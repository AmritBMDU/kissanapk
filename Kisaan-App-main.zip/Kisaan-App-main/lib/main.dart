import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kisaan_electric/StartingUi/splash%20screen.dart';

import 'package:kisaan_electric/global/appcolor.dart';


void main() {
  runApp( Kisaan_Electric());
}

class Kisaan_Electric extends StatelessWidget {
  const Kisaan_Electric({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.white,

        hintColor: appcolor.mixColor,
        fontFamily: 'TenaliRamakrishna',
        textTheme: TextTheme(
          
        )
      ),
      home: splashScreen(),
    );
  }
}