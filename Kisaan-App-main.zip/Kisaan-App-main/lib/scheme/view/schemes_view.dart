import 'dart:convert';
import 'package:http/http.dart'as http;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kisaan_electric/AlertDialogBox/alertBoxContent.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../server/apiDomain.dart';
import '../../whatsaapIcon/WhatsaapIcon.dart';

class schemes_view extends StatefulWidget {
  const schemes_view({super.key});
  @override
  State<schemes_view> createState() => _schemes_viewState();
}

class _schemes_viewState extends State<schemes_view> {
  int totalPoint = 0 ;
  // @override
  // void initState() async{
  //   // TODO: implement initState
  //   final SharedPreferences prefs = await SharedPreferences.getInstance();
  //    totalPoint =  prefs.getInt('point')
  //    !;
  // }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
          color: Colors.white
          // image: DecorationImage(
          //   image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            automaticallyImplyLeading: false,
            title: customAppBar('Schemes'),),
          backgroundColor: Colors.transparent,
          body:
          FutureBuilder(
              future: Schems(),
              builder: (context, snapshot){
            if(snapshot.hasError){
              return Center(child: Image.asset('assets/img_15.png'),);
            }else if(snapshot.connectionState == ConnectionState.waiting){
              return Center(child: CircularProgressIndicator(),);
            }else if(snapshot.hasData){
              var points= snapshot.data;
              return ListView.builder(
                itemCount: points.length,
                  itemBuilder: (context, index){
                  final data  = snapshot.data[index];
                  return Card(
                    child: ListTile(
                      title: Text('${data['title']}'),
                      subtitle: Text('${data['point']}'),
                      leading: Image.network('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlC7Ov5Xn8LBou-KHW9phWsWSQsa70Yec_js6FZEKM&s'),
                      trailing:  totalPoint >= int.parse( data['point'])? blockButton(
                          callback: (){
                            alertBoxdialogBox(context, 'Congratuation', 'Reedem Sechems Successful');
                          },
                          widget: Text('Reedem',style: TextStyle(color: Colors.white),)
                      ):null,
                    ),
                  );
              });
            }else{
              return Center(child: CircularProgressIndicator(),);
            }
              }),
          floatingActionButton:floatingActionButon(context),
        ),
      ),
    );
  }
  Future Schems()async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');

    final response = await http.post(Uri.parse('${apiDomain().domain}scheme'),
        headers: ({
          'Content-Type': 'application/json; charset=UTF-8',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token'
        }));
    if(response.statusCode == 200){
      final data = jsonDecode(response.body);
      final point = data['point'];
      prefs.setInt('point', point);
        totalPoint = point;
      print(point);
      final dataa = data['scheme']['data'];
      print(dataa);
      return dataa;
    }
  }
}
