import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';

import '../../whatsaapIcon/WhatsaapIcon.dart';

class Our_Catalog extends StatefulWidget {
  const Our_Catalog({super.key});
  @override
  State<Our_Catalog> createState() => _Our_Catalog();
}

class _Our_Catalog extends State<Our_Catalog> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            color: Colors.white
          // image: DecorationImage(
          //   image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            automaticallyImplyLeading: false,
            title: customAppBar('Our Catalog'),),
          backgroundColor: Colors.transparent,
          body: Column(
            children: [

              Container(
                height: 1,
                width: Get.width,
                color: appcolor.borderColor,
              ),
             Padding(
               padding: const EdgeInsets.all(8.0),
               child: Container(
                 height: Get.height * 0.4,
                 width: Get.width,
                 child: Image.asset('assets/img_3.png')
               ),
             ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                    height: Get.height * 0.4,
                    width: Get.width,
                    child: Image.asset('assets/img_3.png')
                ),
              ),


            ],
          ),
          floatingActionButton:floatingActionButon(context),
        ),
      ),
    );
  }
}
