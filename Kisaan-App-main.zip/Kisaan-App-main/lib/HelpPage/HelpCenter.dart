import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';

import '../../whatsaapIcon/WhatsaapIcon.dart';

class HelpCenter extends StatefulWidget {
  const HelpCenter({super.key});
  @override
  State<HelpCenter> createState() => _HelpCenter();
}

class _HelpCenter extends State<HelpCenter> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            color: Colors.white
          // image: DecorationImage(
          //   image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          resizeToAvoidBottomInset: false,
          appBar: AppBar(
            backgroundColor: Colors.white,
            automaticallyImplyLeading: false,
            title: customAppBar('Kissan Help Center'),),
          backgroundColor: Colors.transparent,
          body: Column(
            children: [

              Container(
                height: 1,
                width: Get.width,
                color: appcolor.borderColor,
              ),
              SizedBox(
                height: 20,
              ),
              Container(
                height: 396,
                width: 296,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Hi, how can we help you?',style: TextStyle(fontSize: 16),),
                    SizedBox(height: 20,),
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: appcolor.newRedColor,
                        ),
                        borderRadius: BorderRadius.circular(
                          10,
                        ),
                      ),
                      width: Get.width ,
                      height: Get.height * 0.05,
                      child: customtextformfield(
                        key_type: TextInputType.visiblePassword,
                        enabled: true,
                        border: InputBorder.none,
                        bottomLineColor: Colors.transparent,
                        hinttext: 'Search',

                        suffixIcon: Icon(
                          Icons.search,
                        ),
                        newIcon: Icon(
                          Icons.search,
                        ),
                      ),
                    ),
                    SizedBox(height: 20,),
                    Row(
                      children: [
                        Container(
                          height: 82,
                          width: 139,
                          decoration: BoxDecoration(
                            color: Color(0xffD9D9D9),
                            borderRadius: BorderRadius.all(Radius.circular(11)),
                            border: Border.all(
                              color: appcolor.redColor
                            )
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                    height: 40,
                                    width: 40,
                                    child: Image.asset('assets/image 29.png')),
                                Text('Account Setting',style: TextStyle(fontSize: 13),)
                              ],
                            ),
                          ),
                        ),
                        SizedBox(width: 15,),
                        Container(
                          height: 82,
                          width: 139,
                          decoration: BoxDecoration(
                              color: Color(0xffD9D9D9),
                              borderRadius: BorderRadius.all(Radius.circular(11)),
                              border: Border.all(
                                  color: appcolor.redColor
                              )
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                    height: 40,
                                    width: 40,
                                    child: Image.asset('assets/image 30.png')),
                                Text('Login & Password',style: TextStyle(fontSize: 13),)
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                    SizedBox(height: 20,),
                    Row(
                      children: [
                        Container(
                          height: 82,
                          width: 139,
                          decoration: BoxDecoration(
                              color: Color(0xffD9D9D9),
                              borderRadius: BorderRadius.all(Radius.circular(11)),
                              border: Border.all(
                                  color: appcolor.redColor
                              )
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                    height: 40,
                                    width: 40,
                                    child: Image.asset('assets/Rectangle 1.png')),
                                Text('Privacy & Security',style: TextStyle(fontSize: 13),)
                              ],
                            ),
                          ),
                        ),
                        SizedBox(width: 15,),
                        Container(
                          height: 82,
                          width: 139,
                          decoration: BoxDecoration(
                              color: Color(0xffD9D9D9),
                              borderRadius: BorderRadius.all(Radius.circular(11)),
                              border: Border.all(
                                  color: appcolor.redColor
                              )
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                    height: 40,
                                    width: 40,
                                    child: Image.asset('assets/image 33.png')),
                                Text('Privacy Policy',style: TextStyle(fontSize: 13),)
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                    SizedBox(height: 10,),
                    Text('Looking for something else?',style: TextStyle(fontSize: 16,color: appcolor.redColor),),
                    Text('In publishing and graphic design, Lorem\nipsum is a placeholder text commonly \nused to demonstrat',style: TextStyle(fontSize: 14),),


                  ],
                ),
              ),
              Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(

                        children: [
                          SizedBox(width: 22,),
                          Image.asset('assets/Vector (11).png'),
                          SizedBox(width: 4,),
                          Text('Call Us:'),
                          Text('+91 9927001015',style: TextStyle(color: appcolor.redColor),)
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(

                        children: [
                          SizedBox(width: 22,),
                          Image.asset('assets/Vector (12).png'),
                          SizedBox(width: 4,),
                          Text('Email Us:'),
                          Text(' info@kissanwebsite.com',style: TextStyle(color: appcolor.redColor),)
                        ],
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
          floatingActionButton:floatingActionButon(),
        ),
      ),
    );
  }
}
