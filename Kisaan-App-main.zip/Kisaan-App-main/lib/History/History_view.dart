import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';

import '../products/controller/product_controller.dart';
import '../whatsaapIcon/WhatsaapIcon.dart';

class historyView extends StatefulWidget {
  const historyView({super.key});
  @override
  State<historyView> createState() => _historyViewState();
}

class _historyViewState extends State<historyView> {
  productController controller = Get.put(productController());
  DateTime _dateTime = DateTime.now();
  DateTime _EndateTime = DateTime.now();

  void _datepicker()async{    showDatePicker(
      context: context,
      initialEntryMode: DatePickerEntryMode.calendarOnly,
      initialDate: DateTime.now(),
      firstDate: DateTime(2010),
      lastDate: DateTime.now()).then((value) {
    setState(() {
      _dateTime = value!;
    });
  });
  }
  void _Enddatepicker()async{
    showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2010),
        lastDate: DateTime.now()).then((value) {
      setState(() {
        _EndateTime = value!;
        // isCalendarSelected = true;
      });
    });
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            color: Colors.white

          // image: DecorationImage(
          //     image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Column(
            children: [
              customAppBar('History'),
              Container(
                height: 1,
                width: Get.width,
                color: appcolor.borderColor,
              ),
              Container(
                decoration: BoxDecoration(),
                height: Get.height * 0.08,
                child: TabBar(
                  dividerColor: appcolor.newRedColor,
                  indicatorPadding: EdgeInsets.zero,
                  unselectedLabelColor: Colors.black,
                  labelPadding: EdgeInsets.zero,
                  padding: EdgeInsets.zero,
                  unselectedLabelStyle: TextStyle(
                    fontSize: 14,
                  ),
                  indicatorColor: appcolor.redColor,
                  labelColor: Colors.black,
                  labelStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    fontSize: 14,
                  ),
                  controller: controller.tabcontroller,
                  tabs: [
                    Container(
                      child: Text(
                        'Point',
                      ),
                    ),
                    Container(
                      child: Text('Transition'),
                    ),
                    Text('Order'),
                  ],
                ),
              ),
              Expanded(
                child:
                    TabBarView(
                        controller: controller.tabcontroller,
                        children: [
                      points(),
                      Transition(),
                      Order(),
                ]),
              )
            ],
          ),
          floatingActionButton:floatingActionButon(),
        ),
      ),
    );
  }

  Widget points() {
    return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: appcolor.newRedColor,
                  ),
                  borderRadius: BorderRadius.circular(
                    10,
                  ),
                ),
                width: Get.width * 0.6,
                height: Get.height * 0.05,
                child: customtextformfield(
                  enabled: true,
                  border: InputBorder.none,
                  bottomLineColor: Colors.transparent,
                  hinttext: 'Code Search',
                  suffixIcon: Icon(
                    Icons.search,
                  ),
                  newIcon: Icon(
                    Icons.search,
                  ),
                ),
              ),
              Text(
                'Total Points 100',
                style: TextStyle(
                  fontSize: 14,
                  height: 1,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Text(
                'Filter :',
                style: TextStyle(
                  fontSize: 16,
                  height: 1,
                ),
              ),
              Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: appcolor.newRedColor,
                    ),
                    borderRadius: BorderRadius.circular(
                      10,
                    ),
                  ),
                  width: Get.width * 0.26,
                  height: Get.height * 0.04,
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          '${_dateTime == null ? 'Date From: ': '${_dateTime.year}-${_dateTime.month}-${_dateTime.day}'} ',
                          style: TextStyle(
                            fontSize: 9,
                            color: appcolor.black,
                            height: 1,
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            _datepicker();
                          },
                          child: GradientText(
                            gradient: appcolor.gradient,
                            widget: Icon(
                              Icons.calendar_month,
                              size: 16,
                            ),
                          ),
                        )
                      ],
                    ),
                  )),
              Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: appcolor.newRedColor,
                    ),
                    borderRadius: BorderRadius.circular(
                      10,
                    ),
                  ),
                  width: Get.width * 0.26,
                  height: Get.height * 0.04,
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          '${_EndateTime == DateTime.now() ? 'Date To: ': '${_EndateTime.year}-${_EndateTime.month}-${_EndateTime.day}'}',
                          style: TextStyle(
                            fontSize: 9,
                            color: appcolor.black,
                            height: 1,
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            _Enddatepicker();
                          },
                          child: GradientText(
                            gradient: appcolor.gradient,
                            widget: Icon(
                              Icons.calendar_month,
                              size: 16,
                            ),
                          ),
                        )
                      ],
                    ),
                  )),
              blockButton(
                verticalPadding: 3,
                width: Get.width * 0.2,
                widget: Text(
                  'Submit',
                  style: TextStyle(
                    color: Colors.white,fontSize: 12
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: 10,
          )
        ],
      ).paddingSymmetric(
        horizontal: 10,
      ),
    );
  }

  Widget Transition() {
   return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: appcolor.newRedColor,
                  ),
                  borderRadius: BorderRadius.circular(
                    10,
                  ),
                ),
                width: Get.width * 0.6,
                height: Get.height * 0.05,
                child: customtextformfield(
                  enabled: true,
                  border: InputBorder.none,
                  bottomLineColor: Colors.transparent,
                  hinttext: 'Transition Search',
                  suffixIcon: Icon(
                    Icons.search,
                  ),
                  newIcon: Icon(
                    Icons.search,
                  ),
                ),
              ),
              Text(
                'Total Points 100',
                style: TextStyle(
                  fontSize: 14,
                  height: 1,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Text(
                'Filter :',
                style: TextStyle(
                  fontSize: 16,
                  height: 1,
                ),
              ),
              Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: appcolor.newRedColor,
                    ),
                    borderRadius: BorderRadius.circular(
                      10,
                    ),
                  ),
                  width: Get.width * 0.26,
                  height: Get.height * 0.04,
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          '${_dateTime == null ? 'Date From: ': '${_dateTime.year}-${_dateTime.month}-${_dateTime.day}'} ',
                          style: TextStyle(
                            fontSize: 9,
                            color: appcolor.black,
                            height: 1,
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            _datepicker();
                          },
                          child: GradientText(
                            gradient: appcolor.gradient,
                            widget: Icon(
                              Icons.calendar_month,
                              size: 16,
                            ),
                          ),
                        )
                      ],
                    ),
                  )),
              Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: appcolor.newRedColor,
                    ),
                    borderRadius: BorderRadius.circular(
                      10,
                    ),
                  ),
                  width: Get.width * 0.26,
                  height: Get.height * 0.04,
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          '${_EndateTime == DateTime.now() ? 'Date To: ': '${_EndateTime.year}-${_EndateTime.month}-${_EndateTime.day}'}',
                          style: TextStyle(
                            fontSize: 9,
                            color: appcolor.black,
                            height: 1,
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            _Enddatepicker();
                          },
                          child: GradientText(
                            gradient: appcolor.gradient,
                            widget: Icon(
                              Icons.calendar_month,
                              size: 16,
                            ),
                          ),
                        )
                      ],
                    ),
                  )),
              blockButton(
                verticalPadding: 3,
                width: Get.width * 0.2,
                widget: Text(
                  'Submit',
                  style: TextStyle(
                      color: Colors.white,fontSize: 12
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Table(
              border: TableBorder.all(),
              children: [
                TableRow(
                    decoration: BoxDecoration(
                        color: Colors.grey[300]
                    ),
                    children :[
                      Text('Date',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
                      Text('Amount',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
                      Text('Status',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
                      Text('Points',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),


              ]
          ),
        ],
      ).paddingSymmetric(
        horizontal: 10,
      ),
    );
  }

  Widget Order() {
    return  SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: appcolor.newRedColor,
                  ),
                  borderRadius: BorderRadius.circular(
                    10,
                  ),
                ),
                width: Get.width * 0.6,
                height: Get.height * 0.05,
                child: customtextformfield(
                  enabled: true,
                  border: InputBorder.none,
                  bottomLineColor: Colors.transparent,
                  hinttext: 'Product Search',
                  suffixIcon: Icon(
                    Icons.search,
                  ),
                  newIcon: Icon(
                    Icons.search,
                  ),
                ),
              ),
              Text(
                'Total Points 100',
                style: TextStyle(
                  fontSize: 14,
                  height: 1,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Text(
                'Filter :',
                style: TextStyle(
                  fontSize: 16,
                  height: 1,
                ),
              ),
              Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: appcolor.newRedColor,
                    ),
                    borderRadius: BorderRadius.circular(
                      10,
                    ),
                  ),
                  width: Get.width * 0.26,
                  height: Get.height * 0.04,
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          '${_dateTime == null ? 'Date From: ': '${_dateTime.year}-${_dateTime.month}-${_dateTime.day}'} ',
                          style: TextStyle(
                            fontSize: 9,
                            color: appcolor.black,
                            height: 1,
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            _datepicker();
                          },
                          child: GradientText(
                            gradient: appcolor.gradient,
                            widget: Icon(
                              Icons.calendar_month,
                              size: 16,
                            ),
                          ),
                        )
                      ],
                    ),
                  )),
              Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: appcolor.newRedColor,
                    ),
                    borderRadius: BorderRadius.circular(
                      10,
                    ),
                  ),
                  width: Get.width * 0.26,
                  height: Get.height * 0.04,
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          '${_EndateTime == DateTime.now() ? 'Date To: ': '${_EndateTime.year}-${_EndateTime.month}-${_EndateTime.day}'}',
                          style: TextStyle(
                            fontSize: 9,
                            color: appcolor.black,
                            height: 1,
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            _Enddatepicker();
                          },
                          child: GradientText(
                            gradient: appcolor.gradient,
                            widget: Icon(
                              Icons.calendar_month,
                              size: 16,
                            ),
                          ),
                        )
                      ],
                    ),
                  )),
              blockButton(
                verticalPadding: 3,
                width: Get.width * 0.2,
                widget: Text(
                  'Submit',
                  style: TextStyle(
                      color: Colors.white,fontSize: 12
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Table(
              border: TableBorder.all(),
              children: [
                TableRow(
                    decoration: BoxDecoration(
                        color: Colors.grey[300]
                    ),
                    children :[
                      Text('Date',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
                      Text('Order Id',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
                      Text('Order Value',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
                      Text('Status',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),


              ]
          ),
        ],
      ).paddingSymmetric(
        horizontal: 10,
      ),
    );
  }
}
