import 'dart:convert';
import 'package:http/http.dart'as http;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kisaan_electric/History/History_view.dart';
import 'package:kisaan_electric/Orders/OrderPage.dart';
import 'package:kisaan_electric/OurCatalog/Our_Cataog.dart';
import 'package:kisaan_electric/QR/view/qr_scanner_view.dart';
import 'package:kisaan_electric/auth/login/view/login_view.dart';
import 'package:kisaan_electric/auth/ResetPassword/view/reset_password.dart';
import 'package:kisaan_electric/global/aboutUsView.dart';
import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/gradient_text.dart';
import 'package:kisaan_electric/global/language.dart';
import 'package:kisaan_electric/global/legel.dart';
import 'package:kisaan_electric/global/referandEarn.dart';
import 'package:kisaan_electric/global/socialMedia.dart';
import 'package:kisaan_electric/products/view/product_view.dart';
import 'package:kisaan_electric/profile/view/profile_view.dart';
import 'package:kisaan_electric/scheme/view/schemes_view.dart';
import 'package:kisaan_electric/wallet/view/wallet_view.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Feedback/Feedback & Complaints.dart';
import '../HelpPage/HelpCenter.dart';
import '../ranking/ranking.dart';
import '../server/apiDomain.dart';

Widget customDrawer(context,) {

  return FutureBuilder(
    future: HomeData(),
    builder: (context, snapshot){
      if(snapshot.hasError){
        return Center(child: Text('data not found'),);
      }else if(snapshot.connectionState == ConnectionState.waiting){
        return Center(child: CircularProgressIndicator(),);
      }else if(snapshot.hasData){
        var data = snapshot.data;
        var dataa = data['register_at'].split('T');
      var date = dataa[0];
        return Drawer(
          backgroundColor: appcolor.greyColor,
          width: Get.width * 0.75,
          child: Container(
            decoration: BoxDecoration(
                color: Colors.white
              //  image: DecorationImage(
              // image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill)
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height:30,),
                  InkWell(
                    onTap: () {
                      Get.back();
                      Get.to(profile_view());
                    },
                    child: Container(
                      padding: EdgeInsets.only(
                        top: 10,
                      ),
                      child: Row(
                        children: [
                          Container(
                            child: Stack(
                              alignment: Alignment.topCenter,
                              children: [
                                CircleAvatar(
                                  backgroundColor: appcolor.borderColor,
                                  radius: 35,
                                  child: CircleAvatar(
                                    backgroundColor: appcolor.greyColor,
                                    child: Icon(
                                      Icons.person,
                                    ),
                                    radius: 39,
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: Get.height * 0.08),
                                  height: Get.height * 0.03,
                                  width: Get.width * 0.2,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: appcolor.borderColor,
                                    ),
                                    borderRadius: BorderRadius.circular(10),
                                    color: Color(0xffECFF0C),
                                  ),
                                  child: Center(
                                    child: Text(
                                      '20%',
                                      style: TextStyle(
                                        // height: 0.,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(3.0),
                                  child: Text(
                                    '${data['name']}',
                                    style: TextStyle(
                                      height: 1.5,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),

                                Padding(
                                  padding: const EdgeInsets.all(3.0),
                                  child: Text(
                                    '+91 ${data['mobile_no']}',
                                    style: TextStyle(
                                      height: 0.3,
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                                Text(
                                  '$date',
                                  style: TextStyle(
                                    height: 1.2,
                                    fontSize: 14,
                                  ),
                                ),
                                Center(
                                  child: Text(
                                    'CIN: ${data['Cin_no']}',
                                    style: TextStyle(
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                                // Container(
                                //   // padding: EdgeInsets.symmetric(
                                //   //     horizontal: 15, vertical: 5),
                                //   decoration: BoxDecoration(
                                //     border: Border.all(
                                //       color: appcolor.borderColor,
                                //     ),
                                //     borderRadius: BorderRadius.circular(12),
                                //     color: Color(0xffB9B9B9),
                                //
                                //   ),
                                //   width: Get.width * 0.28,
                                //   height: Get.height *0.037,
                                //   child: Center(
                                //     child: Text(
                                //       'CIN: 1123',
                                //       style: TextStyle(
                                //
                                //         fontSize: 14,
                                //       ),
                                //     ),
                                //   ),
                                // ),
                              ],
                            ).paddingOnly(left: 5),
                          ),
                        ],
                      ),
                    ),
                  ),

                  Container(
                    height: Get.height * 0.8,
                    child: ListView(
                      children: [
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(qr_scanner_view());
                          },
                          title: 'Scan',
                          image: Container(
                              child:
                              Image.asset('assets/scan 1.png',)
                            // Image(
                            //   image: AssetImage('assets/scan 1.png',),
                            // ),
                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(schemes_view());
                          },
                          title: 'Scheme',
                          image: Container(
                              child:
                              Image.asset('assets/Vector (3).png',)
                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(wallet_view());
                          },
                          title: 'My Wallet',
                          image: Container(
                              height: Get.height * 0.02,
                              child:  Image.asset('assets/Vector (1).png',)
                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(profile_view());
                          },
                          title: 'My Profile',
                          image: Container(
                              height: Get.height * 0.025,
                              child:  Image.asset('assets/Vector.png',)
                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(product_view());
                          },
                          title: 'Our Products',
                          image: Container(
                              height: Get.height * 0.025,
                              child: Image.asset('assets/secured icon.png',)

                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.to(OrderPage());
                          },
                          title: 'Orders',
                          image: Container(
                              height: Get.height * 0.025,
                              child: Image.asset('assets/Vector (4).png',)

                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(historyView());
                          },
                          title: 'History',
                          image: Container(
                              child:
                              Image.asset('assets/Vector (5).png',)

                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(ranking());
                          },
                          title: 'Ranking',
                          image: Container(
                              height: Get.height * 0.02,
                              child:Image.asset('assets/Vector (7).png',)


                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(socialMedia());
                          },
                          title: 'Social Media',
                          image: Container(
                              height: Get.height * 0.02,
                              child:Image.asset('assets/Vector (2).png',)


                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(referandearn());
                          },
                          title: 'Refer & Earn',
                          image: Container(
                              child: Image.asset('assets/share.png',)

                          ),
                        ),
                        drawerWidget(
                          callback: () {},
                          title: 'Rate Us',
                          image: Container(
                              child: Image.asset('assets/star__.png',)

                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(aboutUs());
                          },
                          title: 'About Us',
                          image: Container(
                              child: Image.asset('assets/Vector (7).png',)

                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.to(Our_Catalog());
                          },
                          title: 'Our Catalog',
                          image: Container(
                              child:Image.asset('assets/Vector (8).png',)

                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.to(HelpCenter());
                          },
                          title: 'Help',
                          image: Container(
                              child: Image.asset('assets/Vector (6).png',)
                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.to(Feedback_Complaints());
                          },
                          title: 'Feedback & Complaints',
                          image: Container(
                              child:Image.asset('assets/support.png',)

                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(legel_view());
                          },
                          title: 'Legal',
                          image: GradientText(
                            gradient: appcolor.gradient,
                            widget: Container(
                                child: Image.asset('assets/external-link-alt.png',)

                            ),
                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(language());
                          },
                          title: 'Language',
                          image: Container(
                              child: Image.asset('assets/Vector (9).png',)

                          ),
                        ),
                        drawerWidget(
                          callback: () {
                            Get.back();
                            Get.to(reset_password());
                          },
                          title: 'Change Password',
                          image: Container(
                              child: Image.asset('assets/change.png',)

                          ),
                        ),
                        drawerWidget(
                          callback: () async{
                            SharedPreferences preferences = await SharedPreferences.getInstance();
                            showDialog<bool>(
                              context: context,
                              builder: (context) =>
                                  AlertDialog(
                                    title: Text('Are you sure?', style: TextStyle(color: Colors.blueGrey),),
                                    content: Text('Do you want to Log Out?', style: TextStyle(color: Colors.blueGrey),),
                                    actions: <Widget>[
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                backgroundColor: appcolor.redColor,
                                                shape: BeveledRectangleBorder(
                                                    borderRadius: BorderRadius.all(Radius.circular(2))
                                                )
                                            ),
                                            onPressed: () => Navigator.pop(context),
                                            child: Text('No', style: TextStyle(color: Colors.white),),
                                          ),
                                          ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                backgroundColor: appcolor.redColor,
                                                shape: BeveledRectangleBorder(
                                                    borderRadius: BorderRadius.all(Radius.circular(2))
                                                )
                                            ),
                                            onPressed: ()async {
                                              await preferences.remove('token');
                                              Get.offAll(login_view());
                                            },
                                            child: Text('Yes', style: TextStyle(color: Colors.white),),
                                          ),
                                        ],
                                      ),


                                    ],
                                  ),
                            );

                          },
                          title: 'Logout',
                          image: GradientText(
                              gradient: appcolor.gradient,
                              widget: Image.asset('assets/Vector (10).png',)

                          ),
                        ),
                        Text(
                          '    App Version 1.0.0',
                          style: TextStyle(
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ).paddingSymmetric(
                horizontal: 10,
              ),
            ),
          ),
        );
      }else{
        return Center(child: CircularProgressIndicator(),);
      }
    },

  );
}

Widget drawerWidget({
  Icon? icon,
  Widget? image,
  String? title,
  Function()? callback,
}) {
  return InkWell(
    onTap: callback,
    child: Container(
      padding: EdgeInsets.only(left: 5, bottom: 2),
      width: Get.width,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,

        children: [
          Container(
            height: Get.height * 0.05,
            child: icon == null
                ? CircleAvatar(
                    radius: 17,
                    backgroundColor: appcolor.borderColor,
                    child: CircleAvatar(
                        radius: 16,
                        backgroundColor: appcolor.greyColor,
                        child: image))
                : CircleAvatar(
                    child: icon,
                  ),
          ),
          SizedBox(
            width: 15,
          ),
          Text(
            '$title',
            style: TextStyle(
              fontSize: 16,
            ),
          )
        ],
      ),
    ),
  );
}
Future HomeData()async{
  final SharedPreferences prefs = await SharedPreferences.getInstance();
  var token = prefs.getString('token');

  final response = await http.post(Uri.parse('${apiDomain().domain}mainpage'),
      headers: ({
        'Content-Type': 'application/json; charset=UTF-8',
        'Accept': 'application/json',
        'Authorization': 'Bearer $token'
      }));
  if(response.statusCode == 200){
    final data = jsonDecode(response.body);

    return data;
  }
}
