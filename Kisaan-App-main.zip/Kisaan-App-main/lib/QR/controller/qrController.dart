import 'package:get/get.dart';

class QrController extends GetxController{

  
} 