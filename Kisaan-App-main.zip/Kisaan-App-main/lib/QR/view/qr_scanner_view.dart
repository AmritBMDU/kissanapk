import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kisaan_electric/History/History_view.dart';

import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/custom_drawer.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';
import 'package:kisaan_electric/notification/notification_page.dart';

import '../../products/view/all_product.dart';
import '../../whatsaapIcon/WhatsaapIcon.dart';

class qr_scanner_view extends StatefulWidget {
  const qr_scanner_view({super.key});

  @override
  State<qr_scanner_view> createState() => _qr_scanner_viewState();
}

class _qr_scanner_viewState extends State<qr_scanner_view> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
          color: Colors.white
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Scaffold(
            appBar: AppBar(
              centerTitle: true,
              title: Container(
                width: Get.width * 0.4,
                child: Image(
                  image: AssetImage(
                    'assets/plain logo 1.png',
                  ),
                ),
              ),
              actions: [
                InkWell(
                  onTap: () {
                    Scaffold.of(context).openDrawer();
                  },
                  child: GradientText(
                    gradient: appcolor.gradient,
                    widget: Icon(
                      Icons.call,
                    ),
                  ),
                ),
                GradientText(
                    gradient: appcolor.gradient,
                    widget: IconButton(
                      onPressed: () {
                        Get.to(notifcation());
                      },
                      icon: Icon(
                        Icons.notifications,
                      ),
                    )),
              ],
              leading: GradientText(
                gradient: appcolor.gradient,
                widget: IconButton(
                  icon: Icon(
                    Icons.arrow_back,
                    size: 25,
                  ),
                  onPressed: () {
                    Get.back();
                  },
                ),
              ),
              backgroundColor: Colors.transparent,
              elevation: 0,
            ),
            backgroundColor: Colors.transparent,
            body: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Center(
                    child: GradientText(
                      gradient: appcolor.gradient,
                      widget: Text(
                        'Scan Your Code',
                        style: TextStyle(fontSize: 20,color:appcolor.redColor),
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      // Get.to(scanQR());
                    },
                    child: Container(
                      margin: EdgeInsets.all(5),
                      padding: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: appcolor.borderColor,
                        ),
                        borderRadius: BorderRadius.circular(8),
                        color: appcolor.greyColor,
                      ),
                      child: Image(
                          image: AssetImage(
                              'assets/QR_code_for_mobile_English_Wikipedia 1.png')),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    'Hold your phone aprox 10cm\naway from the code steady for 2 second',
                    style: TextStyle(
                      fontSize: 15,
                      height: 0.9,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 20,),
                  Container(
                    height: Get.height * 0.055,
                    child: customtextformfield(
                      bottomLineColor: Color(0xffb8b8b8),
                      hinttext: 'Enter your Coupon code',
                      key_type: TextInputType.visiblePassword,

                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Container(
                        height: Get.height * 0.055,
                        child: blockButton(
                          callback: () {

                          },
                          width: Get.width * 0.3,
                          widget: Text(
                            'Submit',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                height: 1.2),
                          ),
                          verticalPadding: 3,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    '*Click below to view scanned code history  ',
                    style: TextStyle(
                      color: appcolor.redColor,
                      fontSize: 14,
                    ),
                  ),
                  TextButton(
                      onPressed: () {
                        Get.to(historyView());
                      },
                      child: Text(
                        'View History',
                        style: TextStyle(
                          fontSize: 14,
                          color: appcolor.redColor,
                          decoration: TextDecoration.underline,
                        ),
                      ))
                ],
              ).paddingSymmetric(horizontal: 15, vertical: 15),
            ),
            floatingActionButton:floatingActionButon(),
          ),
        ),
      ),
    );
  }
}
