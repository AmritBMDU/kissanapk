import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';

import '../../whatsaapIcon/WhatsaapIcon.dart';

class OrderPage extends StatefulWidget {
  const OrderPage({super.key});
  @override
  State<OrderPage> createState() => _OrderPage();
}

class _OrderPage extends State<OrderPage> {
  var image = 'assets/image 16.png';
  var Name = 'Double Door';
  var Price = 'Rs 128.0';
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            color: Colors.white
          // image: DecorationImage(
          //   image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            automaticallyImplyLeading: false,
            title: customAppBar('Orders'),),
          backgroundColor: Colors.transparent,
          body: Column(
            children: [

              Container(
                height: 1,
                width: Get.width,
                color: appcolor.borderColor,
              ),
              Card(
                elevation: 4,
                color: Color(0xffEEEEEE),
                child: ListTile(
                  leading: Container(
                      height: 50,
                      width: 50,
                      child: Image.asset(image,fit: BoxFit.cover,)),
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text('Name: ',style: TextStyle(
                                fontSize: 14,
                                color: appcolor.redColor,
                                height: 0.9,
                              ),),
                              Text(Name,style: TextStyle(
                                fontSize: 14,
                                height: 0.9,
                              ),),
                            ],
                          ),
                          Text('Order CRN7848738984',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 10),)

                        ],
                      ),
                      Container(
                        width: 90,
                        decoration: BoxDecoration(
                            color: Colors.blueAccent,
                            borderRadius: BorderRadius.all(Radius.circular(5))
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),

                          child: Center(child: Text('Conform',style: TextStyle(fontWeight: FontWeight.w200,color: Colors.white),)),
                        ),
                      )
                    ],
                  ),

                  subtitle:Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text('Price: ',style: TextStyle(
                            fontSize: 14,
                            color: appcolor.redColor,
                            height: 0.9,
                          ),),
                          Text('200.0',style: TextStyle(
                            fontSize: 14,
                            height: 0.9,
                          ),),
                        ],
                      ),
                      SizedBox(height: 5,),
                    ],
                  ),
                ),
              ),
              Card(
                elevation: 4,
                color: Color(0xffEEEEEE),
                child: ListTile(
                  leading: Container(
                      height: 50,
                      width: 50,
                      child: Image.asset(image,fit: BoxFit.cover,)),
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text('Name: ',style: TextStyle(
                                fontSize: 14,
                                color: appcolor.redColor,
                                height: 0.9,
                              ),),
                              Text('Socket',style: TextStyle(
                                fontSize: 14,
                                height: 0.9,
                              ),),
                            ],
                          ),
                          Text('Order CRN7848738674',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 10),)

                        ],
                      ),
                      Container(
                        width: 90,
                        decoration: BoxDecoration(
                            color: appcolor.redColor,
                          borderRadius: BorderRadius.all(Radius.circular(5))
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),

                          child: Text('Cancelled',style: TextStyle(fontWeight: FontWeight.w200,color: Colors.white),),
                        ),
                      )
                    ],
                  ),

                  subtitle:Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text('Price: ',style: TextStyle(
                            fontSize: 14,
                            color: appcolor.redColor,
                            height: 0.9,
                          ),),
                          Text(Price,style: TextStyle(
                            fontSize: 14,
                            height: 0.9,
                          ),),
                        ],
                      ),
                      SizedBox(height: 5,),
                    ],
                  ),
                ),
              ),
            ],
          ),
          floatingActionButton:floatingActionButon(),
        ),
      ),
    );
  }
}