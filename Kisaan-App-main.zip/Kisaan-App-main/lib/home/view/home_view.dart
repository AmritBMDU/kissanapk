import 'dart:convert';
import 'package:http/http.dart'as http;
import 'package:carousel_slider/carousel_options.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:kisaan_electric/Offer/OfferPage.dart';
import 'package:kisaan_electric/auth/login/controller/login_controller.dart';
import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/custom_drawer.dart';
import 'package:kisaan_electric/global/gradient_text.dart';
import 'package:kisaan_electric/QR/view/qr_scanner_view.dart';
import 'package:kisaan_electric/products/view/product_view.dart';
import 'package:kisaan_electric/profile/view/profile_view.dart';
import 'package:kisaan_electric/wallet/view/wallet_view.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../Moddal/urlModal.dart';
import '../../Orders/OrderPage.dart';
import '../../notification/notification_page.dart';
import '../../products/view/all_product.dart';
import '../../server/apiDomain.dart';
import '../../whatsaapIcon/WhatsaapIcon.dart';

class Home_view extends StatefulWidget {
  const Home_view({super.key});

  @override
  State<Home_view> createState() => _Home_viewState();
}

class _Home_viewState extends State<Home_view> {
  login_controller controller = Get.put(login_controller());
  SocialMediaUrl() async {
    //   await Future.delayed(Duration(seconds: 2));
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');
    try{
      final response =
      await http.post(Uri.parse('${apiDomain().domain}social_media'),
          headers: ({
            'Content-Type': 'application/json; charset=UTF-8',
            'Accept': 'application/json',
            'Authorization': 'Bearer $token'
          }));
      if(response.statusCode ==200){
        final catalogJson = response.body;
        final decodedData = jsonDecode(catalogJson);
        var productsData = decodedData["data"];
         print(productsData);
        Banners.Items = List.from(productsData)
            .map<Data>((product) => Data.fromJson(product))
            .toList();
        setState(() {
        });
      }
    }catch(w){
      throw Exception(w.toString());
    }
  }
  Future HomeData()async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');

    final response = await http.post(Uri.parse('${apiDomain().domain}mainpage'),
        headers: ({
          'Content-Type': 'application/json; charset=UTF-8',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token'
        }));
    if(response.statusCode == 200){
      final data = jsonDecode(response.body);

      return data;
    }
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    SocialMediaUrl();
  }
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async{
        final value =  await showDialog<bool>(
          context: context,
          builder: (context) =>
              AlertDialog(
                title: Text('Are you sure?', style: TextStyle(color: Colors.blueGrey),),
                content: Text('Do you want to exit?', style: TextStyle(color: Colors.blueGrey),),
                actions: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: appcolor.redColor,
                            shape: BeveledRectangleBorder(
                                borderRadius: BorderRadius.all(Radius.circular(2))
                            )
                        ),
                        onPressed: () => Navigator.of(context).pop(false),
                        child: Text('No', style: TextStyle(color: Colors.white),),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: appcolor.redColor,
                            shape: BeveledRectangleBorder(
                                borderRadius: BorderRadius.all(Radius.circular(2))
                            )
                        ),
                        onPressed: () => Navigator.of(context).pop(true),
                        child: Text('Yes', style: TextStyle(color: Colors.white),),
                      ),
                    ],
                  ),
                ],
              ),
        ); if(value !=null){
          return Future.value(value);
        }else{
          return Future.value(false);
        }
      },
      child: Container(
        color: Colors.white,
        child: Scaffold(
          drawer: customDrawer(context,),
          appBar: AppBar(
            centerTitle: true,
            title: Container(
              width: Get.width * 0.4,
              child: Image(
                image: AssetImage(
                  'assets/plain logo 1.png',
                ),
              ),
            ),
            actions: [
              InkWell(
                onTap: () {
                  _makePhoneCall('+91 9667371301');
                  // Scaffold.of(context).openDrawer();
                },
                child: GradientText(
                  gradient: appcolor.gradient,
                  widget: Icon(
                    Icons.call,
                  ),
                ),
              ),
              GradientText(
                  gradient: appcolor.gradient,
                  widget: IconButton(
                    onPressed: () {
                      Get.to(notifcation());
                    },
                    icon: Icon(
                      Icons.notifications,
                    ),
                  )),
            ],
            leading: Builder(
              builder: (context) {
                return InkWell(
                  onTap: () {
                    Scaffold.of(context).openDrawer();
                  },
                  child: GradientText(
                    gradient: appcolor.gradient,
                    widget: Icon(
                      Icons.sort,
                    ),
                  ),
                );
              },
            ),
            backgroundColor: Colors.transparent,
            elevation: 0,
          ),
          backgroundColor: Colors.transparent,
          resizeToAvoidBottomInset: false,
          body:  SafeArea(
                        child: Container(
                          height: Get.height,
                          width: Get.width,
                          decoration: BoxDecoration(
                              color: Colors.white
                          ),
                          child:  FutureBuilder(
                                future: HomeData(),
                                builder: (context,snapshot){
                                  if(snapshot.hasError){
                                    return Center(child: Image.asset('assets/img_15.png'),);
                                  }else if(snapshot.connectionState == ConnectionState.waiting){
                                    return Center(child: CircularProgressIndicator());
                                  }else if(snapshot.hasData){
                                    var data = snapshot.data;
                                    return   Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              'Hello ${data['name']}',
                                              style: TextStyle(
                                                fontSize: 15,
                                                color: appcolor.black,
                                              ),
                                            ),
                                            Row(
                                              children: [
                                                Text(
                                                  'Status: ',
                                                  style: TextStyle(
                                                    fontSize: 15,
                                                    color: appcolor.black,
                                                  ),
                                                ),
                                                Text(
                                                  '${data['user_status']}',
                                                  style: TextStyle(
                                                    fontSize: 15,
                                                    color:data['user_status'] == 'Approved'? Colors.green:Colors.yellow,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ).paddingSymmetric(horizontal: 18),

                                        CarouselSlider(
                                          options: CarouselOptions(
                                              autoPlay: true,
                                              enlargeCenterPage: true,
                                              viewportFraction: 1,
                                              aspectRatio: 2.0,
                                              initialPage: 1,
                                              height: 100

                                          ),
                                          //carouselController: buttonCarouselController,
                                          items: [ 'assets/image 1.png', 'assets/image 1.png', 'assets/image 1.png'].map((i) {
                                            return Builder(
                                              builder: (BuildContext context) {
                                                return Container(
                                                    width: Get.width,
                                                    // height: Get.height* 0.1,
                                                    child:Image.asset(i,fit: BoxFit.cover,)
                                                );

                                              },
                                            );
                                          }).toList(),
                                        ),

                                        Column(
                                          children: [
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                                              children: [
                                                Card(
                                                  elevation: 1,
                                                  child: Container(
                                                    width: Get.width * 0.4,
                                                    height: Get.height * 0.11,
                                                    decoration: BoxDecoration(
                                                      color: Color(0xffEEEEEE),
                                                      borderRadius: BorderRadius.circular(
                                                        8,
                                                      ),
                                                      // border: Border.all(color: Color(0xff3C2B99)),
                                                    ),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                      children: [
                                                        GradientText(
                                                          gradient: appcolor.gradient,
                                                          widget: Text(
                                                            'Your Points',
                                                            style: TextStyle(
                                                              fontSize: 15,
                                                            ),
                                                            textAlign: TextAlign.center,
                                                          ),
                                                        ),
                                                        GradientText(
                                                          gradient: appcolor.gradient,
                                                          widget: Text(
                                                            '${data['total_point']} Pts.',
                                                            style: TextStyle(
                                                                fontSize: 27,color: appcolor.redColor
                                                            ),
                                                            textAlign: TextAlign.center,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Card(
                                                  elevation: 1,
                                                  child: Container(
                                                    width: Get.width * 0.4,
                                                    height: Get.height * 0.11,
                                                    decoration: BoxDecoration(
                                                      color: Color(0xffEEEEEE),
                                                      borderRadius: BorderRadius.circular(
                                                        8,
                                                      ),
                                                      //   border: Border.all(color: Color(0xff3C2B99)),
                                                    ),
                                                    child: Column(
                                                      children: [
                                                        GradientText(
                                                          gradient: appcolor.gradient,
                                                          widget: Text(
                                                            'Total Redemptions',
                                                            style: TextStyle(
                                                              fontSize: 14,
                                                            ),
                                                            textAlign: TextAlign.center,
                                                          ),
                                                        ),
                                                        SizedBox(height: 5,),
                                                        Text('(Financial Year)',style: TextStyle(fontSize: 10),),
                                                        SizedBox(height: 10,),
                                                        GradientText(
                                                          gradient: appcolor.gradient,
                                                          widget: Text(
                                                            'Rs.${data['redeem']}',
                                                            style: TextStyle(
                                                                fontSize: 27,color: appcolor.redColor
                                                            ),
                                                            textAlign: TextAlign.center,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ).paddingOnly(
                                              bottom: 20,
                                            ),
                                            Wrap(
                                              alignment: WrapAlignment.spaceBetween,
                                              spacing: 5,
                                              runSpacing: 10,
                                              children: [
                                                customwidget(
                                                  assetimagepath: 'assets/scan 1.png',
                                                  callback: () {
                                                    Get.to(qr_scanner_view());
                                                  },
                                                  title: 'Scan',
                                                ),
                                                customwidget(
                                                  assetimagepath: 'assets/offers 1.png',
                                                  callback: () {
                                                    Get.to(OfferPage());
                                                  },
                                                  title: 'Offers',
                                                ),
                                                customwidget(
                                                  assetimagepath: 'assets/Vector.png',
                                                  callback: () {
                                                    Get.to(profile_view());
                                                  },
                                                  title: 'My Profile',
                                                ),
                                                customwidget(
                                                  assetimagepath: 'assets/Vector (1).png',
                                                  callback: () {
                                                    Get.to(wallet_view());
                                                  },
                                                  title: 'My Wallet',
                                                ),
                                                customwidget(
                                                  assetimagepath: 'assets/secured icon.png',
                                                  callback: () {
                                                    Get.to(product_view());
                                                  },
                                                  title: 'Our Products',
                                                ),
                                                customwidget(
                                                  assetimagepath: 'assets/Vector (16).png',
                                                  callback: () {
                                                    Get.to(OrderPage());
                                                  },
                                                  title: 'Orders',
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 10,),
                                            GradientText(
                                              gradient: appcolor.gradient,
                                              widget: Text(
                                                'Our Products',
                                                style: TextStyle(
                                                    fontSize: 20,
                                                    height: 1,color: appcolor.redColor
                                                ),
                                              ),
                                            ).paddingSymmetric(
                                              vertical: 6,
                                            ),
                                            SingleChildScrollView(
                                              scrollDirection: Axis.horizontal,
                                              child: Row(
                                                children: [
                                                  Wrap(
                                                    spacing: 8,
                                                    children: <Widget>[
                                                      InkWell(
                                                        onTap:(){
                                                          Get.to(allProduct());
                                                        },
                                                        child: Card(
                                                          elevation: 1,
                                                          child: Container(
                                                            width: Get.width * 0.28,
                                                            height: Get.height * 0.09,
                                                            decoration: BoxDecoration(
                                                              color: Color(0xffEEEEEE),
                                                              borderRadius: BorderRadius.circular(
                                                                8,
                                                              ),
                                                              //  border: Border.all(color: Color(0xff3C2B99)),
                                                            ),
                                                            child: Column(
                                                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                              children: [
                                                                Container(
                                                                  height: Get.height * 0.06,
                                                                  child: Image(
                                                                      image: AssetImage('assets/image 2.png')),
                                                                ),
                                                                Text(
                                                                  'MODULAR BOX',
                                                                  style: TextStyle(
                                                                    fontSize: 10,
                                                                  ),
                                                                  textAlign: TextAlign.center,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      InkWell(
                                                        onTap: (){
                                                          Get.to(allProduct());
                                                        },
                                                        child: Card(elevation: 1,
                                                          child: Container(
                                                            width: Get.width * 0.28,
                                                            height: Get.height * 0.09,
                                                            decoration: BoxDecoration(
                                                              color: Color(0xffEEEEEE),
                                                              borderRadius: BorderRadius.circular(
                                                                8,
                                                              ),
                                                              //   border: Border.all(color: Color(0xff3C2B99)),
                                                            ),
                                                            child: Column(
                                                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                              children: [
                                                                Container(
                                                                  height: Get.height * 0.06,
                                                                  child: Image(
                                                                      image: AssetImage('assets/image1 1.png')),
                                                                ),
                                                                Text(
                                                                  'CONCEALED BOX',
                                                                  style: TextStyle(
                                                                    fontSize: 10,
                                                                  ),
                                                                  textAlign: TextAlign.center,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      InkWell(
                                                        onTap: (){
                                                          Get.to(allProduct());
                                                        },
                                                        child: Card(
                                                          elevation: 1,
                                                          child: Container(
                                                            width: Get.width * 0.28,
                                                            height: Get.height * 0.09,
                                                            decoration: BoxDecoration(
                                                              color: Color(0xffEEEEEE),
                                                              borderRadius: BorderRadius.circular(
                                                                8,
                                                              ),
                                                              // border: Border.all(color: Color(0xff3C2B99)),
                                                            ),
                                                            child: Column(
                                                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                              children: [
                                                                Container(
                                                                  height: Get.height * 0.06,
                                                                  child: Image(
                                                                      image: AssetImage('assets/image 4.png')),
                                                                ),
                                                                Text(
                                                                  'FAN BOXS',
                                                                  style: TextStyle(
                                                                    fontSize: 10,
                                                                  ),
                                                                  textAlign: TextAlign.center,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      InkWell(
                                                        onTap: (){
                                                          Get.to(allProduct());
                                                        },
                                                        child: Card(elevation: 1,
                                                          child: Container(
                                                            width: Get.width * 0.28,
                                                            height: Get.height * 0.09,
                                                            decoration: BoxDecoration(
                                                              color: Color(0xffEEEEEE),
                                                              borderRadius: BorderRadius.circular(
                                                                8,
                                                              ),
                                                              //  border: Border.all(color: Color(0xff3C2B99)),
                                                            ),
                                                            child: Column(
                                                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                              children: [
                                                                Container(
                                                                  height: Get.height * 0.06,
                                                                  child: Image(
                                                                      image: AssetImage('assets/image1 1.png')),
                                                                ),
                                                                Text(
                                                                  'CONCEALED BOX',
                                                                  style: TextStyle(
                                                                    fontSize: 10,
                                                                  ),
                                                                  textAlign: TextAlign.center,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      InkWell(
                                                        onTap: (){
                                                          Get.to(allProduct());
                                                        },
                                                        child: Card(
                                                          elevation: 1,
                                                          child: Container(
                                                            width: Get.width * 0.28,
                                                            height: Get.height * 0.09,
                                                            decoration: BoxDecoration(
                                                              color: Color(0xffEEEEEE),
                                                              borderRadius: BorderRadius.circular(
                                                                8,
                                                              ),
                                                              //    border: Border.all(color: Color(0xff3C2B99)),
                                                            ),
                                                            child: Column(
                                                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                              children: [
                                                                Container(
                                                                  height: Get.height * 0.06,
                                                                  child: Image(
                                                                      image: AssetImage('assets/image 4.png')),
                                                                ),
                                                                Text(
                                                                  'FAN BOXS',
                                                                  style: TextStyle(
                                                                    fontSize: 10,
                                                                  ),
                                                                  textAlign: TextAlign.center,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ).paddingOnly(
                                                    bottom: 10,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              height: Get.height * 0.055,
                                              child: blockButton(
                                                callback: () {
                                                  Get.to(allProduct());
                                                },
                                                width: Get.width * 0.3,
                                                widget: Text(
                                                  'See More',
                                                  style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 15,
                                                      fontWeight: FontWeight.bold,
                                                      height: 1.2),
                                                ),
                                                verticalPadding: 3,
                                              ),
                                            ),


                                          ],
                                        ).paddingSymmetric(
                                          horizontal: 18,
                                          vertical:6,
                                        ),

                                        Padding(
                                          padding: const EdgeInsets.only(left: 20,right: 20),
                                          child: Container(
                                            height: Get.height * 0.08,
                                            width: Get.width,
                                            child: Padding(
                                                padding: const EdgeInsets.all(8.0),

                                                child: Banners.Items !=null && Banners.Items.isNotEmpty?
                                                ListView.builder(
                                                    itemCount: Banners.Items.length,
                                                    itemBuilder: (context, index){
                                                      final url = Banners.Items[index];
                                                      return   Padding(
                                                        padding: const EdgeInsets.all(2.0),
                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                          children: [
                                                            SocialMedia(
                                                              assetimagepath: 'assets/inst.png',
                                                              callback: () {
                                                                var urls = url.instagram.toString();
                                                                _launchInBrowserView(urls);
                                                              },
                                                            ),
                                                            SizedBox(width: 8,),
                                                            SocialMedia(
                                                              assetimagepath: 'assets/youtbe.png',
                                                              callback: () {
                                                                var urls = url.youtube.toString();
                                                                _launchInBrowserView(urls);
                                                              },
                                                            ),
                                                            SizedBox(width: 8,),
                                                            SocialMedia(
                                                              assetimagepath: 'assets/fb.png',
                                                              callback: () {
                                                                var urls = url.facebook.toString();
                                                                _launchInBrowserView(urls);
                                                              },

                                                            ),
                                                            SizedBox(width: 8,),
                                                            SocialMedia(
                                                              assetimagepath: 'assets/img_9.png',
                                                              callback: () {
                                                                var urls = url.linkedin.toString();
                                                                _launchInBrowserView(urls);
                                                              },
                                                            ),
                                                            SizedBox(width: 8,),
                                                            SocialMedia(
                                                              assetimagepath: 'assets/img_13.png',
                                                              callback: () {
                                                                var urls = url.twitter.toString();
                                                                _launchInBrowserView(urls);
                                                              },
                                                            ),


                                                          ],
                                                        ),
                                                      );
                                                    }): Center(child: CircularProgressIndicator(),)

                                            ),

                                          ),
                                        )
                                      ],
                                    );
                                  }else{
                                    return Center(child: CircularProgressIndicator(),);
                                  }
                                },
                              )

                          ),
                        ),






            floatingActionButton:floatingActionButonn(context),


        ),
      ),
    );
  }

  Future<void> _makePhoneCall(String phoneNumber) async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: phoneNumber,
    );
    await launchUrl(launchUri);
  }
  Future<void> _launchInBrowserView(url) async {
    if (!await launchUrl(Uri.parse(url), mode: LaunchMode.inAppBrowserView)) {
      throw Exception('Could not launch $url');
    }
  }
}

Widget customwidget({
  Function()? callback,
  String? assetimagepath,
  String? title,
}) {
  return InkWell(
    onTap: callback,
    child: Column(
      children: [
        Container(
          child: PhysicalShape(
            elevation: 1,
            clipper: ShapeBorderClipper(shape: CircleBorder()),
            color: Color(0xffEEEEEE),
            child: Container(
                height: 70,
                width: 100,
                child: Image.asset(assetimagepath.toString(),)
            ),
          ),
        ),
        SizedBox(height: 10,),

        GradientText(
          widget: Text(
            '$title',
            style: TextStyle(
              fontSize: 14,color: appcolor.redColor,
            ),
          ),
          gradient: appcolor.gradient,
        ),
      ],
    ),
  );
}
Widget SocialMedia({
  Function()? callback,
  String? assetimagepath,

}) {
  return InkWell(
    onTap: callback,
    child: Column(
      children: [

        CircleAvatar(
          radius: 22,
          backgroundColor: appcolor.greyColor,

          child:Center(child: Image.asset(assetimagepath.toString(),height: 20,width: 20,))
          ),


      ],
    ),
  );
}
Widget floatingActionButonn(context){
  return    SizedBox(
    height: 40,
    width: 40,
    child: FloatingActionButton(

        backgroundColor: Colors.green,
        onPressed: () {
          launchWhatsapp(context);
        },child: FaIcon(FontAwesomeIcons.whatsapp,)

    ),
  );
}
launchWhatsapp(context) async {
  var whatsapp = "+91 7056402956";
  var whatsappAndroid = Uri.parse("whatsapp://send?phone=$whatsapp&text=hello");
  if (await canLaunchUrl(whatsappAndroid,)) {
    await launchUrl(whatsappAndroid,);
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("WhatsApp is not installed on the device"),
      ),
    );
  }
}

