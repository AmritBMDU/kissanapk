import 'package:carousel_slider/carousel_options.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:kisaan_electric/Offer/OfferPage.dart';
import 'package:kisaan_electric/auth/forgetPassword_view.dart';
import 'package:kisaan_electric/auth/login/controller/login_controller.dart';
import 'package:kisaan_electric/auth/register/view/register.dart';
import 'package:kisaan_electric/auth/reset_password.dart';
import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/custom_drawer.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';
import 'package:kisaan_electric/QR/view/qr_scanner_view.dart';
import 'package:kisaan_electric/global/socialMedia.dart';
import 'package:kisaan_electric/products/view/product_view.dart';
import 'package:kisaan_electric/profile/view/profile_view.dart';
import 'package:kisaan_electric/wallet/view/wallet_view.dart';

import '../../Orders/OrderPage.dart';
import '../../notification/notification_page.dart';
import '../../products/view/all_product.dart';
import '../../whatsaapIcon/WhatsaapIcon.dart';

class Home_view extends StatefulWidget {
  const Home_view({super.key});

  @override
  State<Home_view> createState() => _Home_viewState();
}

class _Home_viewState extends State<Home_view> {
  login_controller controller = Get.put(login_controller());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          height: Get.height,
          width: Get.width,
          decoration: BoxDecoration(
            color: Colors.white
          ),
          child: Scaffold(
            drawer: customDrawer(),
            appBar: AppBar(
              centerTitle: true,
              title: Container(
                width: Get.width * 0.4,
                child: Image(
                  image: AssetImage(
                    'assets/plain logo 1.png',
                  ),
                ),
              ),
              actions: [
                InkWell(
                  onTap: () {
                    Scaffold.of(context).openDrawer();
                  },
                  child: GradientText(
                    gradient: appcolor.gradient,
                    widget: Icon(
                      Icons.call,
                    ),
                  ),
                ),
                GradientText(
                    gradient: appcolor.gradient,
                    widget: IconButton(
                      onPressed: () {
                        Get.to(notifcation());
                      },
                      icon: Icon(
                        Icons.notifications,
                      ),
                    )),
              ],
              leading: Builder(
                builder: (context) {
                  return InkWell(
                    onTap: () {
                      Scaffold.of(context).openDrawer();
                    },
                    child: GradientText(
                      gradient: appcolor.gradient,
                      widget: Icon(
                        Icons.sort,
                      ),
                    ),
                  );
                },
              ),
              backgroundColor: Colors.transparent,
              elevation: 0,
            ),
            backgroundColor: Colors.transparent,
            resizeToAvoidBottomInset: false,
            body: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Hello Mohit',
                      style: TextStyle(
                        fontSize: 15,
                        color: appcolor.black,
                      ),
                    ),
                    Row(
                      children: [
                        Text(
                          'Status: ',
                          style: TextStyle(
                            fontSize: 15,
                            color: appcolor.black,
                          ),
                        ),
                        Text(
                          'Pending',
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.yellow,
                          ),
                        ),
                      ],
                    ),
                  ],
                ).paddingSymmetric(horizontal: 18),

                CarouselSlider(
                  options: CarouselOptions(
                    autoPlay: true,
                    enlargeCenterPage: true,
                    viewportFraction: 1,
                    aspectRatio: 2.0,
                    initialPage: 1,
                    height: 100

                  ),
                  //carouselController: buttonCarouselController,
                  items: [ 'assets/image 1.png', 'assets/image 1.png', 'assets/image 1.png'].map((i) {
                    return Builder(
                      builder: (BuildContext context) {
                        return Container(
                            width: Get.width,
                            // height: Get.height* 0.1,
                            child:Image.asset(i,fit: BoxFit.cover,)
                        );

                      },
                    );
                  }).toList(),
                ),

                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Card(
                          elevation: 1,
                          child: Container(
                            width: Get.width * 0.4,
                            height: Get.height * 0.11,
                            decoration: BoxDecoration(
                              color: Color(0xffEEEEEE),
                              borderRadius: BorderRadius.circular(
                                8,
                              ),
                             // border: Border.all(color: Color(0xff3C2B99)),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                GradientText(
                                  gradient: appcolor.gradient,
                                  widget: Text(
                                    'Your Points',
                                    style: TextStyle(
                                      fontSize: 15,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                GradientText(
                                  gradient: appcolor.gradient,
                                  widget: Text(
                                    '0 Pts.',
                                    style: TextStyle(
                                      fontSize: 27,color: appcolor.redColor
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Card(
                          elevation: 1,
                          child: Container(
                            width: Get.width * 0.4,
                            height: Get.height * 0.11,
                            decoration: BoxDecoration(
                              color: Color(0xffEEEEEE),
                              borderRadius: BorderRadius.circular(
                                8,
                              ),
                           //   border: Border.all(color: Color(0xff3C2B99)),
                            ),
                            child: Column(
                              children: [
                                GradientText(
                                  gradient: appcolor.gradient,
                                  widget: Text(
                                    'Total Redemptions',
                                    style: TextStyle(
                                      fontSize: 14,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                SizedBox(height: 5,),
                                Text('(Financial Year)',style: TextStyle(fontSize: 10),),
                                SizedBox(height: 10,),
                                GradientText(
                                  gradient: appcolor.gradient,
                                  widget: Text(
                                    'Rs.0',
                                    style: TextStyle(
                                      fontSize: 27,color: appcolor.redColor
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ).paddingOnly(
                      bottom: 20,
                    ),
                    Wrap(
                      alignment: WrapAlignment.spaceBetween,
                      spacing: 5,
                      runSpacing: 10,
                      children: [
                        customwidget(
                          assetimagepath: 'assets/scan 1.png',
                          callback: () {
                            Get.to(qr_scanner_view());
                          },
                          title: 'Scan',
                        ),
                        customwidget(
                          assetimagepath: 'assets/offers 1.png',
                          callback: () {
                            Get.to(OfferPage());
                          },
                          title: 'Offers',
                        ),
                        customwidget(
                          assetimagepath: 'assets/Vector.png',
                          callback: () {
                            Get.to(profile_view());
                          },
                          title: 'My Profile',
                        ),
                        customwidget(
                          assetimagepath: 'assets/Vector (1).png',
                          callback: () {
                            Get.to(wallet_view());
                          },
                          title: 'My Wallet',
                        ),
                        customwidget(
                          assetimagepath: 'assets/secured icon.png',
                          callback: () {
                            Get.to(product_view());
                          },
                          title: 'Our Products',
                        ),
                        customwidget(
                          assetimagepath: 'assets/Vector (16).png',
                          callback: () {
                            Get.to(OrderPage());
                          },
                          title: 'Orders',
                        ),
                      ],
                    ),
                    SizedBox(height: 10,),
                    GradientText(
                      gradient: appcolor.gradient,
                      widget: Text(
                        'Our Products',
                        style: TextStyle(
                          fontSize: 20,
                          height: 1,color: appcolor.redColor
                        ),
                      ),
                    ).paddingSymmetric(
                      vertical: 6,
                    ),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          Wrap(
                            spacing: 8,
                            children: <Widget>[
                              InkWell(
                                onTap:(){
                                  Get.to(allProduct());
                                 },
                                child: Card(
                                  elevation: 1,
                                  child: Container(
                                    width: Get.width * 0.28,
                                    height: Get.height * 0.09,
                                    decoration: BoxDecoration(
                                      color: Color(0xffEEEEEE),
                                      borderRadius: BorderRadius.circular(
                                        8,
                                      ),
                                    //  border: Border.all(color: Color(0xff3C2B99)),
                                    ),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Container(
                                          height: Get.height * 0.06,
                                          child: Image(
                                              image: AssetImage('assets/image 2.png')),
                                        ),
                                        Text(
                                          'MODULAR BOX',
                                          style: TextStyle(
                                            fontSize: 10,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: (){
                                  Get.to(allProduct());
                                },
                                child: Card(elevation: 1,
                                  child: Container(
                                    width: Get.width * 0.28,
                                    height: Get.height * 0.09,
                                    decoration: BoxDecoration(
                                      color: Color(0xffEEEEEE),
                                      borderRadius: BorderRadius.circular(
                                        8,
                                      ),
                                   //   border: Border.all(color: Color(0xff3C2B99)),
                                    ),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Container(
                                          height: Get.height * 0.06,
                                          child: Image(
                                              image: AssetImage('assets/image1 1.png')),
                                        ),
                                        Text(
                                          'CONCEALED BOX',
                                          style: TextStyle(
                                            fontSize: 10,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: (){
                                  Get.to(allProduct());
                                },
                                child: Card(
                                  elevation: 1,
                                  child: Container(
                                    width: Get.width * 0.28,
                                    height: Get.height * 0.09,
                                    decoration: BoxDecoration(
                                      color: Color(0xffEEEEEE),
                                      borderRadius: BorderRadius.circular(
                                        8,
                                      ),
                                     // border: Border.all(color: Color(0xff3C2B99)),
                                    ),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Container(
                                          height: Get.height * 0.06,
                                          child: Image(
                                              image: AssetImage('assets/image 4.png')),
                                        ),
                                        Text(
                                          'FAN BOXS',
                                          style: TextStyle(
                                            fontSize: 10,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: (){
                                  Get.to(allProduct());
                                },
                                child: Card(elevation: 1,
                                  child: Container(
                                    width: Get.width * 0.28,
                                    height: Get.height * 0.09,
                                    decoration: BoxDecoration(
                                      color: Color(0xffEEEEEE),
                                      borderRadius: BorderRadius.circular(
                                        8,
                                      ),
                                    //  border: Border.all(color: Color(0xff3C2B99)),
                                    ),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Container(
                                          height: Get.height * 0.06,
                                          child: Image(
                                              image: AssetImage('assets/image1 1.png')),
                                        ),
                                        Text(
                                          'CONCEALED BOX',
                                          style: TextStyle(
                                            fontSize: 10,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: (){
                                  Get.to(allProduct());
                                },
                                child: Card(
                                  elevation: 1,
                                  child: Container(
                                    width: Get.width * 0.28,
                                    height: Get.height * 0.09,
                                    decoration: BoxDecoration(
                                      color: Color(0xffEEEEEE),
                                      borderRadius: BorderRadius.circular(
                                        8,
                                      ),
                                  //    border: Border.all(color: Color(0xff3C2B99)),
                                    ),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Container(
                                          height: Get.height * 0.06,
                                          child: Image(
                                              image: AssetImage('assets/image 4.png')),
                                        ),
                                        Text(
                                          'FAN BOXS',
                                          style: TextStyle(
                                            fontSize: 10,
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ).paddingOnly(
                            bottom: 10,
                          ),
                        ],
                      ),
                    ),
                    Container(
                      height: Get.height * 0.055,
                      child: blockButton(
                        callback: () {
                          Get.to(allProduct());
                        },
                        width: Get.width * 0.3,
                        widget: Text(
                          'See More',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              height: 1.2),
                        ),
                        verticalPadding: 3,
                      ),
                    ),

                    // blockButton(
                    //   callback: (){
                    //     Get.to(product_view());
                    //   },
                    //     width: Get.width * 0.35,
                    //     verticalPadding: 0,
                    //     widget: Text(
                    //       'See More',
                    //       style: TextStyle(color: Colors.white, fontSize: 15),
                    //     )).paddingOnly(
                    //   bottom: 20,
                    // )
                  ],
                ).paddingSymmetric(
                  horizontal: 18,
                  vertical:6,
                ),
                // SizedBox(height: 5,),
                // GradientText(
                //   gradient: appcolor.gradient,
                //   widget: Text(
                //     'Social Media',
                //     style: TextStyle(
                //         fontSize: 20,
                //         height: 1,color: appcolor.redColor,
                //     ),textAlign: TextAlign.left,
                //   ),
                // ).paddingSymmetric(
                //   horizontal: 20,
                // ),
                Padding(
                  padding: const EdgeInsets.only(left: 20,right: 20),
                  child: Container(
                    height: Get.height * 0.08,
                    width: Get.width,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      //     Text('Social Media',style: TextStyle(
                      //     fontSize: 20,
                      //     height: 1,color: appcolor.redColor
                      // )),
                          Padding(
                            padding: const EdgeInsets.all(2.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                SocialMedia(
                                  assetimagepath: 'assets/inst.png',
                                  callback: () {
                                    Get.to(socialMedia());
                                  },

                                ),
                                SizedBox(width: 8,),
                                SocialMedia(
                                  assetimagepath: 'assets/youtbe.png',
                                  callback: () {
                                    Get.to(socialMedia());
                                  },
                                ),
                                SizedBox(width: 8,),
                                SocialMedia(
                                  assetimagepath: 'assets/fb.png',
                                  callback: () {
                                    Get.to(socialMedia());
                                  },

                                ),
                                SizedBox(width: 8,),
                                SocialMedia(
                                  assetimagepath: 'assets/img_9.png',
                                  callback: () {
                                    Get.to(socialMedia());
                                  },
                                ),
                                SizedBox(width: 8,),
                                SocialMedia(
                                  assetimagepath: 'assets/img_8.png',
                                  callback: () {
                                    Get.to(socialMedia());
                                  },
                                ),


                              ],
                            ),
                          )
                        ],
                      ),
                    ),

                  ),
                )
              ],
            ),
          ),
        ),
      ),
      floatingActionButton:floatingActionButon(),


    );
  }
}

Widget customwidget({
  Function()? callback,
  String? assetimagepath,
  String? title,
}) {
  return InkWell(
    onTap: callback,
    child: Column(
      children: [
        Container(
          child: PhysicalShape(
            elevation: 1,
            clipper: ShapeBorderClipper(shape: CircleBorder()),
            color: Color(0xffEEEEEE),
            child: Container(
                height: 70,
                width: 100,
                child: Image.asset(assetimagepath.toString(),)
            ),
          ),
        ),
        SizedBox(height: 10,),

        GradientText(
          widget: Text(
            '$title',
            style: TextStyle(
              fontSize: 14,color: appcolor.redColor,
            ),
          ),
          gradient: appcolor.gradient,
        ),
      ],
    ),
  );
}
Widget SocialMedia({
  Function()? callback,
  String? assetimagepath,

}) {
  return InkWell(
    onTap: callback,
    child: Column(
      children: [

        CircleAvatar(
          radius: 22,
          backgroundColor: appcolor.greyColor,

          child:Center(child: Image.asset(assetimagepath.toString(),height: 20,width: 20,))
          ),


      ],
    ),
  );
}

