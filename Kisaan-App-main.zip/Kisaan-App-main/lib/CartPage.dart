import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:kisaan_electric/Orders/OrderPage.dart';
import 'package:kisaan_electric/global/appcolor.dart';

import 'global/blockButton.dart';

class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  int quantity = 1;
  int quantityy = 1;
  var image = 'assets/image 16.png';
  var Name = 'Double Door';
  var Price = 'Rs 128.0';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Color(0xffEEEEEE),
        title: Text('Cart', style: TextStyle(fontSize: 20,color: Colors.black),),
        automaticallyImplyLeading: false,
        leading:  IconButton(onPressed: (){
          Navigator.pop(context);
        }, icon:Icon(Icons.arrow_back_ios,color: Colors.red,)),
      ),
      body: Column(
        children: [
          Card(
            elevation: 4,
            color: Color(0xffEEEEEE),
            child: ListTile(
              leading: Container(
                  height: 50,
                  width: 50,
                  child: Image.asset(image,fit: BoxFit.cover,)),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text('Name: ',style: TextStyle(
                        fontSize: 14,
                        color: appcolor.redColor,
                        height: 0.9,
                      ),),
                      Text(Name,style: TextStyle(
                        fontSize: 14,
                        height: 0.9,
                      ),),
                    ],
                  ),
                  IconButton(onPressed: (){}, icon: Icon(Icons.delete,color: Colors.red,))
                ],
              ),

              subtitle:Column(
              mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text('Price: ',style: TextStyle(
                        fontSize: 14,
                        color: appcolor.redColor,
                        height: 0.9,
                      ),),
                      Text(Price,style: TextStyle(
                        fontSize: 14,
                        height: 0.9,
                      ),),
                    ],
                  ),
                  SizedBox(height: 5,),
                  Container(
                    height: 40,
                    width: 80,
                    decoration: BoxDecoration(
                        color: Colors.white, // Set your desired background color
                        borderRadius: BorderRadius.circular(5.0)),
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          GestureDetector(
                            onTap: (){
                              decrement();
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(right: 1.0),
                              child:Icon(Icons.remove,color: Colors.black,)
                            ),
                          ),
                          SizedBox(width: 2,),
                          Text(
                            '$quantity',
                            style: TextStyle(
                                fontSize: 20,
                                color: Colors.black,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(width: 2,),
                          GestureDetector(
                            onTap: (){
                              increment();
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(left: 3.0),
                              child: Icon(Icons.add,color: Colors.black,)
                            ),
                          )
                        ],
                      ),
                    ),
                  )

                ],
              ),
            ),
          ),
          Card(
            elevation: 4,
            color: Color(0xffEEEEEE),
            child: ListTile(
              leading: Container(
                  height: 50,
                  width: 50,
                  child: Image.asset(image,fit: BoxFit.cover,)),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text('Name: ',style: TextStyle(
                        fontSize: 14,
                        color: appcolor.redColor,
                        height: 0.9,
                      ),),
                      Text(Name,style: TextStyle(
                        fontSize: 14,
                        height: 0.9,
                      ),),
                    ],
                  ),
                  IconButton(onPressed: (){}, icon: Icon(Icons.delete,color: Colors.red,))
                ],
              ),

              subtitle:Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text('Price: ',style: TextStyle(
                        fontSize: 14,
                        color: appcolor.redColor,
                        height: 0.9,
                      ),),
                      Text(Price,style: TextStyle(
                        fontSize: 14,
                        height: 0.9,
                      ),),
                    ],
                  ),
                  SizedBox(height: 5,),
                  Container(
                    height: 40,
                    width: 80,
                    decoration: BoxDecoration(
                        color: Colors.white, // Set your desired background color
                        borderRadius: BorderRadius.circular(5.0)),
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          GestureDetector(
                            onTap: (){
                              decrementy();
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(right: 1.0),
                              child: Icon(Icons.remove, color: Colors.black,)
                            ),
                          ),
                          SizedBox(width: 2,),
                          Text(
                            '$quantityy',
                            style: TextStyle(
                                fontSize: 20,
                                color: Colors.black,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(width: 2,),
                          GestureDetector(
                            onTap: (){
                              incrementy();
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(left: 3.0),
                              child: Icon(Icons.add, color: Colors.black,)
                            ),
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          Spacer(),
          Container(
            decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                      blurRadius: 0,
                      spreadRadius: 0
                  )
                ],
                color: Color(0xffEEEEEE),
                borderRadius: BorderRadius.vertical(
                    top: Radius.elliptical(50,50)
                )
            ),
            height: Get.height * 0.2,
            width: Get.width,
            child: Column(
              children: [
                SizedBox(height: 5,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Text('SubTotal: ',style: TextStyle(color: appcolor.redColor,fontSize: 16),),
                    Text('Rs 256.0',style: TextStyle(fontSize: 16),)
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Text('Discount: ',style: TextStyle(color: appcolor.redColor,fontSize: 16),),
                    Text('Rs 40.0',style: TextStyle(fontSize: 16),)
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Text('Shipping: ',style: TextStyle(color: appcolor.redColor,fontSize: 16),),
                    Text('Rs 20.0',style: TextStyle(fontSize: 16),)
                  ],
                ),
                SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.only(right: 15,left: 15),
                  child: Container(height: 1,width: Get.width, color: Colors.black,),
                ),

                SizedBox(height: 20,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Column(
                      children: [
                        Text('Total',style: TextStyle(color: Colors.black,fontSize: 12),),
                        Text('₹236.0',style: TextStyle(color: Colors.red,fontSize: 20),)
                      ],
                    ),
                    Container(
                      height: Get.height * 0.055,
                      width: 128,
                      child: blockButton(
                        callback: () {
                          Get.to(OrderPage());
                        },
                        width: Get.width * 0.4,
                        widget: Text(
                          'Check Out',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              height: 1.2),
                        ),
                        verticalPadding: 3,
                      ),
                    ),
                  ],
                ),

              ],
            ),
          ),

        ],
      ),
    );
  }

  void increment() {
    setState(() {
      quantity +=1;
    }
    );
  }

  void decrement() {
    setState(() {
      if(quantity ==1){
        quantity ==1;
      }else{
        quantity -= 1;
      }
    });
  }
  void incrementy() {
    setState(() {
      quantityy +=1;
    }
    );
  }

  void decrementy() {
    setState(() {
      if(quantityy ==1){
        quantityy ==1;
      }else{
        quantityy -= 1;
      }
    });
  }
}
