import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';
import 'package:kisaan_electric/global/terms&Condition.dart';

import '../whatsaapIcon/WhatsaapIcon.dart';

class notifcation extends StatefulWidget {
  const notifcation({super.key});

  @override
  State<notifcation> createState() => _notifcation();
}

class _notifcation extends State<notifcation> {

  String text = 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s,';
 String Date = '14 Oct at 5:40';


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            color: Colors.white

          // image: DecorationImage(
          //     image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            automaticallyImplyLeading: false,
            title: customAppBar('Notification'),),
          backgroundColor: Colors.transparent,
          resizeToAvoidBottomInset: false,
          body: SingleChildScrollView(
            child: Column(
              children: [
             Padding(
               padding: const EdgeInsets.all(12.0),
               child: SingleChildScrollView(
                 child: Column(
                   children: [
                     Card(
                      color: Colors.grey[100],
                      elevation: 5,
                      child: ListTile(

                        title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                        subtitle: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(Date,style: TextStyle(fontSize: 12,color: appcolor.redColor),),
                          ],
                        ),
                      ),
                       ),
                     SizedBox(height: 5,),
                     Card(
                       color: Colors.grey[100],
                       elevation: 5,
                       child: ListTile(

                         title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                         subtitle: Row(
                           mainAxisAlignment: MainAxisAlignment.end,
                           children: [
                             Text(Date,style: TextStyle(fontSize: 12,color: appcolor.redColor),),
                           ],
                         ),
                       ),
                     ),
                     SizedBox(height: 5,),
                     Card(
                       color: Colors.grey[100],
                       elevation: 5,
                       child: ListTile(

                         title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                         subtitle: Row(
                           mainAxisAlignment: MainAxisAlignment.end,
                           children: [
                             Text(Date,style: TextStyle(fontSize: 12,color: appcolor.redColor),),
                           ],
                         ),
                       ),
                     ),
                     SizedBox(height: 5,),
                     Card(
                       color: Colors.grey[100],
                       elevation: 5,
                       child: ListTile(

                      title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                      subtitle: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(Date,style: TextStyle(fontSize: 12,color: appcolor.redColor),),
                        ],
                      ),
                       ),
                     ),
                     SizedBox(height: 5,),
                     Card(
                       color: Colors.grey[100],
                       elevation: 5,
                       child: ListTile(

                      title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                      subtitle: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(Date,style: TextStyle(fontSize: 12,color: appcolor.redColor),),
                        ],
                      ),
                       ),
                     ),
                     SizedBox(height: 5,),
                     Card(
                       color: Colors.grey[100],
                       elevation: 5,
                       child: ListTile(

                      title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                      subtitle: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(Date,style: TextStyle(fontSize: 12,color: appcolor.redColor),),
                        ],
                      ),
                       ),
                     ),
                     SizedBox(height: 5,),
                     Card(
                       color: Colors.grey[100],
                       elevation: 5,
                       child: ListTile(

                      title: Text(text,style: TextStyle(fontSize: 12,)    ,),
                      subtitle: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(Date,style: TextStyle(fontSize: 12,color: appcolor.redColor),),
                        ],
                      ),
                       ),
                     ),
                     SizedBox(height: 5,),
                   ],
                 ),
               )
    )
              ],
            ),
          ),
          floatingActionButton:floatingActionButon(),
        ),
      ),
    );
  }
}
