import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';

import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';
import '../products/controller/product_controller.dart';

class ranking extends StatefulWidget {
  const ranking({super.key});

  @override
  State<ranking> createState() => _rankingState();
}

class _rankingState extends State<ranking> {
  productController controller = Get.put(productController());
  late StreamSubscription subscription;
  bool isDeviceConnected = false;
  bool isAlertSet = false;
  getConnectivity() =>
      subscription = Connectivity().onConnectivityChanged.listen(
            (ConnectivityResult result) async {
          isDeviceConnected = await InternetConnectionChecker().hasConnection;
          if (!isDeviceConnected && isAlertSet == false) {
            showDialogBox();
            setState(() => isAlertSet = true);
          }
        },
      );
  showDialogBox() => showCupertinoDialog<String>(
    context: context,
    builder: (BuildContext context) => CupertinoAlertDialog(
      title: const Text('No Connection'),
      content: const Text('Please check your internet connectivity'),
      actions: <Widget>[
        TextButton(
          onPressed: () async {
            Navigator.pop(context, 'Cancel');
            setState(() => isAlertSet = false);
            isDeviceConnected =
            await InternetConnectionChecker().hasConnection;
            if (!isDeviceConnected && isAlertSet == false) {
              showDialogBox();
              setState(() => isAlertSet = true);
            }
          },
          child: const Text('OK'),
        ),
      ],
    ),
  );
  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
          color: Colors.white
        ),
        child: Scaffold(
          resizeToAvoidBottomInset: false,
          backgroundColor: Colors.transparent,
          body: Column(
            children: [
              customAppBar('Ranking',''),
              Container(
                height: 1,
                width: Get.width,
                color: appcolor.borderColor,
              ),
              Container(
                child: Image(image: AssetImage('assets/image 28.png')),
              ),
              Container(
                decoration: BoxDecoration(),
                height: Get.height * 0.08,
                child: TabBar(
                  dividerColor: appcolor.newRedColor,
                  unselectedLabelColor: Colors.black,
                  unselectedLabelStyle: TextStyle(
                    fontSize: 16,
                  ),
                  indicatorColor: appcolor.redColor,
                  labelColor: Colors.black,
                  labelStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    fontSize: 18,
                  ),
                  controller: controller.tabcontroller,
                  tabs: [
                    Container(
                      child: Text(
                        'Electrician'.tr,
                      ),
                    ),
                    Container(
                      child: Text('Partner'.tr),
                    ),
                    Text('Dealer'.tr),
                  ],
                ),
              ),
              Expanded(
                child:
                    TabBarView(controller: controller.tabcontroller, children: [
                  Transition(),
                  Transition(),
                  Transition(),
                ]),
              )
            ],
          ),
        ),
      ),
    );
  }



  Widget Transition() {
    DateTime  dateTime = DateTime.now();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 10,
        ),
        Text(
          'Date:- ${dateTime.day}-${dateTime.month}-${dateTime.year}',
          style: TextStyle(
            fontSize: 22,
          ),
        ),
        Container(
          height: Get.height * 0.53,
          width: Get.width,
          child: Table(
              border: TableBorder.all(),
              children: [
                TableRow(
                    decoration: BoxDecoration(
                        color: Colors.grey[300]
                    ),
                    children :[
                      Text('Rank',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
                      Text('CODE',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
                      Text('Name',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
                      Text('Points',style: TextStyle(fontSize: 12,),textAlign:TextAlign.center),
                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),

                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),

                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),
                TableRow(
                    children :[
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),
                      SizedBox(
                        height: 30,
                        child: TextFormField(
                          cursorColor: Colors.black,
                          cursorHeight: 25,
                          decoration: InputDecoration(
                            border: InputBorder.none,

                          ),
                          keyboardType: TextInputType.visiblePassword,

                        ),
                      ),

                    ]),


              ]
          ),
        ),
      ],
    ).paddingSymmetric(
      horizontal: 10,
    );
  }


}
