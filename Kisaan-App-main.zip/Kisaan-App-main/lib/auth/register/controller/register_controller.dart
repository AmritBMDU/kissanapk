import 'package:get/get.dart';

class registerController extends GetxController{

  RxString groupValue = 'electrician'.obs;
   RxBool showPassword=false.obs;
}