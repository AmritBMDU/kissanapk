import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';
import 'package:http/http.dart';
import 'package:kisaan_electric/auth/login/view/login_view.dart';
import 'package:kisaan_electric/auth/register/controller/register_controller.dart';
import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';
import 'package:kisaan_electric/home/view/home_view.dart';
import 'package:http/http.dart' as http;
import 'package:kisaan_electric/server/apiDomain.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../AlertDialogBox/alertBoxContent.dart';

class register_view extends StatefulWidget {
  const  register_view({super.key});

  @override
  State<register_view> createState() => _register_viewState();
}

class _register_viewState extends State<register_view> {
  TextEditingController name = TextEditingController();
  TextEditingController mobileNo = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController bussinessName = TextEditingController();
  TextEditingController dealerPartnerCin= TextEditingController();
  bool isSelected = false;
  registerController controller = Get.put(registerController());
  var value = null;
  bool isLoading = false;
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    Color getColor(Set<MaterialState> states) {
      const Set<MaterialState> interactiveStates = <MaterialState>{
        MaterialState.pressed,
        MaterialState.hovered,
        MaterialState.focused,
      };
      if (states.any(interactiveStates.contains)) {
        return Colors.blue;
      }
      return Colors.red;
    }
    return SafeArea(
      child: Stack(
        children: [
         Container(
          height: Get.height,
          width: Get.width,
          decoration: BoxDecoration(
            color: Colors.white
            // image: DecorationImage(
            //     image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
          ),
          child: Scaffold(
            backgroundColor: Colors.transparent,
            resizeToAvoidBottomInset: false,
            body: Form(
              key: _formKey,
              child: Column(
                children: [
                  SizedBox(
                       height: Get.height * 0.08,
                      ),
                  Container(
                    child: GradientText(
                      gradient: appcolor.gradient,
                      widget: Text(
                        'Sign Up',
                        style:
                            TextStyle(fontSize: 30, fontWeight: FontWeight.bold,color: appcolor.redColor),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    height: Get.height * 0.055,
                    child: customtextformfield(
                      controller: name,
                      label: '*',
                      bottomLineColor: Color(0xffb8b8b8),
                      hinttext: 'Name',
                      suffixIcon: Icon(Icons.person),
                      newIcon: Icon(Icons.person,color: appcolor.SufixIconColor),
                      // border: InputBorder.none,
                     key_type: TextInputType.visiblePassword,
                    ),
                  ),
                  Container(
                    height: Get.height * 0.055,
                    child:

                    customtextformfield(
                      controller: mobileNo,
                      label: '*',
                      bottomLineColor: Color(0xffb8b8b8),
                      hinttext: 'Mobile Number',
                      suffixIcon: Icon(Icons.call,),
                      newIcon: Icon(Icons.call,color: appcolor.SufixIconColor),
                      key_type: TextInputType.phone,
                      maxLength: 10,
                    ),
                  ),
                  Container(
                    height: Get.height * 0.055,
                    child: customtextformfield(
                      controller: password,
                      label: '*',
                      bottomLineColor: Color(0xffb8b8b8),
                      hinttext: 'Create Password',
                      suffixIcon: Icon(Icons.lock_open),
                      showPassword: controller.showPassword.value,
                      callback: () {
                        controller.showPassword.value =
                        !controller.showPassword.value;
                        setState(() {});
                      },
                      newIcon: Icon(
                        Icons.lock,color: Colors.red,
                      ),
                      key_type: TextInputType.visiblePassword,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      GradientText(
                        gradient: appcolor.gradient,
                        widget: Text(
                          'Your Profession',
                          style: TextStyle(
                            fontSize: 18,color: appcolor.redColor
                          ),
                        ),
                      ),
                    ],
                  ).paddingSymmetric(horizontal: 10),
                  SizedBox(height: 8,),
                  Obx(
                    () => Container(
                      height: Get.height * 0.03,
                      child: Row(
                        children: [
                          Radio(
                            value: 'electrician',
                            groupValue: controller.groupValue.value,
                            onChanged: (val) {
                              controller.groupValue.value = val.toString();
                            },
                            fillColor: MaterialStateColor.resolveWith(
                              (states) => appcolor.mixColor,
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              setState(() {
                                controller.groupValue.value = 'electrician';
                              });

                            },
                            child: Text(
                              'Electrician',
                              style: TextStyle(
                                fontSize: 15,
                              ),
                            ),
                          ),
                          Radio(
                            value: 'dealer',
                            groupValue: controller.groupValue.value,
                            onChanged: (val) {
                              setState(() {
                                controller.groupValue.value = val.toString();
                              });

                            },
                            fillColor: MaterialStateColor.resolveWith(
                              (states) => appcolor.mixColor,
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              setState(() {
                                controller.groupValue.value = 'dealer';

                              });
                            },
                            child: Text(
                              'Dealer',
                              style: TextStyle(
                                fontSize: 15,
                              ),
                            ),
                          ),
                          Radio(
                            value: 'partner',
                            groupValue: controller.groupValue.value,
                            onChanged: (val) {
                              controller.groupValue.value = val.toString();
                            },
                            fillColor: MaterialStateColor.resolveWith(
                              (states) => appcolor.mixColor,
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              setState(() {
                                controller.groupValue.value = 'partner';
                              });
                            },
                            child: Text(
                              'Partner',
                              style: TextStyle(
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 8,),

                  Obx(
                    () => customwidget(controller.groupValue.value,bussinessName, dealerPartnerCin, ),
                  ),
                  Row(
                    children: [
                      Checkbox(
                        checkColor: Colors.white,
                        // fillColor: Colors.red,
                        value: isSelected,
                        onChanged: (bool? value) {
                          setState(() {
                            isSelected = value!;
                          });
                        },
                      ),
                      Row(
                        children: [
                          Text('I Agree'),
                          TextButton(onPressed: (){
                            showDialog(context: context, builder: (context){
                              return AlertDialog(

                                content: FutureBuilder(
                                  future: termscondition(),
                                  builder: (context, snapshot){
                                    if(snapshot.connectionState == ConnectionState.waiting){
                                      return Center(child: CircularProgressIndicator(),);
                                    }else if(snapshot.hasError){
                                      return Center( child: Text('data not found'),);
                                    }else if(snapshot.hasData){
                                      return SingleChildScrollView(
                                        child: Padding(
                                          padding: const EdgeInsets.only(left: 0,right: 0),
                                          child: Html(
                                            data: """${snapshot.data['data']}""",
                                          ),
                                        ),
                                      );

                                    }else{
                                      return Center(child: CircularProgressIndicator(),);
                                    }
                                  },
                                ).paddingSymmetric(
                                  horizontal: 2,
                                ),
                                actions: [
                                  Container(
                                    height: Get.height * 0.055,
                                    child: blockButton(
                                      callback: () {
                                        setState(() {
                                          isSelected =true;
                                        });
                                        Get.back();
                                      },
                                      width: Get.width * 0.9,
                                      widget: Text(
                                        'Ok',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                            height: 1.2),
                                      ),
                                      verticalPadding: 3,
                                    ),
                                  ),
                                ],
                              );
                            });
                          }, child: Text('Term & Condition'), )

                        ],
                      )
                    ],
                  ),
                  Container(
                    height: Get.height * 0.055,
                    child: blockButton(
                      callback: () {
                        // makePostRequest();
                        var Name = name.text.trim().toString();
                        var Password = password.text.trim().toString();
                        var MobileNo = mobileNo.text.trim();
                        var BussinessName = bussinessName.text.trim().toString();
                        var cin = dealerPartnerCin.text.trim();
                        if(Name == '' && Password == '' && MobileNo == ''){
                        return  alertBoxdialogBox(context,'Alert','Please fill Field');
                        } else if(MobileNo.length < 10){
                          alertBoxdialogBox(context, 'Alert', 'The Mobile Number Must be 10 Digits.' );

                        }
                        // else if(BussinessName == ''){
                        //   alertBoxdialogBox(context, 'Alert', 'Enter Bussiness Name' );
                        //
                        // }

                        else if(Name != '' && Password != '' && MobileNo != ''){
                          var value = {
                            "name":Name,
                            "password":Password,
                            "mobile_no":MobileNo,
                            "profession":controller.groupValue.value,
                            "business_name":BussinessName,
                            "identification_id":cin
                          };
                          if(isSelected == false){
                            return  alertBoxdialogBox(context,'Alert','Please agree term and condition');
                          }else{
                            setState(() {
                              isLoading =true;
                            });
                            Future.delayed(Duration(seconds: 3),(){
                              setState(() {
                                isLoading = false;
                              });
                            });
                            registration(value);
                          }
                        }
                        // Get.to(Home_view());
                      },
                      width: Get.width * 0.35,
                      widget: isLoading?SizedBox(
                          height: 10,
                          width: 10,
                          child: CircularProgressIndicator(color: Colors.white,)):Text(
                        'Sign Up',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            height: 1.2),
                      ),
                      verticalPadding: 3,
                    ),
                  ),
                   SizedBox(
                      height: Get.height * 0.01,
                      ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        child:  GradientText(
                          widget: Text(
                              'Have Kisaan account? ',
                              style: TextStyle(
                                fontSize: 15,color: Colors.black
                              ),
                            ), gradient: appcolor.gradient,
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          Get.offAll(login_view());
                        },
                        child: Stack(
                          children: [
                            Container(
                              child: GradientText(
                                widget: Text(
                                  'Login',
                                  style: TextStyle(
                                    height: 1,
                                    fontSize: 15,color: appcolor.redColor,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                gradient: appcolor.gradient,
                              ),
                            ),
                            Column(
                              children: [
                                SizedBox(
                                  height: 18,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                      height: Get.height * 0.03,
                      ),
                  Container(
                     height: Get.height * 0.25,
                    child: Image(
                      image: AssetImage(
                        'assets/imgpsh_fullsize_anim 1.png',
                      ),
                      fit: BoxFit.fill,
                    ),
                  ),
                ],
              ).paddingSymmetric(horizontal: 15, vertical: 15),
            ),
          ),
        ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 130,
                width: 140,
                decoration: BoxDecoration(
                    color: appcolor.redColor,
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(300),
                        topLeft: Radius.circular(2)
                    )
                ),
              ),
            ],
          )
      ]
      ),
    );
  }
  Future registration(Object value)async{
    //final SharedPreferences prefs = await SharedPreferences.getInstance();
    final response = await http.post(Uri.parse('${apiDomain().domain}register'),body: jsonEncode(value),
        headers: ({
          'Content-Type': 'application/json; charset=UTF-8'
        }));
    print(response.body);
       if(response.statusCode == 200){
        final data = jsonDecode(response.body);
        if(data['success'] == true){
          var Token = data['data']['token'];
           Get.offAll(login_view());
           ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${data['message']}')));
          // prefs.setString('token', Token);
        }else if(data['success'] == false) {
          alertBoxdialogBox(context, 'Alert', '${data['message']}');
        }else{
          alertBoxdialogBox(context, 'Alert', '${data['message']}');
        }
    }
  }
  Future termscondition()async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');

    final response = await http.post(Uri.parse('${apiDomain().domain}term_conditions'),
    );
    if(response.statusCode == 200){
      final data = jsonDecode(response.body);
      return data;
    }
  }

}

Widget customwidget(String type, TextEditingController bussinessName,  TextEditingController dealerPartnerCin,) {
  //electric
  if (type == 'electrician') {
    return Container(
      height: Get.height * 0.055,
      child: customtextformfield(
        controller: dealerPartnerCin,
        hinttext: 'Dealer/Partner CIN',bottomLineColor: Color(0xffb8b8b8),
        key_type: TextInputType.visiblePassword,),
    );
  } else if (type == 'dealer') {
    return Container(
      child: Column(
        children: [
          Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: bussinessName,
                hinttext: 'Business Name',bottomLineColor: Color(0xffb8b8b8),
                key_type: TextInputType.visiblePassword,
              )),
          Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: dealerPartnerCin,
                hinttext: 'Partner CIN',bottomLineColor: Color(0xffb8b8b8),
                key_type: TextInputType.visiblePassword,
              )),
        ],
      ),
    );
  } else {
    return Container(
      height: Get.height * 0.055,
      child: customtextformfield(
        controller: bussinessName,
        hinttext: 'Business Name',bottomLineColor: Color(0xffb8b8b8),
        key_type: TextInputType.visiblePassword,),
    );
  }
}

