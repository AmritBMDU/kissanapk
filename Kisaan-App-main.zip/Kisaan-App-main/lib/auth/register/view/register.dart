import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kisaan_electric/auth/login/view/login_view.dart';
import 'package:kisaan_electric/auth/register/controller/register_controller.dart';
import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';
import 'package:kisaan_electric/home/view/home_view.dart';

class register_view extends StatefulWidget {
  const  register_view({super.key});

  @override
  State<register_view> createState() => _register_viewState();
}

class _register_viewState extends State<register_view> {
  bool isSelected = false;
  registerController controller = Get.put(registerController());
  @override
  Widget build(BuildContext context) {
    Color getColor(Set<MaterialState> states) {
      const Set<MaterialState> interactiveStates = <MaterialState>{
        MaterialState.pressed,
        MaterialState.hovered,
        MaterialState.focused,
      };
      if (states.any(interactiveStates.contains)) {
        return Colors.blue;
      }
      return Colors.red;
    }
    return SafeArea(
      child: Stack(
        children: [
         Container(
          height: Get.height,
          width: Get.width,
          decoration: BoxDecoration(
            color: Colors.white
            // image: DecorationImage(
            //     image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
          ),
          child: Scaffold(
            backgroundColor: Colors.transparent,
            resizeToAvoidBottomInset: false,
            body: Column(
              children: [
                SizedBox(
                     height: Get.height * 0.08,
                    ),
                Container(
                  child: GradientText(
                    gradient: appcolor.gradient,
                    widget: Text(
                      'Sign Up',
                      style:
                          TextStyle(fontSize: 30, fontWeight: FontWeight.bold,color: appcolor.redColor),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  height: Get.height * 0.055,
                  child: customtextformfield(
                    label: '*',
                    bottomLineColor: Color(0xffb8b8b8),
                    hinttext: 'Name',
                    suffixIcon: Icon(Icons.person),
                    newIcon: Icon(Icons.person,color: appcolor.SufixIconColor),
                    // border: InputBorder.none,
                   key_type: TextInputType.visiblePassword,
                  ),
                ),
                Container(
                  height: Get.height * 0.055,
                  child:


                  customtextformfield(
                    label: '*',
                    bottomLineColor: Color(0xffb8b8b8),
                    hinttext: 'Mobile Number',
                    suffixIcon: Icon(Icons.call,),
                    newIcon: Icon(Icons.call,color: appcolor.SufixIconColor),
                    key_type: TextInputType.phone,
                    maxLength: 10,
                  ),
                ),
                Container(
                  height: Get.height * 0.055,
                  child: customtextformfield(
                    label: '*',
                    bottomLineColor: Color(0xffb8b8b8),
                    hinttext: 'Create Password',
                    suffixIcon: Icon(Icons.lock_open),
                    newIcon: Icon(
                      Icons.lock,color: Colors.red,
                    ),
                    key_type: TextInputType.visiblePassword,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    GradientText(
                      gradient: appcolor.gradient,
                      widget: Text(
                        'Your Profession',
                        style: TextStyle(
                          fontSize: 18,color: appcolor.redColor
                        ),
                      ),
                    ),
                  ],
                ).paddingSymmetric(horizontal: 10),
                SizedBox(height: 8,),
                Obx(
                  () => Container(
                    height: Get.height * 0.03,
                    child: Row(
                      children: [
                        Radio(
                          value: '1',
                          groupValue: controller.groupValue.value,
                          onChanged: (val) {
                            controller.groupValue.value = val.toString();
                          },
                          fillColor: MaterialStateColor.resolveWith(
                            (states) => appcolor.mixColor,
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            controller.groupValue.value = '1';
                          },
                          child: Text(
                            'Electrician',
                            style: TextStyle(
                              fontSize: 15,
                            ),
                          ),
                        ),
                        Radio(
                          value: '2',
                          groupValue: controller.groupValue.value,
                          onChanged: (val) {
                            controller.groupValue.value = val.toString();
                          },
                          fillColor: MaterialStateColor.resolveWith(
                            (states) => appcolor.mixColor,
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            controller.groupValue.value = '2';
                          },
                          child: Text(
                            'Dealer',
                            style: TextStyle(
                              fontSize: 15,
                            ),
                          ),
                        ),
                        Radio(
                          value: '3',
                          groupValue: controller.groupValue.value,
                          onChanged: (val) {
                            controller.groupValue.value = val.toString();
                          },
                          fillColor: MaterialStateColor.resolveWith(
                            (states) => appcolor.mixColor,
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            controller.groupValue.value = '3';
                          },
                          child: Text(
                            'Partner',
                            style: TextStyle(
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 8,),

                Obx(
                  () => customwidget(controller.groupValue.value),
                ),
                Row(
                  children: [
                    Checkbox(
                      checkColor: Colors.white,
                      // fillColor: Colors.red,
                      value: isSelected,
                      onChanged: (bool? value) {
                        setState(() {
                          isSelected = value!;
                        });
                      },
                    ),
                    Text('Term & Condition')
                  ],
                ),
                Container(
                  height: Get.height * 0.055,
                  child: blockButton(
                    callback: () {
                      Get.to(Home_view());
                    },
                    width: Get.width * 0.35,
                    widget: Text(
                      'Sign Up',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          height: 1.2),
                    ),
                    verticalPadding: 3,
                  ),
                ),
                 SizedBox(
                    height: Get.height * 0.01,
                    ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      child:  GradientText(
                        widget: Text(
                            'Have Kisaan account? ',
                            style: TextStyle(
                              fontSize: 15,color: Colors.black
                            ),
                          ), gradient: appcolor.gradient,
                      ),

                    ),
                    InkWell(
                      onTap: () {
                        Get.offAll(login_view());
                      },
                      child: Stack(
                        children: [
                          Container(
                            child: GradientText(
                              widget: Text(
                                'Login',
                                style: TextStyle(
                                  height: 1,
                                  fontSize: 15,color: appcolor.redColor,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              gradient: appcolor.gradient,
                            ),
                          ),
                          Column(
                            children: [
                              SizedBox(
                                height: 18,
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(
                    height: Get.height * 0.03,
                    ),
                Container(
                   height: Get.height * 0.25,
                  child: Image(
                    image: AssetImage(
                      'assets/imgpsh_fullsize_anim 1.png',
                    ),
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ).paddingSymmetric(horizontal: 15, vertical: 15),
          ),
        ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 130,
                width: 140,
                decoration: BoxDecoration(
                    color: appcolor.redColor,
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(300),
                        topLeft: Radius.circular(2)
                    )
                ),
              ),
            ],
          )
      ]
      ),
    );
  }
}

Widget customwidget(String type) {
  //electric
  if (type == '1') {
    return Container(
      height: Get.height * 0.055,
      child: customtextformfield(hinttext: 'Dealer/Partner CIN',bottomLineColor: Color(0xffb8b8b8),
        key_type: TextInputType.visiblePassword,),
    );
  } else if (type == '2') {
    return Container(
      child: Column(
        children: [
          Container(
              height: Get.height * 0.055,
              child: customtextformfield(hinttext: 'Business Name',bottomLineColor: Color(0xffb8b8b8),
                key_type: TextInputType.visiblePassword,
              )),

          Container(
              height: Get.height * 0.055,
              child: customtextformfield(hinttext: 'Partner CIN',bottomLineColor: Color(0xffb8b8b8),
                key_type: TextInputType.visiblePassword,
              )),
        ],
      ),
    );
  } else {
    return Container(
      height: Get.height * 0.055,
      child: customtextformfield(hinttext: 'Business Name',bottomLineColor: Color(0xffb8b8b8),
        key_type: TextInputType.visiblePassword,),
    );
  }
}
