import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kisaan_electric/auth/forgetPassword_view.dart';
import 'package:kisaan_electric/auth/login/controller/login_controller.dart';
import 'package:kisaan_electric/auth/register/view/register.dart';
import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';
import 'package:kisaan_electric/home/view/home_view.dart';

class login_view extends StatefulWidget {
  const login_view({super.key});

  @override
  State<login_view> createState() => _login_viewState();
}

class _login_viewState extends State<login_view> {
    login_controller controller = Get.put(login_controller());
  var value = null;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Stack(
        children: [
         Container(
          height: Get.height,
          width: Get.width,
          decoration: BoxDecoration(
            color: Colors.white,
          //   image: DecorationImage(
          //       image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
          ),
          child: Scaffold(
            backgroundColor: Colors.transparent,
            resizeToAvoidBottomInset: false,
            body: Column(
              children: [
                SizedBox(
                  height: Get.height *0.1,
                ),
                Container(
                  child: GradientText(
                    gradient: appcolor.gradient,
                    widget: Text(
                      'Login',
                      style:
                          TextStyle(fontSize: 30, fontWeight: FontWeight.bold,color: appcolor.redColor),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  height: Get.height * 0.055,
                  child: customtextformfield(
                    bottomLineColor: Color(0xffb8b8b8),
                    hinttext: 'Mobile Number',
                    suffixIcon: Icon(Icons.call),
                    newIcon: Icon(Icons.call,color: appcolor.SufixIconColor,),
                    key_type: TextInputType.phone,
                    maxLength: 10,
                  ),
                ),
                Container(
                  height: Get.height * 0.055,
                  child: customtextformfield(
                      hinttext: 'Password',
                      bottomLineColor: Color(0xffb8b8b8),
                      suffixIcon: Icon(Icons.lock),
                      newIcon: Icon(
                        Icons.lock_open,color: appcolor.SufixIconColor,
                      ),
                      showPassword: controller.showPassword.value,
                      key_type: TextInputType.visiblePassword,
                      callback: () {
                        controller.showPassword.value =
                            !controller.showPassword.value;

                        setState(() {});
                      }),
                ),
                Container(
                  height: Get.height * 0.055,
                  child: blockButton(
                    callback: () {
                      Get.to(Home_view());
                    },
                    width: Get.width * 0.3,
                    widget: Text(
                      'Login',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          height: 1.2),
                    ),
                    verticalPadding: 3,
                  ),
                ),
                InkWell(
                  onTap: () {
                    Get.to(forgotPassword_view());
                  },
                  child: Container(
                    child: GradientText(
                      widget: Text(
                        'Forget Password?',
                        style: TextStyle(
                          fontSize: 15,color: appcolor.redColor
                        ),
                      ),
                      gradient: appcolor.gradient,
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      child:  GradientText(
                        gradient: appcolor.gradient,
                        widget: Text(
                            'Don\'t have any account? ',
                            style: TextStyle(
                              fontSize: 15,
                            ),
                          ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Get.off(register_view());
                      },
                      child: Stack(
                        children: [
                          Container(
                            child: GradientText(
                              widget: Text(
                                'SignUp',
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,color: appcolor.redColor
                                ),
                              ),
                              gradient: appcolor.gradient,
                            ),
                          ),
                          Column(
                            children: [
                              SizedBox(
                                height: 20,
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: Get.height * 0.038,
                ),
                Container(
                  child: Image(
                    image: AssetImage(
                      'assets/login 1.png',
                    ),
                  ),
                ),
                SizedBox(height: 50,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Helpline No:- ',style: TextStyle(color: appcolor.redColor),),
                    Text('+91 9823564784')
                  ],
                ),
                Text('Terms & Condition ',style: TextStyle(color: appcolor.redColor),),


              ],
            ).paddingSymmetric(horizontal: 15, vertical: 15),
          ),
        ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Material(
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(300),
                    topLeft: Radius.circular(2)
                ),
                child: Container(
                  height: 130,
                  width: 140,
                  decoration: BoxDecoration(
                      color: appcolor.redColor,
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(300),
                          topLeft: Radius.circular(2)
                      )
                  ),
                  child:  Padding(
                    padding: const EdgeInsets.only(top: 30,left: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.all(2

                          ),
                          width: Get.width * 0.3,
                          height: Get.height * 0.035,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color:Colors.white
                            ),
                          ),
                          child: DropdownButtonFormField(
                            decoration: InputDecoration.collapsed(
                              hintText: 'Language',
                              hintStyle: TextStyle(
                                color: Colors.black,
                                fontSize: 13,
                                height: 1,
                              ),
                            ),
                            value: value,
                            onChanged: (value) {},
                            items: [
                              DropdownMenuItem(
                                child: Text(
                                  'English',
                                  style: TextStyle(
                                    fontSize: 13
                                  ),
                                ),
                                value: 1,
                              ),
                              DropdownMenuItem(
                                  child: Text(
                                    'Hindi',
                                    style: TextStyle(
                                      fontSize: 13,
                                    ),
                                  ),
                                  value: 2),
                              DropdownMenuItem(
                                  child: Text(
                                    'Punjabi',
                                    style: TextStyle(
                                      fontSize: 13,
                                    ),
                                  ),
                                  value: 3),
                              DropdownMenuItem(
                                  child: Text(
                                    'Gujrati',
                                    style: TextStyle(
                                      fontSize: 13,
                                    ),
                                  ),
                                  value: 4),
                              DropdownMenuItem(
                                  child: Text(
                                    'Marathi',
                                    style: TextStyle(
                                      fontSize: 13,
                                    ),
                                  ),
                                  value: 5),
                              DropdownMenuItem(
                                  child: Text(
                                    'Odia',
                                    style: TextStyle(
                                      fontSize: 13,
                                    ),
                                  ),
                                  value: 6),
                              DropdownMenuItem(
                                  child: Text(
                                    'Nepali',
                                    style: TextStyle(
                                      fontSize: 13,
                                    ),
                                  ),
                                  value: 7),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          )
      ]
      ),
    );
  }
}
