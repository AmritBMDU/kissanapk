import 'package:get/get.dart';

class  login_controller extends GetxController{

  RxBool showPassword=false.obs;
}