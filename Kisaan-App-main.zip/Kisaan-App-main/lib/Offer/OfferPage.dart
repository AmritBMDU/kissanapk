import 'dart:convert';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart'as http;
import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../whatsaapIcon/WhatsaapIcon.dart';
import '../AlertDialogBox/alertBoxContent.dart';
import '../server/apiDomain.dart';

class OfferPage extends StatefulWidget {
  const OfferPage({super.key});

  @override
  State<OfferPage> createState() => _OfferPage();
}

class _OfferPage extends State<OfferPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            color: Colors.white
          // image: DecorationImage(
          //   image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Column(
            children: [
              customAppBar('Offers'),
              Container(
                height: 1,
                width: Get.width,
                color: appcolor.borderColor,
              ),
              SizedBox(
                height: 20,
              ),

              CarouselSlider(
                options: CarouselOptions(
                    autoPlay: true,
                    enlargeCenterPage: true,
                    viewportFraction: 1,
                    aspectRatio: 2.0,
                    initialPage: 1,
                    height: 100
                ),
                //carouselController: buttonCarouselController,
                items: [ 'assets/image 1.png', 'assets/image 1.png', 'assets/image 1.png'].map((i) {
                  return Builder(
                    builder: (BuildContext context) {
                      return Container(
                          width: Get.width,
                          // height: Get.height* 0.1,
                          child:Image.asset(i,fit: BoxFit.cover,)
                      );
                    },
                  );
                }).toList(),
              ),
              Expanded(
                child: FutureBuilder(
                    future: Schems(),
                    builder: (context, snapshot){
                      if(snapshot.hasError){
                        return Center(child: Image.asset('assets/img_15.png'),);
                      }else if(snapshot.connectionState == ConnectionState.waiting){
                        return Center(child: CircularProgressIndicator(),);
                      }else if(snapshot.hasData){
                        var points= snapshot.data;
                        return ListView.builder(
                            itemCount: points.length,
                            itemBuilder: (context, index){
                              final data  = snapshot.data[index];
                              return Card(
                                child: ListTile(
                                  title: Text('${data['title']}'),
                                  subtitle: Text('${data['point']}'),
                                  leading: Image.network('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlC7Ov5Xn8LBou-KHW9phWsWSQsa70Yec_js6FZEKM&s'),
                                  trailing: blockButton(
                                      callback: (){
                                        alertBoxdialogBox(context, 'Congratuation', 'Reedem Sechems Successful');
                                      },
                                      widget: Text('Reedem',style: TextStyle(color: Colors.white),)
                                  ),
                                ),
                              );
                            });
                      }else{
                        return Center(child: CircularProgressIndicator(),);
                      }
                    }),
              ),

            ],
          ),
          floatingActionButton:floatingActionButon(context),
        ),
      ),
    );
  }
  Future Schems()async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');
    final response = await http.post(Uri.parse('${apiDomain().domain}scheme'),
        headers: ({
          'Content-Type': 'application/json; charset=UTF-8',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token'
        }));
    if(response.statusCode == 200){
      final data = jsonDecode(response.body);
      final point = data['point'];
      prefs.setInt('point', point);
      print(point);
      final dataa = data['scheme']['data'];
      print(dataa);
      return dataa;
    }
  }
}
