import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:kisaan_electric/global/gradient_text.dart';
import 'package:kisaan_electric/wallet/view/redemption_view.dart';
import 'package:kisaan_electric/wallet/view/tds_certificate_view.dart';
import 'package:marquee/marquee.dart';
import '../../whatsaapIcon/WhatsaapIcon.dart';

class wallet_view extends StatefulWidget {
  const wallet_view({super.key});

  @override
  State<wallet_view> createState() => _wallet_viewState();
}

class _wallet_viewState extends State<wallet_view> {
  var value = null;
  RxBool showContainer = false.obs;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
          color: Colors.white
          // image: DecorationImage(
          //     image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            automaticallyImplyLeading: false,
            title: customAppBar('My Wallet'),),
          backgroundColor: Colors.transparent,
          body: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.only(bottom: 15),
                  height: Get.height * 0.04,
                  width: Get.width,
                  color: appcolor.newRedColor,
                  child:Marquee(
                    text: 'Approval pending with Kisaan Electric ', style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                  ),

                    scrollAxis: Axis.horizontal,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    blankSpace: 20.0,
                    velocity: 100.0,
                    pauseAfterRound: Duration(seconds: 1),
                    startPadding: 10.0,
                    accelerationDuration: Duration(seconds: 1),
                    accelerationCurve: Curves.linear,
                    decelerationDuration: Duration(milliseconds: 500),
                    decelerationCurve: Curves.easeOut,
                  )
                
                ),
                Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Text(
                    'Mohit Kumar',
                    style: TextStyle(fontSize: 18, height: 0.8),
                  ),
                ),
                Text(
                  'Registered On : 05 Oct 2023',
                  style: TextStyle(
                    height: 0.8,
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 10,),
                GradientText(
                  gradient: appcolor.gradient,
                  widget: Text(
                    'Balance Point : 20',
                    style: TextStyle(
                      height: 1.2,
                      fontSize: 16,color: appcolor.redColor
                    ),
                  ),
                ),
                Column(
                  children: [
                    Row(
                      children: [
                        GradientText(
                          gradient: appcolor.gradient,
                          widget: Text(
                            'Pan Status',
                            style: TextStyle(
                              height: 0.8,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: Get.height * 0.055,
                          child: blockButton(
                            callback: () {

                            },
                            width: Get.width * 0.3,
                            widget: Text(
                              'Pending',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  height: 1.2),
                            ),
                            verticalPadding: 3,
                          ),
                        ),
                      ],
                    ).paddingOnly(
                      bottom: 10,
                    ),
                    Row(
                      children: [
                        GradientText(
                          gradient: appcolor.gradient,
                          widget: Text(
                            'Bank Status',
                            style: TextStyle(
                              height: 0.8,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: Get.height * 0.055,
                          child: blockButton(
                            callback: () {

                            },
                            width: Get.width * 0.3,
                            widget: Text(
                              'Pending',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  height: 1.2),
                            ),
                            verticalPadding: 3,
                          ),
                        ),
                      ],
                    ).paddingOnly(
                      bottom: 15,
                    ),
                    Row(
                      children: [
                        GradientText(
                          gradient: appcolor.gradient,
                          widget: Text(
                            'Aadhar Status',
                            style: TextStyle(
                              height: 0.8,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: Get.height * 0.055,
                          child: blockButton(
                            callback: () {

                            },
                            width: Get.width * 0.3,
                            widget: Text(
                              'Pending',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  height: 1.2),
                            ),
                            verticalPadding: 3,
                          ),
                        ),
                      ],
                    ).paddingOnly(
                      bottom: 15,
                    ),
                    Row(
                      children: [
                        GradientText(
                          gradient: appcolor.gradient,
                          widget: Text(
                            'GST Status',
                            style: TextStyle(
                              height: 0.8,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: Get.height * 0.055,
                          child: blockButton(
                            callback: () {

                            },
                            width: Get.width * 0.3,
                            widget: Text(
                              'Pending',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  height: 1.2),
                            ),
                            verticalPadding: 3,
                          ),
                        ),
                      ],
                    ).paddingOnly(
                      bottom: 15,
                    ),
                    // Row(
                    //   children: [
                    //     GradientText(
                    //       gradient: appcolor.gradient,
                    //       widget: Text(
                    //         'Reedemable Points',
                    //         style: TextStyle(
                    //           height: 0.8,
                    //           fontSize: 24,
                    //         ),
                    //       ),
                    //     ),
                    //     Spacer(),
                    //     Text(
                    //       '0        ',
                    //       style: TextStyle(
                    //         height: 0.8,
                    //         fontSize: 30,
                    //       ),
                    //     ),
                    //   ],
                    // ).paddingOnly(
                    //   bottom: 15,
                    // ),
                    // Row(
                    //   children: [
                    //     GradientText(
                    //       gradient: appcolor.gradient,
                    //       widget: Text(
                    //         'Reedemable Cash',
                    //         style: TextStyle(
                    //           height: 0.8,
                    //           fontSize: 24,
                    //         ),
                    //       ),
                    //     ),
                    //     Spacer(),
                    //     Text(
                    //       '0        ',
                    //       style: TextStyle(
                    //         height: 0.8,
                    //         fontSize: 30,
                    //       ),
                    //     ),
                    //   ],
                    // ).paddingOnly(
                    //   bottom: 15,
                    // ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          height: Get.height * 0.055,
                          child: blockButton(
                            callback: () {
                              Get.to(tds_certificate_view());
                            },
                            width: Get.width * 0.3,
                            widget: Text(
                              'TDS Details',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  height: 1.2),
                            ),
                            verticalPadding: 3,
                          ),

                        ),
                        Container(
                          height: Get.height * 0.055,
                          child: blockButton(
                            callback: () {
                              Get.to(redemption_view());
                            },
                            width: Get.width * 0.3,
                            widget: Text(
                              'Redemptions',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  height: 1.2),
                            ),
                            verticalPadding: 3,
                          ),

                        ),


                      ],
                    ).paddingOnly(
                      bottom: 15,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        DottedBorder(
                          borderType: BorderType.RRect,
                          color: appcolor.newRedColor,
                          radius: Radius.circular(10),
                          child: Container(
                            width: Get.width * 0.42,
                            decoration: BoxDecoration(
                              color: appcolor.greyColor,
                              borderRadius: BorderRadius.circular(
                                10,
                              ),
                            ),
                            child: Center(
                              child: Text(
                                'Cash',
                                style: TextStyle(fontSize: 20, height: 1.5),
                              ),
                            ),
                          ),
                        ),
                        DottedBorder(
                          borderType: BorderType.RRect,
                          color: appcolor.newRedColor,
                          radius: Radius.circular(10),
                          child: Container(
                            width: Get.width * 0.42,
                            decoration: BoxDecoration(
                              color: appcolor.greyColor,
                              borderRadius: BorderRadius.circular(
                                10,
                              ),
                            ),
                            child: Center(
                              child: Text(
                                'Scheme',
                                style: TextStyle(fontSize: 20, height: 1.5),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ).paddingOnly(
                      bottom: 15,
                    ),
                    Obx(
                      () => Container(
                        child: Stack(
                          children: [
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 20),
                              height: Get.height * 0.07,
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: showContainer.value == false
                                      ? Colors.black
                                      : appcolor.newRedColor,
                                ),
                                color: Colors.transparent,
                                borderRadius: BorderRadius.circular(5),
                              ),
                              child: Center(
                                child: DropdownButtonFormField(
                                  decoration: InputDecoration.collapsed(
                                    hintText: 'Select Method',
                                    hintStyle: TextStyle(
                                      color: Colors.black,
                                      fontSize: 16,
                                      height: 2.5,
                                    ),
                                  ),
                                  value: value,
                                  onChanged: (value) {
                                    showContainer.value = !showContainer.value;
                                  },
                                  items: [
                                    DropdownMenuItem(
                                      child: Text(
                                        'Google Pay',
                                        style: TextStyle(
                                          fontSize: 14,
                                        ),
                                      ),
                                      value: 1,
                                    ),
                                    DropdownMenuItem(
                                        child: Text(
                                          'Paytm',
                                          style: TextStyle(
                                            fontSize: 14,
                                          ),
                                        ),
                                        value: 2),
                                        DropdownMenuItem(
                                      child: Text(
                                        'Phone Pay',
                                        style: TextStyle(
                                          fontSize: 14,
                                        ),
                                      ),
                                      value: 3,
                                    ),
                                    DropdownMenuItem(
                                      child: Text(
                                        'Bank',
                                        style: TextStyle(
                                          fontSize: 14,
                                        ),
                                      ),
                                      value: 4,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 3),
                              margin: EdgeInsets.only(left: 10),
                              decoration: BoxDecoration(
                                color: appcolor.greyColor,
                              ),
                              child: Text(
                                'Select Reedem Method',
                                style: TextStyle(
                                  height: 0.5,
                                  fontSize: 14,
                                  color: showContainer.value == false
                                      ? Colors.black
                                      : appcolor.black,
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),

                    //show container
                    Obx(
                      () => showContainer.value == true
                          ? Column(
                              children: [
                                Container(
                                  // padding: EdgeInsets.only(top: 4),
                                  height: Get.height * 0.06,
                                  width: Get.width * 0.5,
                                  decoration: BoxDecoration(
                                      color: Color(0xffFFFFFF),
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(
                                        color: appcolor.newRedColor,
                                      )),
                                  child: TextField(
                                    keyboardType: TextInputType.number,
                                    textAlign: TextAlign.center,
                                    cursorColor: Colors.black,
                                    cursorHeight: 0,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 24,
                                    ),
                                    decoration: InputDecoration(
                                        enabledBorder: InputBorder.none,
                                        disabledBorder: InputBorder.none,
                                        border: InputBorder.none,
                                        hintText: 'Enter Points',
                                        contentPadding:
                                            EdgeInsets.symmetric(vertical: 6),
                                        hintStyle: TextStyle(
                                          fontSize: 20,
                                          height: 2.5,
                                          color: Colors.black
                                        )),
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Text(
                                  'Daily Limit for Electrician : Rs. 1000',
                                  style: TextStyle(
                                    fontSize: 16,
                                    height: 0.8,
                                  ),
                                ),
                                Text(
                                  'Amount Redeemed today : Rs. 0',
                                  style: TextStyle(fontSize: 16, height: 1.2),
                                ),
                                Text(
                                  'Daily Limit for Dealers : Rs. 250',
                                  style: TextStyle(
                                    fontSize: 16,
                                    height: 0.8,
                                  ),
                                ),
                                Container(
                                  height: Get.height * 0.055,
                                  child: blockButton(
                                    callback: () {

                                    },
                                    width: Get.width * 0.3,
                                    widget: Text(
                                      'Reedem',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                          height: 1.2),
                                    ),
                                    verticalPadding: 3,
                                  ),

                                ),
                              ],
                            ).paddingOnly(
                              top: 20,
                            )
                          : Container(),
                    ),
                  ],
                ).paddingSymmetric(
                  horizontal: 15,
                  vertical: 10,
                ),
              ],
            ),
          ),
          floatingActionButton:floatingActionButon(),
        ),
      ),
    );
  }
}
