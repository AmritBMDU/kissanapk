import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';

import '../../whatsaapIcon/WhatsaapIcon.dart';

class Feedback_Complaints extends StatefulWidget {
  const Feedback_Complaints({super.key});
  @override
  State<Feedback_Complaints> createState() => _Feedback_Complaints();
}

class _Feedback_Complaints extends State<Feedback_Complaints> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            color: Colors.white
          // image: DecorationImage(
          //   image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            automaticallyImplyLeading: false,
            title: customAppBar('Feedback & Complaints'),),
          backgroundColor: Colors.transparent,
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [

              Container(
                height: 1,
                width: Get.width,
                color: appcolor.borderColor,
              ),
              SizedBox(
                height: 20,
              ),
              Center(
                child: Container(
                  height: 308,
                  width: 311,
                  decoration: BoxDecoration(
                    color: Color(0xffD9D9D9),
                    borderRadius: BorderRadius.all(Radius.circular(11))
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 5,),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Card(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(15))
                            ),
                            height: 38,
                            width: 284,
                            child: TextField(
                              keyboardType: TextInputType.visiblePassword,
                              decoration: InputDecoration(
                                hintText: 'Subject',
                                hintStyle: TextStyle(color: Colors.black),
                                contentPadding: EdgeInsets.symmetric(
                                  horizontal: 10,vertical: 10
                                ),
                                focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: appcolor.redColor)),
                                border: UnderlineInputBorder(
                                )
                              ),
                            ),
                          ),
                        ),
                      ),

                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Card(
                          child: Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.all(Radius.circular(15))
                            ),
                            height: 72,
                            width: 284,
                            child: TextField(
                              keyboardType: TextInputType.visiblePassword,
                              decoration: InputDecoration(
                                  hintText: 'Message....',
                                  hintStyle: TextStyle(color: Colors.black),
                                  focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: appcolor.redColor)),

                                  contentPadding: EdgeInsets.symmetric(
                                      horizontal: 10,vertical: 30
                                  ),
                                  border: UnderlineInputBorder()
                              ),
                            ),
                          ),
                        ),
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('Upload Image', style: TextStyle(fontSize: 14),),
                          SizedBox(width: 10,),
                          Card(
                            child: Container(
                              height: 80,
                                width: 144,
                              child: Image.asset('assets/Vector1.png'),
                            ),
                          )
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 20),
                        child: Container(
                          height: Get.height * 0.055,
                          child: blockButton(
                            callback: () {

                            },
                            width: Get.width * 0.3,
                            widget: Text(
                              'Submit',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  height: 1.2),
                            ),
                            verticalPadding: 3,
                          ),
                        ),
                      ),
                    ],
                  ),

                ),
              )
            ],
          ),
          floatingActionButton:floatingActionButon(),
        ),
      ),
    );
  }
}
