import 'package:http/http.dart'as http;
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../whatsaapIcon/WhatsaapIcon.dart';
import '../AlertDialogBox/alertBoxContent.dart';
import '../home/view/home_view.dart';
import '../server/apiDomain.dart';

class Feedback_Complaints extends StatefulWidget {
  const Feedback_Complaints({super.key});
  @override
  State<Feedback_Complaints> createState() => _Feedback_Complaints();
}

class _Feedback_Complaints extends State<Feedback_Complaints> {
  TextEditingController subject = TextEditingController();
  TextEditingController message = TextEditingController();
  RxString groupValue = 'feedback'.obs;
  RxString profilegroupvalue = 'complaints'.obs;
  File? SelectedImage;
  bool isLoading = false;
  bool showSpinner = false ;
  Future<void> sendImageToServer(String subject, message, ) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');
    var choose = profilegroupvalue.value.toString();
    var uri = Uri.parse('${apiDomain().domain}feedback'); // Replace with your server's endpoint

    var request = http.MultipartRequest("POST", uri)
      ..files.add(await http.MultipartFile.fromPath('image', SelectedImage!.path));
    request.headers['Authorization'] =
        'Bearer ' + '$token';
    request.fields['subject']= '$subject';
    request.fields['message']= '$message';
    request.fields['category']= '$choose';

    var response = await request.send();
    if (response.statusCode == 200) {
      final res = await http.Response.fromStream(response);
      var rest = jsonDecode(res.body);
     // print(res.body);
      if(rest['status'] == true){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${rest['message']}')));
        Get.offAll(Home_view());
      }else{
        alertBoxdialogBox(context, 'Alert', '${rest['message']}');
        //  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${data['message']}')));
      }
    } else {
      print("Failed to upload image. Status code: ${response.statusCode}");
    }
  }


  @override
  Widget build(BuildContext context) {
    return  SafeArea(
        child: Container(
          height: Get.height,
          width: Get.width,
          decoration: BoxDecoration(
              color: Colors.white
            // image: DecorationImage(
            //   image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
          ),
          child: Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.white,
              automaticallyImplyLeading: false,
              title: customAppBar('Feedback & Complaints'),),
            backgroundColor: Colors.transparent,
            body: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: 1,
                  width: Get.width,
                  color: appcolor.borderColor,
                ),
                SizedBox(
                  height: 20,
                ),
                Center(
                  child: Container(
                    height: 340,
                    width: 311,
                    decoration: BoxDecoration(
                      color: Color(0xffD9D9D9),
                      borderRadius: BorderRadius.all(Radius.circular(11))
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Obx(
                              () => Center(
                                child: Container(
                                height: Get.height * 0.04,
                              child: Row(
                                children: [
                                  Radio(
                                    value: 'feedback',
                                    groupValue: profilegroupvalue.value,
                                    onChanged: (val) {
                                      profilegroupvalue.value = val.toString();
                                    },
                                    fillColor: MaterialStateColor.resolveWith(
                                          (states) => appcolor.mixColor,
                                    ),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      groupValue.value = 'feedback';
                                    },
                                    child: Text(
                                      'Feedback',
                                      style: TextStyle(
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 15,
                                  ),
                                  Radio(
                                    value: 'complaints',
                                    groupValue: profilegroupvalue.value,
                                    onChanged: (val) {
                                      profilegroupvalue.value = val.toString();
                                    },
                                    fillColor: MaterialStateColor.resolveWith(
                                          (states) => appcolor.mixColor,
                                    ),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      groupValue.value = 'complaints';
                                    },
                                    child: Text(
                                      'Complaints',
                                      style: TextStyle(
                                        fontSize: 14 ,
                                      ),
                                    ),
                                  ),
                                ],
                            ),
                          ),
                              ),
                        ),
                        SizedBox(height: 5,),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Card(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.all(Radius.circular(15))
                              ),
                              height: 38,
                              width: 284,
                              child: TextField(
                                controller: subject,
                                keyboardType: TextInputType.visiblePassword,
                                decoration: InputDecoration(
                                  hintText: 'Subject',
                                  hintStyle: TextStyle(color: Colors.black),
                                  contentPadding: EdgeInsets.symmetric(
                                    horizontal: 10,vertical: 10
                                  ),
                                  focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: appcolor.redColor)),
                                  border: UnderlineInputBorder(
                                  )
                                ),
                              ),
                            ),
                          ),
                        ),

                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Card(
                            child: Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(Radius.circular(15))
                              ),
                              height: 72,
                              width: 284,
                              child: TextField(
                                controller: message,
                                maxLines: 10,
                                keyboardType: TextInputType.visiblePassword,
                                decoration: InputDecoration(

                                    hintText: 'Message....',
                                    hintStyle: TextStyle(color: Colors.black),
                                    focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: appcolor.redColor)),

                                    contentPadding: EdgeInsets.symmetric(
                                        horizontal: 10,vertical: 20
                                    ),
                                    border: UnderlineInputBorder()
                                ),
                              ),
                            ),
                          ),
                        ),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('Upload Image', style: TextStyle(fontSize: 14),),
                            SizedBox(width: 10,),
                           InkWell(
                               onTap: (){
                                 showModalBottomSheet<void>(
                                   context: context,
                                   builder: (BuildContext context) {
                                     return Container(
                                       height: 80,
                                       color:appcolor.redColor,
                                       child: Center(
                                         child: Row(
                                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                           crossAxisAlignment: CrossAxisAlignment.center,
                                           mainAxisSize: MainAxisSize.min,
                                           children: <Widget>[
                                             Column(
                                               children: [
                                                 IconButton(onPressed: ()async{
                                                     imagePickerCamera();
                                                 }, icon: Icon(Icons.camera,color: Colors.white,),
                                                 ),
                                                 Text('Camera',style: TextStyle(color: Colors.white),),

                                               ],
                                             ),
                                             SizedBox(width: 40,),
                                             Column(
                                               children: [
                                                 IconButton(onPressed: ()async{
                                                   imagePicker();
                                                 }, icon: FaIcon(FontAwesomeIcons.file,color: Colors.white,),
                                                 ),
                                                 Text('File',style: TextStyle(color: Colors.white),),
                                               ],
                                             ),

                                             // ElevatedButton(
                                             //   child: const Text('Close BottomSheet'),
                                             //   onPressed: () => Navigator.pop(context),
                                             // ),
                                           ],
                                         ),
                                       ),
                                     );
                                   },
                                 );
                               },
                           child: Card(
                              child: Container(
                                height: 80,
                                  width: 144,
                                child: SelectedImage == null? Image.asset('assets/Vector1.png'): Image.file(SelectedImage!,fit: BoxFit.cover,),
                              ),
                            )
                           )
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 20),
                          child: Container(
                            height: Get.height * 0.055,
                            child: blockButton(
                              callback: () {
                                var Subject = subject.text.trim().toString();
                                var Message = message.text.trim().toString();
                                if(Subject == null && Message == null){
                                  alertBoxdialogBox(context,'Alert','Please fill field');
                                }else if(SelectedImage == null){
                                  alertBoxdialogBox(context,'Alert','Please Select Image');
                                }else{
                                  setState(() {
                                    isLoading =true;
                                  });
                                  Future.delayed(Duration(seconds: 4),(){
                                    setState(() {
                                      isLoading = false;
                                    });
                                  });
                                  sendImageToServer( Subject,Message,);
                                }
                              },
                              width: Get.width * 0.3,
                              widget:isLoading == false? Text(
                                'Submit',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                    height: 1.2),
                              ):SizedBox(
                                  height: 10,
                                  width: 10,
                                  child: CircularProgressIndicator(color: Colors.white,))
                            ),
                          ),
                        ),
                      ],
                    ),

                  ),
                )
              ],
            ),
            floatingActionButton:floatingActionButon(context),
          ),
        ),

    );
  }
  Future imagePicker()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.gallery);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage = File(returnedImage.path);
      Navigator.of(context).pop();
    });
  }
  Future imagePickerCamera()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.camera);
    // CroppedFile? croppedFile = await ImageCropper().cropImage(
    //     aspectRatioPresets: [
    //       CropAspectRatioPreset.square,
    //       CropAspectRatioPreset.ratio3x2,
    //       CropAspectRatioPreset.original,
    //       CropAspectRatioPreset.ratio4x3,
    //       CropAspectRatioPreset.ratio16x9,
    //     ],
    //     sourcePath: returnedImage!.path
    // );
    if(returnedImage == null)return;
    setState(() {
      SelectedImage = File(returnedImage.path);
      Navigator.of(context).pop();

    });
  }
  Future feedback(Object value)async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');
print(value);
    final response = await http.post(Uri.parse('${apiDomain().domain}feedback'),body: jsonEncode(value),
        headers: ({
          'Content-Type': 'application/json; charset=UTF-8',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token'
        }));
    if(response.statusCode == 200){
      final data = jsonDecode(response.body);
      if(data['status'] == true){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${data['message']}')));
        Get.off(Home_view());
      }else{
        showDialog(
            context: context, builder: (BuildContext contex){
          return AlertDialog(
            title: Text('Oops!', style: TextStyle(color: appcolor.redColor,fontWeight: FontWeight.bold),),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset('assets/img_12.png',),
                Text('Invalid QR Code') ,
              ],
            ),
            actions: [
              Container(
                height: Get.height * 0.055,
                child: blockButton(
                  callback: () {
                    Get.back();
                  },
                  width: Get.width ,
                  widget: Text(
                    'Ok',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        height: 1.2),
                  ),
                  verticalPadding: 3,
                ),
              ),
            ],
          );
        });
        //  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${data['message']}')));

      }
    }
  }
}
