import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

Widget floatingActionButon(){
  return    SizedBox(
    height: 40,
    width: 40,
    child: FloatingActionButton(

    backgroundColor: Colors.green,
    onPressed: () {  },child: FaIcon(FontAwesomeIcons.whatsapp,)

    ),
  );
}