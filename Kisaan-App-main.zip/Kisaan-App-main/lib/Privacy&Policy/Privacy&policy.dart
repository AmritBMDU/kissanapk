import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/gradient_text.dart';

import '../../whatsaapIcon/WhatsaapIcon.dart';

class privacy_policy extends StatefulWidget {
  const privacy_policy({super.key});
  @override
  State<privacy_policy> createState() => _privacy_policy();
}

class _privacy_policy extends State<privacy_policy> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            color: Colors.white
          // image: DecorationImage(
          //   image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            automaticallyImplyLeading: false,
            title: customAppBar('Privacy Policy'),),
          backgroundColor: Colors.transparent,
          body: Column(
            children: [

              Container(
                height: 1,
                width: Get.width,
                color: appcolor.borderColor,
              ),
              SizedBox(height: 10,),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('1. Payment : Any amount equal to above Rs. 1',style: TextStyle(fontSize: 14),),

                  Text('2. Bank Transfer : Any Amount equal or above \n    Rs.300',style: TextStyle(fontSize: 14),)
                ],
              ),
              SizedBox(height: 20,),
              Center(child: Text('Disclaimer', style: TextStyle(fontSize: 16,color: appcolor.redColor),)),
              SizedBox(height: 10,),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(' 1. Please note as, per CBDTwhen an unknown \n       printer took a galley of type and scrambled \n       it to make a type specimen book. It has \n       survived not only five centuries,',style: TextStyle(fontSize: 14),),

                  Text(' 2. Please note as, per CBDTwhen an unknown \n       printer took a galley of type and scrambled \n       it to make a type specimen book. It has \n       survived not only five centuries,',style: TextStyle(fontSize: 14),),
                ],
              ),
              SizedBox(height: 20,),
              Center(child: Text('End User License Agreement', style: TextStyle(fontSize: 16,color: appcolor.redColor),)),
              SizedBox(height: 10,),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('  To View the update terms & conditions please \n   clieck on the link',style: TextStyle(fontSize: 14),),

                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(width: 25,),
                  TextButton(onPressed: (){}, child: Text('Click Here')),
                ],
              )
            ],
          ),
          floatingActionButton:floatingActionButon(),
        ),
      ),
    );
  }
}
