class productdetail {
  Product? product;
  List<Size>? size;
  String? profession;
  bool? status;

  productdetail({this.product, this.size, this.profession, this.status});

  productdetail.fromJson(Map<String, dynamic> json) {
    product =
    json['product'] != null ? new Product.fromJson(json['product']) : null;
    if (json['size'] != null) {
      size = <Size>[];
      json['size'].forEach((v) {
        size!.add(new Size.fromJson(v));
      });
    }
    profession = json['profession'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.product != null) {
      data['product'] = this.product!.toJson();
    }
    if (this.size != null) {
      data['size'] = this.size!.map((v) => v.toJson()).toList();
    }
    data['profession'] = this.profession;
    data['status'] = this.status;
    return data;
  }
}

class Product {
  int? id;
  String? createdAt;
  String? updatedAt;
  String? name;
  int? series;
  int? category;
  int? price;
  String? code;
  String? moduleSize;
  String? size;
  String? dimension;
  String? description;
  String? image;
  Null? images;

  Product(
      {this.id,
        this.createdAt,
        this.updatedAt,
        this.name,
        this.series,
        this.category,
        this.price,
        this.code,
        this.moduleSize,
        this.size,
        this.dimension,
        this.description,
        this.image,
        this.images});

  Product.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    name = json['name'];
    series = json['series'];
    category = json['category'];
    price = json['price'];
    code = json['code'];
    moduleSize = json['module_size'];
    size = json['size'];
    dimension = json['dimension'];
    description = json['description'];
    image = json['image'];
    images = json['images'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['name'] = this.name;
    data['series'] = this.series;
    data['category'] = this.category;
    data['price'] = this.price;
    data['code'] = this.code;
    data['module_size'] = this.moduleSize;
    data['size'] = this.size;
    data['dimension'] = this.dimension;
    data['description'] = this.description;
    data['image'] = this.image;
    data['images'] = this.images;
    return data;
  }
}

class Size {
  String? size;
  int? price;

  Size({this.size, this.price});

  Size.fromJson(Map<String, dynamic> json) {
    size = json['size'];
    price = json['price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['size'] = this.size;
    data['price'] = this.price;
    return data;
  }
}