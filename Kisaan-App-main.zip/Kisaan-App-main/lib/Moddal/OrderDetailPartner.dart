
class OrderDetailParnters{
  static  List<PartnerOrderDetail> Items = [

  ];
}



class OrderDetailParnter {
  List<PartnerOrderDetail>? partnerOrderDetail;
  bool? status;

  OrderDetailParnter({this.partnerOrderDetail, this.status});

  OrderDetailParnter.fromJson(Map<String, dynamic> json) {
    if (json['PartnerOrderDetail'] != null) {
      partnerOrderDetail = <PartnerOrderDetail>[];
      json['PartnerOrderDetail'].forEach((v) {
        partnerOrderDetail!.add(new PartnerOrderDetail.fromJson(v));
      });
    }
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.partnerOrderDetail != null) {
      data['PartnerOrderDetail'] =
          this.partnerOrderDetail!.map((v) => v.toJson()).toList();
    }
    data['status'] = this.status;
    return data;
  }
}

class PartnerOrderDetail {
  int? id;
  String? orderId;
  String? productName;
  String? image;
  int? quantity;
  int? series;
  int? price;
  String? size;
  String? createdAt;
  String? updatedAt;

  PartnerOrderDetail(
      {this.id,
        this.orderId,
        this.productName,
        this.image,
        this.quantity,
        this.series,
        this.price,
        this.size,
        this.createdAt,
        this.updatedAt});

  PartnerOrderDetail.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    orderId = json['order_id'];
    productName = json['product_name'];
    image = json['image'];
    quantity = json['quantity'];
    series = json['series'];
    price = json['price'];
    size = json['size'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['order_id'] = this.orderId;
    data['product_name'] = this.productName;
    data['image'] = this.image;
    data['quantity'] = this.quantity;
    data['series'] = this.series;
    data['price'] = this.price;
    data['size'] = this.size;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}