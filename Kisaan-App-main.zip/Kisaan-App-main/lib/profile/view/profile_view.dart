import 'dart:convert';
import 'dart:io';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart'as http;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:kisaan_electric/AlertDialogBox/alertBoxContent.dart';
import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/customAppBar.dart';
import 'package:kisaan_electric/global/customtextformfield.dart';
import 'package:kisaan_electric/global/image_pickerController.dart';
import 'package:kisaan_electric/home/view/home_view.dart';
import 'package:kisaan_electric/profile/controller/profileController.dart';
import 'package:kisaan_electric/wallet/controller/wallte_controller.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../server/apiDomain.dart';
import '../../whatsaapIcon/WhatsaapIcon.dart';

class profile_view extends StatefulWidget {
  const profile_view({super.key});

  @override
  State<profile_view> createState() => _profile_viewState();
}

class _profile_viewState extends State<profile_view> {
  imagePickercontroller imagecontroller = Get.put(imagePickercontroller());
  wallet_controller controller = Get.put(wallet_controller());
  profilecontroller profileController = Get.put(profilecontroller());
  RxString groupValue = '1'.obs;
  RxString profilegroupvalue = '1'.obs;
  String personalDate = '';
  String AdditionalDate1 = '';
  String AdditionalDate2 = '';
  String AdditionalDate3 = '';
  String radiou = '';
 bool isLoading1 = false;
 bool isLoading2 = false;
 bool isLoading3 = false;
 bool isLoading4 = false;
 bool isLoading5 = false;
  // Image Picker

  // Text Controller
  TextEditingController fullName = TextEditingController();
  TextEditingController mobile = TextEditingController();
  TextEditingController whatsapno = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController address = TextEditingController();
  TextEditingController pincode = TextEditingController();
  TextEditingController country = TextEditingController();
  TextEditingController state = TextEditingController();
  TextEditingController city = TextEditingController();
  TextEditingController bankName = TextEditingController();
  TextEditingController accounNo = TextEditingController();
  TextEditingController ifscCode = TextEditingController();
  TextEditingController accontHolderName = TextEditingController();
  TextEditingController paythmNo = TextEditingController();
  TextEditingController googlePayNo = TextEditingController();
  TextEditingController phonePayNo = TextEditingController();
  TextEditingController aadharno = TextEditingController();
  TextEditingController panNo = TextEditingController();
  TextEditingController GstNo = TextEditingController();
  TextEditingController firstname = TextEditingController();
  TextEditingController  studyfirst= TextEditingController();
  TextEditingController firstdob = TextEditingController();
  TextEditingController secondname = TextEditingController();
  TextEditingController seconddob = TextEditingController();
  TextEditingController secondstudyin = TextEditingController();
  TextEditingController thrdname = TextEditingController();
  TextEditingController thrddob = TextEditingController();
  TextEditingController thrdstudy = TextEditingController();
  TextEditingController reading = TextEditingController();
  TextEditingController writings=  TextEditingController();
  TextEditingController speaking = TextEditingController();
  TextEditingController cin = TextEditingController();
  TextEditingController workExperience = TextEditingController();
  var gender;
  File? SelectedImage;
  File? SelectedImage1;
  File? SelectedImage2;
  File? SelectedImage3;
  File? SelectedImage4;
  File? SelectedImage5;
  File? SelectedImage6;
  File? SelectedImage7;
  String _radioVal = "";
  int? _radioSelected;
  String radioVall = "";
  int? radioSelectedd;

@override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(seconds: 500),(){
       Profilebasic('');
    });
    Profilebasics();
    // Transfer();
    // documentInfo();
  }

  Future imagePicker()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.gallery);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage = File(returnedImage.path);
      Navigator.of(context).pop();
    });
  }
  Future imagePickerCamera()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.camera);
    // CroppedFile? croppedFile = await ImageCropper().cropImage(
    //     aspectRatioPresets: [
    //       CropAspectRatioPreset.square,
    //       CropAspectRatioPreset.ratio3x2,
    //       CropAspectRatioPreset.original,
    //       CropAspectRatioPreset.ratio4x3,
    //       CropAspectRatioPreset.ratio16x9,
    //     ],
    //     sourcePath: returnedImage!.path
    // );
    if(returnedImage == null)return;
    setState(() {
      SelectedImage = File(returnedImage.path);
      Navigator.of(context).pop();

    });
  }
  Future imagePicker1()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.gallery);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage1 = File(returnedImage.path);
      Navigator.of(context).pop();
    });
  }
  Future imagePickerCamera1()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.camera);
    // CroppedFile? croppedFile = await ImageCropper().cropImage(
    //     aspectRatioPresets: [
    //       CropAspectRatioPreset.square,
    //       CropAspectRatioPreset.ratio3x2,
    //       CropAspectRatioPreset.original,
    //       CropAspectRatioPreset.ratio4x3,
    //       CropAspectRatioPreset.ratio16x9,
    //     ],
    //     sourcePath: returnedImage!.path
    // );
    if(returnedImage == null)return;
    setState(() {
      SelectedImage1 = File(returnedImage.path);
      Navigator.of(context).pop();

    });
  }
  Future imagePicker2()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.gallery);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage2 = File(returnedImage.path);
      Navigator.of(context).pop();
    });
  }
  Future imagePickerCamera2()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.camera);
    // CroppedFile? croppedFile = await ImageCropper().cropImage(
    //     aspectRatioPresets: [
    //       CropAspectRatioPreset.square,
    //       CropAspectRatioPreset.ratio3x2,
    //       CropAspectRatioPreset.original,
    //       CropAspectRatioPreset.ratio4x3,
    //       CropAspectRatioPreset.ratio16x9,
    //     ],
    //     sourcePath: returnedImage!.path
    // );
    if(returnedImage == null)return;
    setState(() {
      SelectedImage2= File(returnedImage.path);
      Navigator.of(context).pop();

    });
  }
  Future aadharFront()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.gallery);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage3 = File(returnedImage.path);
      Navigator.of(context).pop();
    });
  }
  Future aadharFrontcamer()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.camera);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage3= File(returnedImage.path);
      Navigator.of(context).pop();

    });
  }
  Future aadharback()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.gallery);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage4 = File(returnedImage.path);
      Navigator.of(context).pop();
    });
  }
  Future aadharbackCamera()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.camera);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage4= File(returnedImage.path);
      Navigator.of(context).pop();

    });
  }
  Future pancard()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.gallery);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage5 = File(returnedImage.path);
      Navigator.of(context).pop();
    });
  }
  Future pancardcamera()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.camera);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage5= File(returnedImage.path);
      Navigator.of(context).pop();

    });
  }
  Future gstupload()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.gallery);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage6 = File(returnedImage.path);
      Navigator.of(context).pop();
    });
  }
  Future gstcamera()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.camera);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage6= File(returnedImage.path);
      Navigator.of(context).pop();

    });
  }
  Future shopImage()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.gallery);

    if(returnedImage == null)return;
    setState(() {
      SelectedImage7 = File(returnedImage.path);
      Navigator.of(context).pop();
    });
  }
  Future shopcamera()async{
    final returnedImage = await ImagePicker().pickImage(source: ImageSource.camera);
    if(returnedImage == null)return;
    setState(() {
      SelectedImage7= File(returnedImage.path);
      Navigator.of(context).pop();

    });
  }

  var value = null;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
          color: Colors.white
          // image: DecorationImage(
          //     image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Column(
            children: [
              customAppBar('My Profile'),
              Container(
                height: 1,
                width: Get.width,
                color: appcolor.borderColor,
              ),
              FutureBuilder(
                future: Profilebasic(''),
                builder: (context,snapshot){
                  if(snapshot.hasData){
                    var data = snapshot.data;
                    var date = data['created_at'];
                    var split = date.split('T');
                    var split1 = split[0];
                    return Column(
                      children: [
                        Container(
                          padding: EdgeInsets.only(
                            top: 5,
                            left: 10,
                            right: 10,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Container(
                                child: Stack(
                                  alignment: Alignment.topCenter,
                                  children: [
                                    CircleAvatar(
                                      backgroundColor: appcolor.borderColor,
                                      radius: 40,
                                      child: CircleAvatar(
                                        backgroundColor: appcolor.greyColor,
                                        child: Icon(
                                          Icons.person,
                                        ),
                                        radius: 39,
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: Get.height * 0.09),
                                      height: Get.height * 0.03,
                                      width: Get.width * 0.24,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          color: appcolor.borderColor,
                                        ),
                                        borderRadius: BorderRadius.circular(10),
                                        color: Color(0xffECFF0C),
                                      ),
                                      child: Center(
                                        child: Text(
                                          '20%',
                                          style: TextStyle(
                                            // height: 0.,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Text(
                                      'Name : ${data['name']}',
                                      style: TextStyle(
                                        height: 1.5,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Text(
                                      'Phone : +91 ${data['mobile_no']}',
                                      style: TextStyle(
                                        height: 0.6,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ),
                                  Text(
                                    'Registered On: ${split1}',
                                    style: TextStyle(
                                      height: 1.2,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ).paddingOnly(left: 5),
                            ],
                          ),
                        ),

                      ],
                    );
                  }else if(snapshot.hasError){
                    return Text('Data not Found');
                  }else if(snapshot.connectionState ==ConnectionState.waiting){
                    return Center(child: CircularProgressIndicator(),);
                  }else{
                    return CircularProgressIndicator();
                  }
                },
              ),
              Container(
                decoration: BoxDecoration(),
                height: Get.height * 0.08,
                child: TabBar(
                  dividerColor: appcolor.newRedColor,
                  isScrollable: true,
                  unselectedLabelColor: Colors.black,
                  unselectedLabelStyle: TextStyle(
                    fontSize: 16,
                  ),
                  indicatorColor: appcolor.redColor,
                  labelColor: Colors.black,
                  labelStyle: TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                  ),
                  padding: EdgeInsets.zero,
                  // labelPadding: EdgeInsets.zero,
                  indicatorPadding: EdgeInsets.zero,
                  controller: controller.tabcontroller,
                  tabs: [
                    Container(
                      padding: EdgeInsets.zero,
                      child: Text(
                        'Personel Info',
                      ),
                    ),
                    Container(
                      child: Text('Transfer Info'),
                    ),
                    Text('Documents Info'),
                    Text('Additional Info'),
                  ],
                ),
              ),
              Expanded(
                child: TabBarView(
                  controller: controller.tabcontroller,
                  children: [
                    personelInfo(),
                    TransferInfo(),
                    Documents(),
                    AdditionalInfo(),
                  ],
                ),
              )
              // Container(
              //   padding: EdgeInsets.only(
              //     top: 5,
              //     left: 10,
              //     right: 10,
              //   ),
              //   child: Row(
              //     mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              //     children: [
              //       Container(
              //         child: Stack(
              //           alignment: Alignment.topCenter,
              //           children: [
              //             CircleAvatar(
              //               backgroundColor: appcolor.borderColor,
              //               radius: 40,
              //               child: CircleAvatar(
              //                 backgroundColor: appcolor.greyColor,
              //                 child: Icon(
              //                   Icons.person,
              //                 ),
              //                 radius: 39,
              //               ),
              //             ),
              //             Container(
              //               margin: EdgeInsets.only(top: Get.height * 0.09),
              //               height: Get.height * 0.03,
              //               width: Get.width * 0.24,
              //               decoration: BoxDecoration(
              //                 border: Border.all(
              //                   color: appcolor.borderColor,
              //                 ),
              //                 borderRadius: BorderRadius.circular(10),
              //                 color: Color(0xffECFF0C),
              //               ),
              //               child: Center(
              //                 child: Text(
              //                   '20%',
              //                   style: TextStyle(
              //                     // height: 0.,
              //                     fontSize: 14,
              //                   ),
              //                 ),
              //               ),
              //             ),
              //           ],
              //         ),
              //       ),
              //       Column(
              //         mainAxisAlignment: MainAxisAlignment.end,
              //         crossAxisAlignment: CrossAxisAlignment.start,
              //         children: [
              //           Padding(
              //             padding: const EdgeInsets.all(3.0),
              //             child: Text(
              //               'Name : Mohit Kumar',
              //               style: TextStyle(
              //                 height: 1.5,
              //                 fontSize: 16,
              //               ),
              //             ),
              //           ),
              //           Padding(
              //             padding: const EdgeInsets.all(3.0),
              //             child: Text(
              //               'Phone : +91 89076 7689',
              //               style: TextStyle(
              //                 height: 0.6,
              //                 fontSize: 16,
              //               ),
              //             ),
              //           ),
              //           Text(
              //             'Registered On: 27 Sep 2023',
              //             style: TextStyle(
              //               height: 1.2,
              //               fontSize: 16,
              //             ),
              //           ),
              //         ],
              //       ).paddingOnly(left: 5),
              //     ],
              //   ),
              // ),
              // Container(
              //   decoration: BoxDecoration(),
              //   height: Get.height * 0.08,
              //   child: TabBar(
              //     dividerColor: appcolor.newRedColor,
              //     isScrollable: true,
              //     unselectedLabelColor: Colors.black,
              //     unselectedLabelStyle: TextStyle(
              //       fontSize: 16,
              //     ),
              //     indicatorColor: appcolor.redColor,
              //     labelColor: Colors.black,
              //     labelStyle: TextStyle(
              //       color: Colors.black,
              //       fontSize: 16,
              //     ),
              //     padding: EdgeInsets.zero,
              //     // labelPadding: EdgeInsets.zero,
              //     indicatorPadding: EdgeInsets.zero,
              //     controller: controller.tabcontroller,
              //     tabs: [
              //       Container(
              //         padding: EdgeInsets.zero,
              //         child: Text(
              //           'Personel Info',
              //         ),
              //       ),
              //       Container(
              //         child: Text('Transfer Info'),
              //       ),
              //       Text('Documents Info'),
              //       Text('Additional Info'),
              //     ],
              //   ),
              // ),
              // Expanded(
              //   child: TabBarView(
              //     controller: controller.tabcontroller,
              //     children: [
              //       personelInfo(),
              //       TransferInfo(),
              //       Documents(),
              //       AdditionalInfo(),
              //     ],
              //   ),
              // )
            ],
          ),
          floatingActionButton:floatingActionButon(context),
        ),
      ),
    );
  }
  //Personal infomation get data
  Future Profilebasic(Object value)async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');

    final response = await http.post(Uri.parse('${apiDomain().domain}profileinfo'),
        headers: ({
          'Content-Type': 'application/json; charset=UTF-8',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token'
        }));
    if(response.statusCode == 200){
      final data = jsonDecode(response.body);
      final dataa = data['data'];
      dataa[0]['country']==null? '':country.text = dataa[0]['country'];
      dataa[0]['state']==null? '':state.text = dataa[0]['state'];
      dataa[0]['name']==null? '':fullName.text = dataa[0]['name'];
      dataa[0]['mobile_no']==null? '':mobile.text = dataa[0]['mobile_no'];
      dataa[0]['email']==null? '':email.text = dataa[0]['email'];
      dataa[0]['address']==null? '':address.text = dataa[0]['address'];
      dataa[0]['pincode']==null? '':pincode.text = dataa[0]['pincode'];
      dataa[0]['city']==null? '':city.text = dataa[0]['city'];
      dataa[0]['whatsapp_number']==null? '':whatsapno.text = dataa[0]['whatsapp_number'];
      dataa[0]['bank_name']==null? '':bankName.text = dataa[0]['bank_name'].toString();
      dataa[0]['Ac_number']==null? '':accounNo.text = dataa[0]['Ac_number'];
      dataa[0]['ifsc_code']==null? '':ifscCode.text = dataa[0]['ifsc_code'];
      dataa[0]['holder_name']==null? '':accontHolderName.text = dataa[0]['holder_name'];
      dataa[0]['paytm_no']==null? '':paythmNo.text = dataa[0]['paytm_no'];
      dataa[0]['googlepay_no']==null? '':googlePayNo.text = dataa[0]['googlepay_no'];
      dataa[0]['phonepay_no']==null? '':phonePayNo.text = dataa[0]['phonepay_no'];
      dataa[0]['aadhar_no']==null? '':aadharno.text = dataa[0]['aadhar_no'].toString();
      dataa[0]['pan_no']==null? '':panNo.text = dataa[0]['pan_no'];
      dataa[0]['gst_no']==null? '':GstNo.text = dataa[0]['gst_no'];
      dataa[0]['oneChildName']==null? '':firstname.text = dataa[0]['oneChildName'];
      dataa[0]['oneChildDate']==null? '':firstdob.text = dataa[0]['oneChildDate'];
      dataa[0]['oneChildStudy']==null? '':studyfirst.text = dataa[0]['oneChildStudy'];
      dataa[0]['secondChildName']==null? '':secondname.text = dataa[0]['secondChildName'];
      dataa[0]['secondChildDate']==null? '':seconddob.text = dataa[0]['secondChildDate'];
      dataa[0]['secondChildStudy']==null? '':secondstudyin.text = dataa[0]['secondChildStudy'];
      dataa[0]['thirdChildName']==null? '':thrdname.text = dataa[0]['thirdChildName'];
      dataa[0]['thirdChildDate']==null? '':thrddob.text = dataa[0]['thirdChildDate'];
      dataa[0]['thirdChildStudy']==null? '':thrdstudy.text = dataa[0]['thirdChildStudy'];
      dataa[0]['reading']==null? '':reading.text = dataa[0]['reading'];
      dataa[0]['writing']==null? '':writings.text = dataa[0]['writing'];
      dataa[0]['speaking']==null? '':speaking.text = dataa[0]['speaking'];
      dataa[0]['experiance']==null? '':workExperience.text = dataa[0]['experiance'];
      _radioSelected = dataa[0]['gender']== 'male'?1:2;
      // setState(() {

      // });
     // print(dataa);
      return dataa[0];
    }
  }
  Future Profilebasics()async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');

    final response = await http.post(Uri.parse('${apiDomain().domain}profileinfo'),
        headers: ({
          'Content-Type': 'application/json; charset=UTF-8',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token'
        }));
    if(response.statusCode == 200){
      final data = jsonDecode(response.body);
      final dataa = data['data'];
      setState(() {
      _radioSelected = dataa[0]['gender']== 'male'?1:2;
      radioSelectedd = int.parse(dataa[0]['children_info']);
      });
      // print(dataa);
      return dataa[0];
    }
  }
// update data personal infromation
  Future ProfileUpdate(String url,Object value)async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');
    final response = await http.post(Uri.parse('${apiDomain().domain}$url'),body: jsonEncode(value),
        headers: ({
          'Content-Type': 'application/json; charset=UTF-8',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token'
        }));
    if(response.statusCode == 200){
      final data = jsonDecode(response.body);
      if(data['status']== true){
        //Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Home_view()));
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${data['message']}')));
      }else{
        alertBoxdialogBox(context, 'Alert', '${data['message']}');
      }
      return data[0];
    }
  }
  // Pincode get data
  Future PinCodeGenerate(String code)async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');
    final response = await http.get(Uri.parse('https://api.postalpincode.in/pincode/$code'),
        );
    if(response.statusCode == 200){
      final data = jsonDecode(response.body);
      var  dataa = data[0]['PostOffice'];
      country.text = dataa[0]['Country'].toString();
      state.text = dataa[0]['State'].toString();
      city.text = dataa[0]['Block'].toString();
      // print(dataa);
      return dataa;
    }
  }
  Widget personelInfo() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 20,
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: fullName,
                  verticalContentPadding: 0,
                  hinttext: 'Full Name',
                  hintTextColor: Colors.black,
                  bottomLineColor: Color(0xffb8b8b8),
                  suffixIcon: Container(
                    height: Get.height * 0.00009,
                      child:Icon(Icons.person,color:appcolor.redColor,)
                  ),
                  newIcon: Container(
                    height: Get.height * 0.00009,
                    child:Icon(Icons.person,color:appcolor.redColor,)

                  )),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Radio(
                      value: 1,
                      groupValue: _radioSelected,
                      activeColor: Colors.red,
                      onChanged: (value) {
                        setState(() {
                          _radioSelected = value as int;
                          _radioVal = 'male';
                        //  print(_radioVal);
                        });
                      },
                    ),
                    const Text("Male"),
                  ],
                ),
                Row(
                  children: [
                    Radio(
                      value: 2,
                      groupValue: _radioSelected,
                      activeColor: Colors.red,
                      onChanged: (value) {
                        setState(() {
                          _radioSelected = value as int;
                          _radioVal = 'female';
                          print(_radioVal);
                        });
                      },
                    ),
                    const Text("Female"),
                  ],
                ),
              ],
            ),
            // Obx(
            //   () => Container(
            //     height: Get.height * 0.04,
            //     child: Row(
            //       children: [
            //         Radio(
            //           value: '1',
            //           groupValue: profilegroupvalue.value,
            //           onChanged: (val) {
            //             profilegroupvalue.value = val.toString();
            //           },
            //           fillColor: MaterialStateColor.resolveWith(
            //             (states) => appcolor.mixColor,
            //           ),
            //         ),
            //         InkWell(
            //           onTap: () {
            //             groupValue.value = '1';
            //           },
            //           child: Text(
            //             'Male',
            //             style: TextStyle(
            //               fontSize: 14,
            //             ),
            //           ),
            //         ),
            //         SizedBox(
            //           width: 15,
            //         ),
            //         Radio(
            //           value: '2',
            //           groupValue: gender,
            //           onChanged: (val) {
            //             groupValue.value = val.toString();
            //           },
            //           fillColor: MaterialStateColor.resolveWith(
            //             (states) => appcolor.mixColor,
            //           ),
            //         ),
            //         InkWell(
            //           onTap: () {
            //             groupValue.value = '2';
            //           },
            //           child: Text(
            //             'Female',
            //             style: TextStyle(
            //               fontSize: 14 ,
            //             ),
            //           ),
            //         ),
            //       ],
            //     ),
            //   ),
            // ),
            InkWell(
              onTap: ()async{
                personalDate =
                    await profileController.showdatepicker(context);
                setState(() {});
              },
              child: Padding(
                padding: const EdgeInsets.only(right: 24,left: 10,bottom: 6,top: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('${personalDate =='' ?'Birth Date':personalDate}'),
                    Container(
                      height: Get.height * 0.025,
                      child: Image.asset('assets/birthdate.png',color: appcolor.redColor,),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 10,left: 10),
              child: Container(height: 1,width: Get.width,color: Color(0xffb8b8b8),),
            ),
            SizedBox(height: 6,),
            // Container(
            //   height: Get.height * 0.055,
            //   child: customtextformfield(
            //     callback: () async {
            //       print('hii');
            //       personalDate =
            //           await profileController.showdatepicker(context);
            //       setState(() {});
            //     },
            //     readOnly: true,
            //     key_type: TextInputType.datetime,
            //     verticalContentPadding: 0,
            //     hinttext: personalDate == '' ? 'Birth Date' : personalDate,
            //     hintTextColor: Colors.black,
            //     bottomLineColor: Colors.black,
            //     newIcon: Container(
            //       height: Get.height * 0.025,
            //       child: Image.asset('assets/birthdate.png',color: appcolor.redColor,),
            //     ),
            //   ),
            // ),
            
            Container(

              height: Get.height * 0.055,
              child: customtextformfield(
                controller: mobile,
                key_type: TextInputType.phone,
                verticalContentPadding: 0,
                hinttext: 'Phone Number',
                maxLength: 10,
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                newIcon: Container(
                  height: Get.height * 0.025,
                    child: Image.asset('assets/support.png',color: appcolor.redColor,)
                ),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: whatsapno,
                key_type: TextInputType.phone,
                verticalContentPadding: 0,
                hinttext: 'Whatsapp Number',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                maxLength: 10,
                newIcon: Container(
                  height: Get.height * 0.025,
                    child: Image.asset('assets/whatsapp.png',color: appcolor.redColor,)
                ),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: Padding(
                padding: const EdgeInsets.all(1.0),
                child: customtextformfield(
                  controller: email,
                  verticalContentPadding: 0,
                  hinttext: 'Email',
                  key_type: TextInputType.emailAddress,
                  hintTextColor: Colors.black,
                  bottomLineColor: Color(0xffb8b8b8),
                  newIcon: Container(
                    height: Get.height * 0.025,
                      child: Image.asset('assets/email.png',color: appcolor.redColor,)
                  ),
                ),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: address,
                verticalContentPadding: 0,
                hinttext: 'Address',
                key_type: TextInputType.streetAddress,
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                newIcon: Container(
                  height: Get.height * 0.025,
                    child: Image.asset('assets/location.png',color: appcolor.redColor,)


                ),
              ),
            ),
            Row(
              children: [
                Container(
                  width: Get.width * 0.5,
                  height: Get.height * 0.055,
                  child: customtextformfield(
                    controller: pincode,
                    verticalContentPadding: 0,
                    hinttext: 'Pin Code',
                    key_type: TextInputType.number,
                    hintTextColor: Colors.black,
                    bottomLineColor: Color(0xffb8b8b8),
                  ),
                ),
                Container(
                  height: Get.height * 0.055,
                  child: blockButton(
                    callback: () {
                      var PinCode = pincode.text.trim();
                      if(PinCode != ''){
                        PinCodeGenerate(PinCode);
                      }
                    },
                    width: Get.width * 0.3,
                    widget: Text(
                      'Check',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          height: 1.2),
                    ),
                    verticalPadding: 3,
                  ),
                ),
              ],
            ),

            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: country,
                key_type: TextInputType.visiblePassword,
                verticalContentPadding: 0,
                hinttext: 'Country',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                maxLength: 10,
                newIcon: Container(
                    height: Get.height * 0.025,
                    child: Icon(Icons.location_on,color: appcolor.redColor,)
                ),
              ),
            ),

            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: state,
                key_type: TextInputType.phone,
                verticalContentPadding: 0,
                hinttext: 'State',

                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                maxLength: 10,
                newIcon: Container(
                    height: Get.height * 0.025,
                    child: Icon(Icons.location_on,color: appcolor.redColor,)
                ),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: city,
                key_type: TextInputType.phone,
                verticalContentPadding: 0,
                hinttext: 'City',

                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                maxLength: 10,
                newIcon: Container(
                    height: Get.height * 0.025,
                    child: Icon(Icons.location_on,color: appcolor.redColor,)
                ),
              ),
            ),
            SizedBox(
              height: Get.height * 0.02,
            ),
            Container(
              height: Get.height * 0.055,
              child: blockButton(
                callback: () {
                  var Name = fullName.text.trim().toString();
                  var Mobile = mobile.text.trim();
                  var wNo = whatsapno.text.trim().toString();
                  var Email = email.text.trim().toString();
                  var Address = address.text.trim().toString();
                  var Country = country.text.trim().toString();
                  var PinCode = pincode.text.trim().toString();
                  var State = state.text.trim().toString();
                  var City= city.text.trim().toString();
                  if(Name == '' && Mobile == '' ){

                  }else{
                    var value = {
                      "name":Name,
                      "email":Email,
                      "mobile_no":Mobile,
                      "whatsapp_number":wNo,
                      "address":Address,
                      "pincode": PinCode,
                      "country":Country,
                      "state": State,
                      "city":City,
                      "gender":_radioVal,
                      "dob":personalDate
                    };
                    setState(() {
                      isLoading1 =true;
                    });
                    Future.delayed(Duration(seconds: 4),(){
                      setState(() {
                        isLoading2 = false;
                      });
                    });
                    ProfileUpdate('profileinfo',value);
                  }

                },
                width: Get.width * 0.3,
                widget: isLoading2 == false?Text(
                  'Update',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      height: 1.2),
                ):SizedBox(
                    height: 10,
                    width: 10,
                    child: CircularProgressIndicator(color: Colors.white,)),
                verticalPadding: 3,
              ),
            ),
            SizedBox(
              height: Get.height * 0.02,
            ),
          ],
        ),
      ),
    );
  }


  Future<void> UpdateTransfer(String AccountNO, BankName,IfscCode,HolderName ,PaythmNo,GoogleNo,Phonepay) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');
    var choose = profilegroupvalue.value.toString();
    var uri = Uri.parse('${apiDomain().domain}transferinfo'); // Replace with your server's endpoint

    var request = http.MultipartRequest("POST", uri)
      ..files.add(await http.MultipartFile.fromPath('cancelled_cheque', SelectedImage!.path));
    request.files.add(await http.MultipartFile.fromPath('passbook', SelectedImage1!.path));
    request.files.add(await http.MultipartFile.fromPath('paytm_kyc', SelectedImage2!.path));

    request.headers['Authorization'] =
        'Bearer ' + '$token';

    //\request.fields['paytm_kyc']= '${SelectedImage2!.path}';
    request.fields['Ac_number']= '$AccountNO';
    request.fields['bank_name']= '$BankName';
    request.fields['ifsc_code']= '$IfscCode';
    request.fields['holder_name']= '$HolderName';
    request.fields['paytm_no']= '$PaythmNo';
    request.fields['googlepay_no']= '$GoogleNo';
    request.fields['phonepay_no']= '$Phonepay';

    var response = await request.send();
    if (response.statusCode == 200) {
      final res = await http.Response.fromStream(response);
      var rest = jsonDecode(res.body);
      // print(res.body);
      if(rest['status'] == true){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${rest['message']}')));
        Get.offAll(Home_view());
      }else{
        alertBoxdialogBox(context, 'Alert', '${rest['message']}');
        //  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${data['message']}')));
      }
    } else {
      print("Failed to upload image. Status code: ${response.statusCode}");
    }
  }

  // Pincode get data

  Widget TransferInfo() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Text(
              'Bank Account Details',
              style: TextStyle(
                fontSize: 20,
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: bankName,
                gradient: appcolor.voidGradient,
                verticalContentPadding: 0,
                hinttext: 'Bank Name',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                newIcon: Container(
                  height: Get.height * 0.025,
                  child: Image(
                    image: AssetImage('assets/bank.png'),
                  ),
                ),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                key_type: TextInputType.number,
                controller: accounNo,
                gradient: appcolor.voidGradient,
                verticalContentPadding: 0,
                hinttext: 'Account Number',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                newIcon: Container(
                  height: Get.height * 0.025,
                  child: Image(
                    image: AssetImage('assets/bank.png'),
                  ),
                ),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: ifscCode,
                gradient: appcolor.voidGradient,
                verticalContentPadding: 0,
                hinttext: 'IFSC Code',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                newIcon: Container(
                  height: Get.height * 0.025,
                  child: Image(
                    image: AssetImage('assets/bank.png'),
                  ),
                ),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                 controller: accontHolderName,
                verticalContentPadding: 0,
                hinttext: 'Account Holder Name',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                newIcon: Container(
                  height: Get.height * 0.025,
                  child: Icon(Icons.person,color: appcolor.redColor,)
                ),
              ),
            ),
               Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                key_type: TextInputType.number,
                controller: paythmNo,
                gradient: appcolor.voidGradient,
                verticalContentPadding: 0,
                hinttext: 'Paytm Number',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                newIcon: Container(
                  height: Get.height * 0.025,
                  child: Image.asset('assets/phone.png',color: appcolor.redColor,)

                ),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                key_type: TextInputType.number,
                controller: googlePayNo,
                gradient: appcolor.voidGradient,
                verticalContentPadding: 0,
                hinttext: 'Google Pay Number',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                newIcon: Container(
                    height: Get.height * 0.025,
                    child: Image.asset('assets/phone.png',color: appcolor.redColor,)

                ),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                key_type: TextInputType.number,
                controller: phonePayNo,
                gradient: appcolor.voidGradient,
                verticalContentPadding: 0,
                hinttext: 'Phone Pay Number',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                newIcon: Container(
                    height: Get.height * 0.025,
                    child: Image.asset('assets/phone.png',color: appcolor.redColor,)

                ),
              ),
            ),
                Text(
                'Bank Documents',
                  style: TextStyle(
                   fontSize: 15,
                 ),
             ),
            SizedBox(height: 10,),
            Wrap(
              spacing: 10,
              children: [
                Column(
                  children: [
                    InkWell(
                      onTap: (){
                        showModalBottomSheet<void>(
                            context: context,
                            builder: (BuildContext context) {
                          return Container(
                            height: 80,
                            color:appcolor.redColor,
                            child: Center(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Column(
                                    children: [
                                      IconButton(onPressed: ()async{
                                        imagePickerCamera();
                                      }, icon: Icon(Icons.camera,color: Colors.white,),
                                      ),
                                      Text('Camera',style: TextStyle(color: Colors.white),),

                                    ],
                                  ),
                                  SizedBox(width: 40,),
                                  Column(
                                    children: [
                                      IconButton(onPressed: ()async{
                                        imagePicker();
                                      }, icon: FaIcon(FontAwesomeIcons.file,color: Colors.white,),
                                      ),
                                      Text('File',style: TextStyle(color: Colors.white),),
                                    ],
                                  ),
                                  // ElevatedButton(
                                  //   child: const Text('Close BottomSheet'),
                                  //   onPressed: () => Navigator.pop(context),
                                  // ),
                                ],
                              ),
                            ),
                          );
                        });
                      },
                      child: Container(
                        height: Get.height * 0.15,
                        width: Get.width * 0.27,
                        decoration: BoxDecoration(
                          color: Color(0xffD9D9D9),
                        ),
                        child: Center(
                          child: SelectedImage == null?Image.asset(
                              'assets/add.png',
                           
                          ):Image.file(SelectedImage!,fit: BoxFit.cover,),
                        ),
                      ),
                    ),
                    Text(
                      'Cancelled\nCheque',
                      style: TextStyle(fontSize: 14, height: 1),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
                Column(
                  children: [
                    InkWell(
                      onTap: (){
                        showModalBottomSheet<void>(
                            context: context,
                            builder: (BuildContext context) {
                          return Container(
                            height: 80,
                            color:appcolor.redColor,
                            child: Center(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Column(
                                    children: [
                                      IconButton(onPressed: ()async{
                                        imagePickerCamera1();
                                      }, icon: Icon(Icons.camera,color: Colors.white,),
                                      ),
                                      Text('Camera',style: TextStyle(color: Colors.white),),

                                    ],
                                  ),
                                  SizedBox(width: 40,),
                                  Column(
                                    children: [
                                      IconButton(onPressed: ()async{
                                        imagePicker1();
                                      }, icon: FaIcon(FontAwesomeIcons.file,color: Colors.white,),
                                      ),
                                      Text('File',style: TextStyle(color: Colors.white),),
                                    ],
                                  ),

                                  // ElevatedButton(
                                  //   child: const Text('Close BottomSheet'),
                                  //   onPressed: () => Navigator.pop(context),
                                  // ),
                                ],
                              ),
                            ),
                          );
                        },);
                      },
                      child: Container(
                        height: Get.height * 0.15,
                        width: Get.width * 0.27,
                        decoration: BoxDecoration(
                          color: Color(0xffD9D9D9),
                        ),
                        child: Center(
                          child: SelectedImage1 == null ? Image.asset(
                              'assets/add.png',
                            
                          ): Image.file(SelectedImage1!),
                        ),
                      ),
                    ),
                    Text(
                      'Passbook',
                      style: TextStyle(
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    InkWell(
                      onTap: (){
                        showModalBottomSheet<void>(
                            context: context,
                            builder: (BuildContext context) {
                          return Container(
                            height: 80,
                            color:appcolor.redColor,
                            child: Center(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Column(
                                    children: [
                                      IconButton(onPressed: ()async{
                                        imagePickerCamera2();
                                      }, icon: Icon(Icons.camera,color: Colors.white,),
                                      ),
                                      Text('Camera',style: TextStyle(color: Colors.white),),

                                    ],
                                  ),
                                  SizedBox(width: 40,),
                                  Column(
                                    children: [
                                      IconButton(onPressed: ()async{
                                        imagePicker2();
                                      }, icon: FaIcon(FontAwesomeIcons.file,color: Colors.white,),
                                      ),
                                      Text('File',style: TextStyle(color: Colors.white),),
                                    ],
                                  ),

                                  // ElevatedButton(
                                  //   child: const Text('Close BottomSheet'),
                                  //   onPressed: () => Navigator.pop(context),
                                  // ),
                                ],
                              ),
                            ),
                          );
                        },);
                      },
                      child: Container(
                        height: Get.height * 0.15,
                        width: Get.width * 0.27,
                        decoration: BoxDecoration(
                          color: Color(0xffD9D9D9),
                        ),
                        child: Center(
                          child:  SelectedImage2 ==null ?Image.asset(
                              'assets/add.png',
                            
                          ):Image.file(SelectedImage2!),
                        ),
                      ),
                    ),
                    Text(
                      'Paytm KYC\nScreenshot',
                      style: TextStyle(fontSize: 14, height: 1.1),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ],
            ),

            Container(
              height: Get.height * 0.055,
              child: blockButton(
                callback: () {
                  var AccountNO = accounNo.text.trim();
                  var BankName = bankName.text.trim().toString();
                  var IfscCode = ifscCode.text.trim().toString();
                  var HolderName = accontHolderName.text.trim().toString();
                  var PaythmNo = paythmNo.text.trim().toString();
                  var GoogleNo = googlePayNo.text.trim().toString();
                  var Phonepay = phonePayNo.text.trim().toString();
                  var valuess = {
                    "bank_name":BankName,
                    "Ac_number":AccountNO,
                    "ifsc_code":IfscCode,
                    "holder_name":HolderName,
                    "paytm_no":PaythmNo,
                    "googlepay_no":GoogleNo,
                    "phonepay_no":Phonepay,
                  };
                  if(SelectedImage == null || SelectedImage1 == null || SelectedImage2 == null){
                    ProfileUpdate('transferinfo',valuess);
                    setState(() {
                      isLoading1 =true;
                    });
                    Future.delayed(Duration(seconds: 4),(){
                      setState(() {
                        isLoading1 = false;
                      });
                    });

                  }else if(SelectedImage2 == null){
                    alertBoxdialogBox(context, 'Alert', 'Please upload all document');
                  }else if(SelectedImage1 == null){
                    alertBoxdialogBox(context, 'Alert', 'Please upload all document');

                  }else if(SelectedImage == null){
                    alertBoxdialogBox(context, 'Alert', 'Please upload all document');

                  }

                  else{
                    UpdateTransfer( AccountNO, BankName,IfscCode,HolderName ,PaythmNo,GoogleNo,Phonepay);
                    setState(() {
                      isLoading1 =true;
                    });
                    Future.delayed(Duration(seconds: 4),(){
                      setState(() {
                        isLoading1 = false;
                      });
                    });
                  }
                },
                width: Get.width * 0.3,
                widget:isLoading1== false? Text(
                  'Update',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      height: 1.2),
                ):SizedBox(
                    height: 10,
                    width: 10,
                    child: Center(child: CircularProgressIndicator(color: Colors.white,))),
                verticalPadding: 3,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> AadharDocumentInfo(String AccountNO,) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');
    var choose = profilegroupvalue.value.toString();
    var uri = Uri.parse('${apiDomain().domain}documentinfo'); // Replace with your server's endpoint
    var request = http.MultipartRequest("POST", uri)
      ..files.add(await http.MultipartFile.fromPath('aadhar_front', SelectedImage3!.path));
    request.files.add(await http.MultipartFile.fromPath('aadhar_back', SelectedImage4!.path));
    request.headers['Authorization'] =
        'Bearer ' + '$token';
    request.fields['aadhar_no']= '$AccountNO';
    var response = await request.send();
    if (response.statusCode == 200) {
      final res = await http.Response.fromStream(response);
      var rest = jsonDecode(res.body);
      if(rest['status'] == true){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${rest['message']}')));
       // Get.offAll(Home_view());
      }else{
        alertBoxdialogBox(context, 'Alert', '${rest['message']}');
        //  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${data['message']}')));
      }
    } else {
      print("Failed to upload image. Status code: ${response.statusCode}");
    }
  }
  Future<void> PanDocumentInfo(String AccountNO,gstno) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var token = prefs.getString('token');
    var choose = profilegroupvalue.value.toString();
    var uri = Uri.parse('${apiDomain().domain}documentinfo'); // Replace with your server's endpoint
    var request = http.MultipartRequest("POST", uri)
      ..files.add(await http.MultipartFile.fromPath('pan_card', SelectedImage5!.path));
    request.files.add(await http.MultipartFile.fromPath('gst_certificate', SelectedImage6!.path));
    request.files.add(await http.MultipartFile.fromPath('shop_image', SelectedImage7!.path));
    request.headers['Authorization'] =
        'Bearer ' + '$token';
    request.fields['pan_no']= '$AccountNO';
    request.fields['gst_no']= '$gstno';
    var response = await request.send();
    if (response.statusCode == 200) {
      final res = await http.Response.fromStream(response);
      var rest = jsonDecode(res.body);
      // print(res.body);
      if(rest['status'] == true){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${rest['message']}')));
        // Get.offAll(Home_view());
      }else{
        alertBoxdialogBox(context, 'Alert', '${rest['message']}');
        //  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${data['message']}')));
      }
    } else {
      print("Failed to upload image. Status code: ${response.statusCode}");
    }
  }

  Widget Documents() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 5,
            ),
            Text(
              'Aadhar Details',
              style: TextStyle(
                fontSize: 20,
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                maxLength: 12,
                controller: aadharno,
                gradient: appcolor.voidGradient,
                verticalContentPadding: 0,
                hinttext: 'Aadhar Number',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                key_type: TextInputType.number,
                newIcon: Container(
                  height: Get.height * 0.025,
                  child: Image(
                    image: AssetImage('assets/acctDetails.png'),
                  ),
                ),
              ),
            ),
            Wrap(
              spacing: 10,
              children: [
                Column(
                  children: [
                    Container(
                      height: Get.height * 0.18,
                      width: Get.width * 0.2,
                      child: Center(
                          child: Text(
                        'Upload\nAadhar\nCard',
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        textAlign: TextAlign.center,
                      )),
                    ),
                  ],
                ),
                Column(
                  children: [
                    InkWell(onTap: (){
                      showModalBottomSheet<void>(
                        context: context,
                        builder: (BuildContext context) {
                          return Container(
                            height: 80,
                            color:appcolor.redColor,
                            child: Center(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Column(
                                    children: [
                                      IconButton(onPressed: ()async{
                                        aadharFrontcamer();
                                      }, icon: Icon(Icons.camera,color: Colors.white,),
                                      ),
                                      Text('Camera',style: TextStyle(color: Colors.white),),

                                    ],
                                  ),
                                  SizedBox(width: 40,),
                                  Column(
                                    children: [
                                      IconButton(onPressed: ()async{
                                        aadharFront();
                                      }, icon: FaIcon(FontAwesomeIcons.file,color: Colors.white,),
                                      ),
                                      Text('File',style: TextStyle(color: Colors.white),),
                                    ],
                                  ),

                                  // ElevatedButton(
                                  //   child: const Text('Close BottomSheet'),
                                  //   onPressed: () => Navigator.pop(context),
                                  // ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                      child: Container(
                        height: Get.height * 0.18,
                        width: Get.width * 0.3,
                        decoration: BoxDecoration(
                          color: Color(0xffD9D9D9),
                        ),
                        child: Center(
                          child:SelectedImage3 == null?Image.asset( 'assets/add.png',):Image.file(SelectedImage3!)

                        ),
                      ),
                    ),
                    Text(
                      'Front Side',
                      style: TextStyle(
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    InkWell(
                      onTap: (){
                        showModalBottomSheet<void>(
                          context: context,
                          builder: (BuildContext context) {
                            return Container(
                              height: 80,
                              color:appcolor.redColor,
                              child: Center(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Column(
                                      children: [
                                        IconButton(onPressed: ()async{
                                          aadharbackCamera();
                                        }, icon: Icon(Icons.camera,color: Colors.white,),
                                        ),
                                        Text('Camera',style: TextStyle(color: Colors.white),),

                                      ],
                                    ),
                                    SizedBox(width: 40,),
                                    Column(
                                      children: [
                                        IconButton(onPressed: ()async{
                                          aadharback();
                                        }, icon: FaIcon(FontAwesomeIcons.file,color: Colors.white,),
                                        ),
                                        Text('File',style: TextStyle(color: Colors.white),),
                                      ],
                                    ),

                                    // ElevatedButton(
                                    //   child: const Text('Close BottomSheet'),
                                    //   onPressed: () => Navigator.pop(context),
                                    // ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                      child: Container(
                        height: Get.height * 0.18,
                        width: Get.width * 0.3,
                        decoration: BoxDecoration(
                          color: Color(0xffD9D9D9),
                        ),
                        child: Center(
                          child:SelectedImage4 == null?Image.asset('assets/add.png'):Image.file(SelectedImage4!)


                        ),
                      ),
                    ),
                    Text(
                      'Back Side',
                      style: TextStyle(fontSize: 14, height: 0),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(
              height: Get.height * 0.02,
            ),
          Container(
            height: Get.height * 0.055,
            child: blockButton(
              callback: () {
                // setState(() {
                //   isLoading3 =true;
                // });
                // Future.delayed(Duration(seconds: 2),(){
                //   setState(() {
                //     isLoading3 = false;
                //   });
                // });

                var Aadharno = aadharno.text.trim();
                if(SelectedImage3 == null && SelectedImage4 == null){
                  var value = {
                    "aadhar_no":Aadharno
                  };
                  ProfileUpdate('documentinfo',value);
                }else{
                  AadharDocumentInfo(Aadharno);
                }
              },
              width: Get.width * 0.3,
              widget: isLoading3 ==  false?Text(
                'Update',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    height: 1.2),
              ):SizedBox(height: 10,width: 10,child: CircularProgressIndicator(color: Colors.white,),),
              verticalPadding: 3,
            ),
          ),
            SizedBox(
              height: Get.height * 0.02,
            ),
            Text(
              'Details',
              style: TextStyle(fontSize: 20, height: 1),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: panNo,
                gradient: appcolor.voidGradient,
                verticalContentPadding: 0,
                key_type: TextInputType.name,
                hinttext: 'Pan Number',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                newIcon: Container(
                  height: Get.height * 0.025,
                  child: Image(
                    image: AssetImage('assets/acctDetails.png'),
                  ),
                ),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: GstNo,
                gradient: appcolor.voidGradient,
                verticalContentPadding: 0,
                key_type: TextInputType.name,
                hinttext: 'Gst Number',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
                newIcon: Container(
                  height: Get.height * 0.025,
                  child: Image(
                    image: AssetImage('assets/acctDetails.png'),
                  ),
                ),
              ),
            ),
            Wrap(
              spacing: 10,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Upload Pan card ',
                      style: TextStyle(
                        fontSize: 14,
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    InkWell(
                      onTap: (){
                        showModalBottomSheet<void>(
                          context: context,
                          builder: (BuildContext context) {
                            return Container(
                              height: 80,
                              color:appcolor.redColor,
                              child: Center(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Column(
                                      children: [
                                        IconButton(onPressed: ()async{
                                          pancardcamera();
                                        }, icon: Icon(Icons.camera,color: Colors.white,),
                                        ),
                                        Text('Camera',style: TextStyle(color: Colors.white),),

                                      ],
                                    ),
                                    SizedBox(width: 40,),
                                    Column(
                                      children: [
                                        IconButton(onPressed: ()async{
                                          pancard();
                                        }, icon: FaIcon(FontAwesomeIcons.file,color: Colors.white,),
                                        ),
                                        Text('File',style: TextStyle(color: Colors.white),),
                                      ],
                                    ),

                                    // ElevatedButton(
                                    //   child: const Text('Close BottomSheet'),
                                    //   onPressed: () => Navigator.pop(context),
                                    // ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                      child: Container(
                        height: Get.height * 0.15,
                        width: Get.width * 0.45,
                        decoration: BoxDecoration(
                          color: Color(0xffD9D9D9),
                        ),
                        child: Center(
                          child: SelectedImage5 == null ?Image.asset('assets/add.png'):Image.file(SelectedImage5!,fit: BoxFit.cover,),
                        ),
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'GST Certificate\nUpload',
                      style: TextStyle(
                        fontSize: 14,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(
                      width: 27,
                    ),
                    InkWell(
                      onTap: (){
                        showModalBottomSheet<void>(
                          context: context,
                          builder: (BuildContext context) {
                            return Container(
                              height: 80,
                              color:appcolor.redColor,
                              child: Center(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Column(
                                      children: [
                                        IconButton(onPressed: ()async{
                                          gstcamera();
                                        }, icon: Icon(Icons.camera,color: Colors.white,),
                                        ),
                                        Text('Camera',style: TextStyle(color: Colors.white),),

                                      ],
                                    ),
                                    SizedBox(width: 40,),
                                    Column(
                                      children: [
                                        IconButton(onPressed: ()async{
                                          gstupload();
                                        }, icon: FaIcon(FontAwesomeIcons.file,color: Colors.white,),
                                        ),
                                        Text('File',style: TextStyle(color: Colors.white),),
                                      ],
                                    ),

                                    // ElevatedButton(
                                    //   child: const Text('Close BottomSheet'),
                                    //   onPressed: () => Navigator.pop(context),
                                    // ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                      child: Container(
                        height: Get.height * 0.15,
                        width: Get.width * 0.45,
                        decoration: BoxDecoration(
                          color: Color(0xffD9D9D9),
                        ),
                        child: Center(
                          child: SelectedImage6 == null ? Image.asset('assets/add.png'):Image.file(SelectedImage6!,fit: BoxFit.cover,)


                        ),
                      ),
                    ),
                  ],
                ).marginOnly(top: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Shop Image      ',
                      style: TextStyle(
                        fontSize: 14,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(
                      width: 27,
                    ),
                    InkWell(
                      onTap: (){
                        showModalBottomSheet<void>(
                          context: context,
                          builder: (BuildContext context) {
                            return Container(
                              height: 80,
                              color:appcolor.redColor,
                              child: Center(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Column(
                                      children: [
                                        IconButton(onPressed: ()async{
                                          shopcamera();
                                        }, icon: Icon(Icons.camera,color: Colors.white,),
                                        ),
                                        Text('Camera',style: TextStyle(color: Colors.white),),

                                      ],
                                    ),
                                    SizedBox(width: 40,),
                                    Column(
                                      children: [
                                        IconButton(onPressed: ()async{
                                          shopImage();
                                        }, icon: FaIcon(FontAwesomeIcons.file,color: Colors.white,),
                                        ),
                                        Text('File',style: TextStyle(color: Colors.white),),
                                      ],
                                    ),

                                    // ElevatedButton(
                                    //   child: const Text('Close BottomSheet'),
                                    //   onPressed: () => Navigator.pop(context),
                                    // ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                      child: Container(
                        height: Get.height * 0.15,
                        width: Get.width * 0.45,
                        decoration: BoxDecoration(
                          color: Color(0xffD9D9D9),
                        ),
                        child: Center(
                          child:SelectedImage7 == null ?Image.asset('assets/add.png'):Image.file(SelectedImage7!,fit: BoxFit.cover,)


                        ),
                      ),
                    ),
                  ],
                ).marginOnly(top: 10),
              ],
            ),
            SizedBox(
              height: Get.height * 0.02,
            ),
            Container(
              height: Get.height * 0.055,
              child: blockButton(
                callback: () {
                  var Pan= panNo.text.trim();
                  var Gstno= GstNo.text.trim();

                  if(SelectedImage5 == null && SelectedImage6 == null && SelectedImage7 == null){
                    setState(() {
                      isLoading4 =true;
                    });
                    Future.delayed(Duration(seconds: 2),(){
                      setState(() {
                        isLoading4 = false;
                      });
                    });
                    var value = {
                      "pan_no":Pan,
                      "gst_no":Gstno,
                    };
                    ProfileUpdate('documentinfo',value);
                  }else{
                    setState(() {
                      isLoading4 =true;
                    });
                    Future.delayed(Duration(seconds: 2),(){
                      setState(() {
                        isLoading4 = false;
                      });
                    });
                    PanDocumentInfo(Pan,Gstno);
                  }
                },
                width: Get.width * 0.3,
                widget: isLoading4 ==  false?Text(
                  'Update',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      height: 1.2),
                ):SizedBox(height: 10,width: 10,child: CircularProgressIndicator(color: Colors.white,),),
                verticalPadding: 3,
              ),
            ),
            SizedBox(
              height: Get.height * 0.02,
            ),
          ],
        ),
      ),
    );
  }
  // Future AddationInfoUpdate(Object value)async{
  //   final SharedPreferences prefs = await SharedPreferences.getInstance();
  //   var token = prefs.getString('token');
  //
  //   final response = await http.post(Uri.parse('${apiDomain().domain}aditionalinfo'),body: jsonEncode(value),
  //       headers: ({
  //         'Content-Type': 'application/json; charset=UTF-8',
  //         'Accept': 'application/json',
  //         'Authorization': 'Bearer $token'
  //       }));
  //   if(response.statusCode == 200){
  //     final data = jsonDecode(response.body);
  //     if(data['status']== true){
  //       Get.offAll(Home_view());
  //       ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${data['message']}')));
  //     }else{
  //       alertBoxdialogBox(context, 'Alert', '${data['message']}');
  //     }
  //     return data[0];
  //   }
  // }
  Widget AdditionalInfo() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 5,
            ),
            // Text(
            //   'Electrician Form',
            //   style: TextStyle(fontSize: 20, height: 1),
            // ),
            SizedBox(height: 5,),
            Text(
              'kindly Fill the following Details',
              style: TextStyle(
                fontSize: 14,
                height: 1,
              ),
            ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.symmetric(horizontal: 0),
              height: Get.height * 0.05,
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: Color(0xffb8b8b8),
                  ),
                ),
                color: Colors.transparent,
              ),
              child: Center(
                child: DropdownButtonFormField(
                  decoration: InputDecoration.collapsed(
                    hintText: 'Nationality',
                    hintStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 13,
                      height: 2.5,
                    ),
                  ),
                  value: value,
                  onChanged: (value) {},
                  items: [
                    DropdownMenuItem(
                      child: Text(
                        'India',
                        style: TextStyle(
                          fontSize: 13,
                        ),
                      ),
                      value: 1,
                    ),
                    DropdownMenuItem(
                        child: Text(
                          'Nepal',
                          style: TextStyle(
                            fontSize: 13,
                          ),
                        ),
                        value: 2),
                  ],
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.symmetric(horizontal: 0),
              height: Get.height * 0.05,
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: Color(0xffb8b8b8),
                  ),
                ),
                color: Colors.transparent,
              ),
              child: Center(
                child: DropdownButtonFormField(
                  decoration: InputDecoration.collapsed(
                    hintText: 'Marital Status',
                    hintStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 13,
                      height: 2.5,
                    ),
                  ),
                  value: value,
                  onChanged: (value) {},
                  items: [
                    DropdownMenuItem(
                      child: Text(
                        'Married',
                        style: TextStyle(
                          fontSize: 13,
                        ),
                      ),
                      value: 1,
                    ),
                    DropdownMenuItem(
                        child: Text(
                          'Unmarried',
                          style: TextStyle(
                            fontSize: 13,
                          ),
                        ),
                        value: 2),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Text(
                  'Children Info',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    height: 1,
                  ),
                ),
              ],
            ).paddingSymmetric(horizontal: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Radio(
                      value: 1,
                      groupValue: radioSelectedd,
                      activeColor: Colors.red,
                      onChanged: (value) {
                        setState(() {
                          radioSelectedd = value as int;
                          radioVall = '1';
                          //  print(_radioVal);
                        });
                      },
                    ),
                    const Text("1"),
                  ],
                ),
                Row(
                  children: [
                    Radio(
                      value: 2,
                      groupValue: radioSelectedd,
                      activeColor: Colors.red,
                      onChanged: (value) {
                        setState(() {
                          radioSelectedd = value as int;
                          radioVall = '2';
                          print(radioVall);
                        });
                      },
                    ),
                    const Text("2"),
                  ],
                ),
                Row(
                  children: [
                    Radio(
                      value: 3,
                      groupValue: radioSelectedd,
                      activeColor: Colors.red,
                      onChanged: (value) {
                        setState(() {
                          radioSelectedd = value as int;
                          radioVall = '3';
                          print(radioVall);
                        });
                      },
                    ),
                    const Text("3"),
                  ],
                ),
              ],
            ),
            radioVall == '1' ?
            Column(
              children: [
                //Text('First Child Info',style: TextStyle(fontSize: 16),),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: Get.height * 0.055,
                      width: Get.width * 0.45,
                      child: customtextformfield(
                        controller: firstname,
                          hinttext: 'Name',
                          hintTextColor: Colors.black,
                          bottomLineColor: Color(0xffb8b8b8)),
                    ),
                    Container(
                      height: Get.height * 0.055,
                      width: Get.width * 0.45,
                      child: customtextformfield(
                        controller: firstdob,
                        readOnly: true,
                        callback: ()async{
                          AdditionalDate1 =
                          await profileController.showdatepicker(context);
                      setState(() {});
                        },
                          key_type: TextInputType.datetime,
                          hinttext: AdditionalDate1==''? 'Birth Date':AdditionalDate1,
                          hintTextColor: Colors.black,
                          newIcon: Container(
                            height: Get.height * 0.025,
                            child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)
                          ),
                          bottomLineColor: Color(0xffb8b8b8)),
                    ),
                  ],
                ),
                Container(
                  height: Get.height * 0.055,
                  child: customtextformfield(
                    controller: studyfirst,
                    verticalContentPadding: 0,
                    hinttext: 'Study In',
                    hintTextColor: Colors.black,
                    bottomLineColor: Color(0xffb8b8b8),
                    // newIcon: Container(
                    //   height: Get.height * 0.025,
                    //     child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)
                    // ),
                  ),
                ),
              ],
            ) :
            radioVall == '2'?
            Column(
              children: [
               // Text('First Child Info',style: TextStyle(fontSize: 15),),
               // Text('First Child Info',style: TextStyle(fontSize: 15,color: appcolor.redColor),),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: Get.height * 0.055,
                      width: Get.width * 0.45,
                      child: customtextformfield(
                        controller: firstname,
                          hinttext: '1st Name',
                          hintTextColor: Colors.black,
                          bottomLineColor: Color(0xffb8b8b8)),
                    ),
                    Container(
                      height: Get.height * 0.055,
                      width: Get.width * 0.45,
                      child: customtextformfield(
                        controller: firstdob,
                          readOnly: true,
                          callback: ()async{
                            AdditionalDate1 =
                            await profileController.showdatepicker(context);
                            setState(() {});
                          },
                          key_type: TextInputType.datetime,
                          hinttext:AdditionalDate1==''? '1st Birth Date':AdditionalDate1,
                          hintTextColor: Colors.black,
                          newIcon: Container(
                              height: Get.height * 0.025,
                              child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)

                          ),
                          bottomLineColor: Color(0xffb8b8b8)),
                    ),
                  ],
                ),
                Container(
                  height: Get.height * 0.055,
                  child: customtextformfield(
                    controller: studyfirst,
                    verticalContentPadding: 0,
                    hinttext: '1st Study In',
                    hintTextColor: Colors.black,
                    bottomLineColor: Color(0xffb8b8b8),
                    // newIcon: Container(
                    //   height: Get.height * 0.025,
                    //     child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)
                    // ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: Get.height * 0.055,
                      width: Get.width * 0.45,
                      child: customtextformfield(
                        controller: secondname,
                          hinttext: '2nd Name',
                          hintTextColor: Colors.black,
                          bottomLineColor: Color(0xffb8b8b8)),
                    ),
                    Container(
                      height: Get.height * 0.055,
                      width: Get.width * 0.45,
                      child: customtextformfield(
                        controller: seconddob,
                          readOnly: true,
                          callback: ()async{
                            AdditionalDate1 =
                            await profileController.showdatepicker(context);
                            setState(() {});
                          },
                          key_type: TextInputType.datetime,
                          hinttext:AdditionalDate1==''? '2nd Birth Date':AdditionalDate1,
                          hintTextColor: Colors.black,
                          newIcon: Container(
                              height: Get.height * 0.025,
                              child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)

                          ),
                          bottomLineColor: Color(0xffb8b8b8)),
                    ),
                  ],
                ),
                Container(
                  height: Get.height * 0.055,
                  child: customtextformfield(
                    controller: secondstudyin,
                    verticalContentPadding: 0,
                    hinttext: '2nd Study In',
                    hintTextColor: Colors.black,
                    bottomLineColor: Color(0xffb8b8b8),
                    // newIcon: Container(
                    //   height: Get.height * 0.025,
                    //     child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)
                    // ),
                  ),
                ),
              ],
            ) :
            radioVall == '3'?
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: Get.height * 0.055,
                      width: Get.width * 0.45,
                      child: customtextformfield(
                        controller: firstname,
                          hinttext: '1st Name',
                          hintTextColor: Colors.black,
                          bottomLineColor: Color(0xffb8b8b8)),
                    ),
                    Container(
                      height: Get.height * 0.055,
                      width: Get.width * 0.45,
                      child: customtextformfield(
                        controller: firstdob,
                          readOnly: true,
                          callback: ()async{
                            AdditionalDate1 =
                            await profileController.showdatepicker(context);
                            setState(() {});
                          },
                          key_type: TextInputType.datetime,
                          hinttext:AdditionalDate1==''? '1st Birth Date':AdditionalDate1,
                          hintTextColor: Colors.black,
                          newIcon: Container(
                              height: Get.height * 0.025,
                              child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)

                          ),
                          bottomLineColor: Color(0xffb8b8b8)),
                    ),
                  ],
                ),
                Container(
                  height: Get.height * 0.055,
                  child: customtextformfield(
                    controller: studyfirst,
                    verticalContentPadding: 0,
                    hinttext: '1st Study In',
                    hintTextColor: Colors.black,
                    bottomLineColor: Color(0xffb8b8b8),
                    // newIcon: Container(
                    //   height: Get.height * 0.025,
                    //     child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)
                    // ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: Get.height * 0.055,
                      width: Get.width * 0.45,
                      child: customtextformfield(
                        controller: secondname,
                          hinttext: '2nd Name',
                          hintTextColor: Colors.black,
                          bottomLineColor: Color(0xffb8b8b8)),
                    ),
                    Container(
                      height: Get.height * 0.055,
                      width: Get.width * 0.45,
                      child: customtextformfield(
                        controller: seconddob,
                          readOnly: true,
                          callback: ()async{
                            AdditionalDate1 =
                            await profileController.showdatepicker(context);
                            setState(() {});
                          },
                          key_type: TextInputType.datetime,
                          hinttext:AdditionalDate1==''? '2nd Birth Date':AdditionalDate1,
                          hintTextColor: Colors.black,
                          newIcon: Container(
                              height: Get.height * 0.025,
                              child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)

                          ),
                          bottomLineColor: Color(0xffb8b8b8)),
                    ),
                  ],
                ),
                Container(
                  height: Get.height * 0.055,
                  child: customtextformfield(
                    controller: secondstudyin,
                    verticalContentPadding: 0,
                    hinttext: '2nd Study In',
                    hintTextColor: Colors.black,
                    bottomLineColor: Color(0xffb8b8b8),
                    // newIcon: Container(
                    //   height: Get.height * 0.025,
                    //     child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)
                    // ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: Get.height * 0.055,
                      width: Get.width * 0.45,
                      child: customtextformfield(
                        controller: thrdname,
                          hinttext: '3rd Name',
                          hintTextColor: Colors.black,
                          bottomLineColor: Color(0xffb8b8b8)),
                    ),
                    Container(
                      height: Get.height * 0.055,
                      width: Get.width * 0.45,
                      child: customtextformfield(
                        controller: thrddob,
                          readOnly: true,
                          callback: ()async{
                            AdditionalDate1 =
                            await profileController.showdatepicker(context);
                            setState(() {});
                          },
                          key_type: TextInputType.datetime,
                          hinttext: AdditionalDate1==''? '3rd Birth Date':AdditionalDate1,
                          hintTextColor: Colors.black,
                          newIcon: Container(
                              height: Get.height * 0.025,
                              child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)
                          ),
                          bottomLineColor: Color(0xffb8b8b8)),
                    ),
                  ],
                ),
                Container(
                  height: Get.height * 0.055,
                  child: customtextformfield(
                    controller: thrdstudy,
                    verticalContentPadding: 0,
                    hinttext: '3rd Study In',
                    hintTextColor: Colors.black,
                    bottomLineColor: Color(0xffb8b8b8),
                    // newIcon: Container(
                    //   height: Get.height * 0.025,
                    //     child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)
                    // ),
                  ),
                ),
              ],
            ):

            // Container(
            //   height: Get.height * 0.055,
            //   child: customtextformfield(
            //     verticalContentPadding: 0,
            //     hinttext: 'Study In',
            //     hintTextColor: Colors.black,
            //     bottomLineColor: Colors.black,
            //     // newIcon: Container(
            //     //   height: Get.height * 0.025,
            //     //     child:Image.asset('assets/birthdate.png',color: appcolor.redColor,)
            //     // ),
            //   ),
            // ),
            SizedBox(height: 20,),
            // Container(
            //   margin: EdgeInsets.symmetric(horizontal: 10),
            //   padding: EdgeInsets.symmetric(horizontal: 0),
            //   height: Get.height * 0.05,
            //   decoration: BoxDecoration(
            //     border: Border(
            //       bottom: BorderSide(
            //         color: Color(0xffb8b8b8),
            //       ),
            //     ),
            //     color: Colors.transparent,
            //   ),
            //   child: Center(
            //     child: DropdownButtonFormField(
            //       decoration: InputDecoration.collapsed(
            //         hintText: 'Blood Group',
            //         hintStyle: TextStyle(
            //           color: Colors.black,
            //           fontSize: 13,
            //           height: 2.5,
            //         ),
            //       ),
            //       value: value,
            //       onChanged: (value) {},
            //       items: [
            //         DropdownMenuItem(
            //           child: Text(
            //             'A+',
            //             style: TextStyle(
            //               fontSize: 13,
            //             ),
            //           ),
            //           value: 1,
            //         ),
            //         DropdownMenuItem(
            //             child: Text(
            //               'A-',
            //               style: TextStyle(
            //                 fontSize: 13,
            //               ),
            //             ),
            //             value: 2),
            //         DropdownMenuItem(
            //             child: Text(
            //               'B+',
            //               style: TextStyle(
            //                 fontSize: 13,
            //               ),
            //             ),
            //             value: 3,),
            //         DropdownMenuItem(
            //           child: Text(
            //             'B-',
            //             style: TextStyle(
            //               fontSize: 13,
            //             ),
            //           ),
            //           value: 4,),
            //         DropdownMenuItem(
            //           child: Text(
            //             'AB+',
            //             style: TextStyle(
            //               fontSize: 13,
            //             ),
            //           ),
            //           value: 5,),
            //         DropdownMenuItem(
            //           child: Text(
            //             'AB-',
            //             style: TextStyle(
            //               fontSize: 13,
            //             ),
            //           ),
            //           value: 6,),
            //         DropdownMenuItem(
            //           child: Text(
            //             'O+',
            //             style: TextStyle(
            //               fontSize: 13,
            //             ),
            //           ),
            //           value: 7,),
            //         DropdownMenuItem(
            //           child: Text(
            //             'O-',
            //             style: TextStyle(
            //               fontSize: 13,
            //             ),
            //           ),
            //           value: 8,),
            //       ],
            //     ),
            //   ),
            // ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.symmetric(horizontal: 0),
              height: Get.height * 0.05,
              // width: Get.width * 0.3,
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: Color(0xffb8b8b8),
                  ),
                ),
                color: Colors.transparent,
              ),
              child: Center(
                child: DropdownButtonFormField(
                  decoration: InputDecoration.collapsed(
                    hintText: 'Blood Group',
                    hintStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 13,
                      height: 2.5,
                    ),
                  ),
                  value: value,
                  onChanged: (value) {},
                  items: [
                    DropdownMenuItem(
                      child: Text(
                        'A+',
                        style: TextStyle(
                          fontSize: 13,
                        ),
                      ),
                      value: 1,
                    ),
                    DropdownMenuItem(
                        child: Text(
                          'A-',
                          style: TextStyle(
                            fontSize: 13,
                          ),
                        ),
                        value: 2),
                    DropdownMenuItem(
                      child: Text(
                        'B+',
                        style: TextStyle(
                          fontSize: 13,
                        ),
                      ),
                      value: 3,),
                    DropdownMenuItem(
                      child: Text(
                        'B-',
                        style: TextStyle(
                          fontSize: 13,
                        ),
                      ),
                      value: 4,),
                    DropdownMenuItem(
                      child: Text(
                        'AB+',
                        style: TextStyle(
                          fontSize: 13,
                        ),
                      ),
                      value: 5,),
                    DropdownMenuItem(
                      child: Text(
                        'AB-',
                        style: TextStyle(
                          fontSize: 13,
                        ),
                      ),
                      value: 6,),
                    DropdownMenuItem(
                      child: Text(
                        'O+',
                        style: TextStyle(
                          fontSize: 13,
                        ),
                      ),
                      value: 7,),
                    DropdownMenuItem(
                      child: Text(
                        'O-',
                        style: TextStyle(
                          fontSize: 13,
                        ),
                      ),
                      value: 8,),
                  ],
                ),
              ),
            ),
            SizedBox(height: 10,),
            Container(
              margin: EdgeInsets.only(top: 0),
              height: Get.height * 0.055,

              child: customtextformfield(
                controller: workExperience,
                verticalContentPadding: 0,
                hinttext: 'Total Work Experience',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
              ),
            ),


            Container(
              margin: EdgeInsets.only(top: 0),
              height: Get.height * 0.055,

              child: customtextformfield(
                controller: reading,
                verticalContentPadding: 0,
                hinttext: 'Language Known(Reading)',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: writings,
                verticalContentPadding: 0,
                hinttext: 'Language Known(Writing)',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: speaking,
                verticalContentPadding: 0,
                hinttext: 'Language Known(Speaking)',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: customtextformfield(
                controller: cin,
                verticalContentPadding: 0,
                hinttext: 'Dealer/Partner/CIN',
                hintTextColor: Colors.black,
                bottomLineColor: Color(0xffb8b8b8),
              ),
            ),
            Container(
              height: Get.height * 0.055,
              child: blockButton(
                callback: () {
                  var value = {
                    'nationality':groupValue.value == '1'?'india':'nepal',
                    'marital_status':groupValue.value == '1'?'married':'unmarried',
                    'children_info':radioVall ,
                    'oneChildStudy':studyfirst.text.trim().toString() ,
                    'oneChildDate':firstdob.text.trim().toString() ,
                    'secondChildName':secondname.text.trim().toString() ,
                    'secondChildDate':seconddob.text.trim().toString() ,
                    'secondChildStudy':secondstudyin.text.trim().toString() ,
                    'thirdChildName':thrdname.text.trim().toString() ,
                    'thirdChildDate':thrddob.text.trim().toString() ,
                    'thirdChildStudy':thrdstudy.text.trim().toString() ,
                    'bloodgroup':groupValue.value == '1'?'A+':groupValue.value == '2'?'A-':groupValue.value == '3'?'B+':groupValue.value == '4'?'B-':groupValue.value == '5'?'AB+':groupValue.value == '6'?'AB-':groupValue.value == '7'?'O+':'O-',
                    'experiance':workExperience.text.trim(),
                    "reading":reading.text.trim().toString(),
                    "writing":writings.text.trim().toString(),
                    "speaking":speaking.text.trim().toString(),
                    "partne":cin.text.trim().toString(),
                  };
                  setState(() {
                    isLoading5 =true;
                  });
                  Future.delayed(Duration(seconds: 2),(){
                    setState(() {
                      isLoading5 = false;
                    });
                  });
                  ProfileUpdate('aditionalinfo',value);
                },
                width: Get.width * 0.3,
                widget: isLoading5 == false?Text(
                  'Update',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      height: 1.2),
                ):SizedBox(height: 10,width: 10,child: CircularProgressIndicator(color: Colors.white,),),
                verticalPadding: 3,
              ),
            ),
            SizedBox(
              height: Get.height * 0.02,
            ),
          ],
        ),
      ),
    );
  }
}
