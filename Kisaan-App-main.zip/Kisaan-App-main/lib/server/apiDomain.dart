class apiDomain{
  final domain = 'https://kissan.qbacp.com/api/';
}