import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:kisaan_electric/CartPage.dart';
import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/blockButton.dart';
import 'package:kisaan_electric/global/custom_drawer.dart';
import 'package:kisaan_electric/global/gradient_text.dart';
import 'package:kisaan_electric/products/view/all_product.dart';
import 'package:kisaan_electric/products/view/ceilingfan_view.dart';
import 'package:kisaan_electric/products/view/eco_series_view.dart';
import 'package:kisaan_electric/whatsaapIcon/WhatsaapIcon.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../server/apiDomain.dart';
import 'detailed_product_view.dart';

class product_view extends StatefulWidget {
  const product_view({super.key});

  @override
  State<product_view> createState() => _product_viewState();
}

class _product_viewState extends State<product_view> {
  late StreamSubscription subscription;
  bool isDeviceConnected = false;
  bool isAlertSet = false;
  getConnectivity() =>
      subscription = Connectivity().onConnectivityChanged.listen(
            (ConnectivityResult result) async {
          isDeviceConnected = await InternetConnectionChecker().hasConnection;
          if (!isDeviceConnected && isAlertSet == false) {
            showDialogBox();
            setState(() => isAlertSet = true);
          }
        },
      );
  showDialogBox() => showCupertinoDialog<String>(
    context: context,
    builder: (BuildContext context) => CupertinoAlertDialog(
      title: const Text('No Connection'),
      content: const Text('Please check your internet connectivity'),
      actions: <Widget>[
        TextButton(
          onPressed: () async {
            Navigator.pop(context, 'Cancel');
            setState(() => isAlertSet = false);
            isDeviceConnected =
            await InternetConnectionChecker().hasConnection;
            if (!isDeviceConnected && isAlertSet == false) {
              showDialogBox();
              setState(() => isAlertSet = true);
            }
          },
          child: const Text('OK'),
        ),
      ],
    ),
  );
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getConnectivity();
  }
  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
            color: Colors.white
          // image: DecorationImage(
          //     image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
        child: Scaffold(
          drawer: customDrawer(context,),
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            flexibleSpace: Container(
              decoration: BoxDecoration(
                gradient: appcolor.gradient,
              ),
            ),
            title: Container(
              height: Get.height * 0.05,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(
                  8,
                ),
                border: Border.all(
                  color: Colors.white,
                ),
              ),
              width: Get.width * 0.7,
              child: Center(
                child: TextFormField(
                  keyboardType: TextInputType.visiblePassword,
                  cursorHeight: 24,
                  cursorColor: Colors.white,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                  decoration: InputDecoration(
                      enabledBorder: InputBorder.none,
                      disabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      hintText: 'Search',
                      hintStyle: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                      ),
                      contentPadding: EdgeInsets.symmetric(
                        vertical: 10,
                        horizontal: 10,
                      )),
                ),
              ),
            ),
            leadingWidth: 35,
            actions: [
              IconButton(
                onPressed: () async{
               //    final SharedPreferences prefs = await SharedPreferences.getInstance();
               // var data =   prefs.getString('pro');
               // if(data == 'dealer'){
               //   Get.to(CartPage());
               // }
                },
                icon: Icon(
                  Icons.shopping_cart_outlined,
                ),
                color: Colors.white,
              ),
            ],
            leading: Builder(
              builder: (context) {
                return IconButton(
                  onPressed: () {
                    Scaffold.of(context).openDrawer();
                  },
                  icon: Icon(
                    Icons.sort,color: Colors.white,
                  ),
                );
              },
            ),
            backgroundColor: Colors.transparent,
            elevation: 0,
          ),
          body: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // SizedBox(height: 50,),
                // Center(child: Text('Coming Soon',style: TextStyle(fontWeight: FontWeight.w700,fontSize: 17),))
                 Container(
                  height: 120,
                  width: Get.width,
                  child: Image(
                    image: AssetImage(
                      'assets/4279110 1.png',
                    ),
                    fit: BoxFit.fill,
                  ),
                ),
                Column(
                  children: [
                    Row(
                      children: [
                        GradientText(
                          gradient: appcolor.gradient,
                          widget: Text(
                            'Series',
                            style: TextStyle(
                              fontSize: 20,
                              height: 1,color: appcolor.redColor
                            ),
                          ),
                        ),
                      ],
                    ).paddingOnly(
                      bottom: 10,
                    ),
                    Container(
                      height: Get.height* 0.16,
                      child: FutureBuilder(
                          future: api().GetData('allSeries',''),
                          builder: (context, snapshot){
                            if(snapshot.hasError){
                              return Image.asset('${apiDomain().nodataimage}');
                            }else if(snapshot.connectionState ==ConnectionState.waiting){
                              return Center(child: CircularProgressIndicator(),);
                            }else if(snapshot.hasData){
                              return ListView.builder(
                                shrinkWrap: true,
                                 scrollDirection: Axis.horizontal,
                                  itemCount: snapshot.data.length,
                                  itemBuilder: (context, index){
                                  var data = snapshot.data[index];
                                  return InkWell(
                                    onTap: (){
                                      Get.to(ecoSeries_view(id: data['id'],name: data['name'],));
                                    },
                                    child:
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Container(
                                          child: Column(
                                            children: [
                                              Container(
                                                  decoration: BoxDecoration(
                                                      border: Border.all(color: appcolor.redColor,width:2 ),
                                                    borderRadius: BorderRadius.circular(11)
                                                  ),
                                                height:60,
                                                width: 80,
                                                padding: EdgeInsets.only(
                                                  bottom: 4,
                                                ),
                                                child: Image.network('${apiDomain().imageUrl+data['image']}',fit: BoxFit.cover,)
                                              ),
                                              Text(
                                                '${data['Series']}',
                                                style: TextStyle(
                                                  fontSize: 14,
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                        SizedBox(width: 30,),
                                      ],
                                    ),
                                  ).paddingOnly(
                                    bottom: 10,
                                  );
                                  });
                            }else{
                              return Center(child: CircularProgressIndicator(),);
                            }
                          }),
                    ),
                    Row(
                      children: [
                        InkWell(
                          onTap: (){
                            Get.to(ecoSeries_view());
                          },
                          child: GradientText(
                            gradient: appcolor.gradient,
                            widget: Text(
                              'All Categories',
                              style: TextStyle(
                                fontSize: 20,
                                height: 1,color: appcolor.redColor
                              ),
                            ),
                          ),
                        ),
                      ],
                    ).paddingOnly(
                      bottom: 10,
                    ),
                    // All category data fetch
                    Container(
                      height: Get.height * 0.26,
                      child: FutureBuilder(
                          future: api().GetData('allCategory',''),
                          builder: (context, snapshot){
                            if(snapshot.hasError){
                              return Text('Data Not Found');
                            }else if(snapshot.connectionState == ConnectionState.waiting){
                              return Center(child: CircularProgressIndicator(),);
                            }else if(snapshot.hasData){
                              return ListView.builder(
                                itemCount: snapshot.data.length,
                                  itemBuilder: (context, index){
                                  return  GridView.builder(
                                    physics:AlwaysScrollableScrollPhysics() ,
                                    shrinkWrap: true,
                                     scrollDirection: Axis.vertical,
                                    itemCount: snapshot.data.length,
                                    gridDelegate:  SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 3
                                    ),
                                    itemBuilder: (context, index) {
                                      var data = snapshot.data[index];
                                      return
                                          InkWell(
                                            onTap: (){
                                              Get.to(ceiling_fan(id: data['id'],));
                                            },
                                            child: Container(
                                              child: Column(
                                                children: [
                                                  Container(
                                                    height:60,
                                                    width: 60,
                                                    padding: EdgeInsets.only(
                                                      bottom: 4,
                                                    ),
                                                    child: Image.network('${apiDomain().imageUrl+data['image']}',fit: BoxFit.cover,)
                                                  ),
                                                  Text(
                                                    '${data['category']}',
                                                    style: TextStyle(
                                                      fontSize: 14,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          );

                                    },
                                  );


                                  });
                            }else {
                              return Center(child: CircularProgressIndicator(),);
                            }
                          }),
                    ),

                    Column(
                      children: [
                        Row(
                          children: [
                            GradientText(
                              gradient: appcolor.gradient,
                              widget: Text(
                                'All Product',
                                style: TextStyle(
                                    fontSize: 20,
                                    height: 1,color: appcolor.redColor
                                ),
                              ),
                            ),
                          ],
                        ).paddingOnly(
                          bottom: 10,
                        ),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: [
                              Wrap(
                                spacing: 8,
                                children: <Widget>[
                                  Container(
                                    height: 100,
                                    child: FutureBuilder(
                                        future: api().GetData('allProduct',''),
                                        builder: (context,snapshot){
                                          if(snapshot.hasError){
                                            return Text('Data not Fount');
                                          }else if(snapshot.connectionState == ConnectionState.waiting){
                                            return Center(child: CircularProgressIndicator(),);
                                          }else if(snapshot.hasData){
                                            return ListView.builder(
                                              itemCount: snapshot.data.length,
                                              shrinkWrap: true,
                                                scrollDirection: Axis.horizontal,
                                                itemBuilder: (context, index){
                                                  var data = snapshot.data[index];
                                                  return  InkWell(
                                                    onTap:(){
                                                      Get.to(detailedProductView(name: data['name'],));
                                                    },
                                                    child: Card(
                                                      elevation: 1,
                                                      child: Container(
                                                        width: Get.width * 0.28,
                                                        height: Get.height * 0.11,
                                                        decoration: BoxDecoration(
                                                          color: Color(0xffEEEEEE),
                                                          borderRadius: BorderRadius.circular(
                                                            8,
                                                          ),
                                                          //  border: Border.all(color: Color(0xff3C2B99)),
                                                        ),
                                                        child: Column(
                                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                          children: [
                                                            Container(

                                                              height: Get.height * 0.06,
                                                              child: Image.network('${apiDomain().imageUrl+data['image']}',fit: BoxFit.cover,)
                                                            ),
                                                            Text(
                                                              '${data['name']}',
                                                              style: TextStyle(
                                                                fontSize: 10,
                                                              ),
                                                              textAlign: TextAlign.center,
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  );
                                                });
                                          }else{
                                            return Center(child: CircularProgressIndicator(),);
                                          }
                                        }),
                                  )

                                  // InkWell(
                                  //   onTap: (){
                                  //     Get.to(allProduct());
                                  //   },
                                  //   child: Card(elevation: 1,
                                  //     child: Container(
                                  //       width: Get.width * 0.28,
                                  //       height: Get.height * 0.11,
                                  //       decoration: BoxDecoration(
                                  //         color: Color(0xffEEEEEE),
                                  //         borderRadius: BorderRadius.circular(
                                  //           8,
                                  //         ),
                                  //         //   border: Border.all(color: Color(0xff3C2B99)),
                                  //       ),
                                  //       child: Column(
                                  //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  //         children: [
                                  //           Container(
                                  //             height: Get.height * 0.06,
                                  //             child: Image(
                                  //                 image: AssetImage('assets/image1 1.png')),
                                  //           ),
                                  //           Text(
                                  //             'CONCEALED BOX',
                                  //             style: TextStyle(
                                  //               fontSize: 10,
                                  //             ),
                                  //             textAlign: TextAlign.center,
                                  //           ),
                                  //         ],
                                  //       ),
                                  //     ),
                                  //   ),
                                  // ),
                                  // InkWell(
                                  //   onTap: (){
                                  //     Get.to(allProduct());
                                  //   },
                                  //   child: Card(
                                  //     elevation: 1,
                                  //     child: Container(
                                  //       width: Get.width * 0.28,
                                  //       height: Get.height * 0.11,
                                  //       decoration: BoxDecoration(
                                  //         color: Color(0xffEEEEEE),
                                  //         borderRadius: BorderRadius.circular(
                                  //           8,
                                  //         ),
                                  //         // border: Border.all(color: Color(0xff3C2B99)),
                                  //       ),
                                  //       child: Column(
                                  //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  //         children: [
                                  //           Container(
                                  //             height: Get.height * 0.06,
                                  //             child: Image(
                                  //                 image: AssetImage('assets/image 4.png')),
                                  //           ),
                                  //           Text(
                                  //             'FAN BOXS',
                                  //             style: TextStyle(
                                  //               fontSize: 10,
                                  //             ),
                                  //             textAlign: TextAlign.center,
                                  //           ),
                                  //         ],
                                  //       ),
                                  //     ),
                                  //   ),
                                  // ),
                                  // InkWell(
                                  //   onTap: (){
                                  //     Get.to(allProduct());
                                  //   },
                                  //   child: Card(elevation: 1,
                                  //     child: Container(
                                  //       width: Get.width * 0.28,
                                  //       height: Get.height * 0.11,
                                  //       decoration: BoxDecoration(
                                  //         color: Color(0xffEEEEEE),
                                  //         borderRadius: BorderRadius.circular(
                                  //           8,
                                  //         ),
                                  //         //  border: Border.all(color: Color(0xff3C2B99)),
                                  //       ),
                                  //       child: Column(
                                  //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  //         children: [
                                  //           Container(
                                  //             height: Get.height * 0.06,
                                  //             child: Image(
                                  //                 image: AssetImage('assets/image1 1.png')),
                                  //           ),
                                  //           Text(
                                  //             'CONCEALED BOX',
                                  //             style: TextStyle(
                                  //               fontSize: 10,
                                  //             ),
                                  //             textAlign: TextAlign.center,
                                  //           ),
                                  //         ],
                                  //       ),
                                  //     ),
                                  //   ),
                                  // ),
                                  // InkWell(
                                  //   onTap: (){
                                  //     Get.to(allProduct());
                                  //   },
                                  //   child: Card(
                                  //     elevation: 1,
                                  //     child: Container(
                                  //       width: Get.width * 0.28,
                                  //       height: Get.height * 0.11,
                                  //       decoration: BoxDecoration(
                                  //         color: Color(0xffEEEEEE),
                                  //         borderRadius: BorderRadius.circular(
                                  //           8,
                                  //         ),
                                  //         //    border: Border.all(color: Color(0xff3C2B99)),
                                  //       ),
                                  //       child: Column(
                                  //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  //         children: [
                                  //           Container(
                                  //             height: Get.height * 0.06,
                                  //             child: Image(
                                  //                 image: AssetImage('assets/image 4.png')),
                                  //           ),
                                  //           Text(
                                  //             'FAN BOXS',
                                  //             style: TextStyle(
                                  //               fontSize: 10,
                                  //             ),
                                  //             textAlign: TextAlign.center,
                                  //           ),
                                  //         ],
                                  //       ),
                                  //     ),
                                  //   ),
                                  // ),
                                ],
                              ).paddingOnly(
                                bottom: 10,
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: Get.height * 0.055,
                          child: blockButton(
                            callback: () {
                              Get.to(allProduct());
                            },
                            width: Get.width * 0.3,
                            widget: Text(
                              'See More',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  height: 1.2),
                            ),
                            verticalPadding: 3,
                          ),
                        ),
                      ],
                    ),
                  ],
                ).paddingSymmetric(horizontal: 10, vertical: 10),
              ],
            ),
          ),
          floatingActionButton:floatingActionButon(context)


        ),
      ),
    );
  }
}
