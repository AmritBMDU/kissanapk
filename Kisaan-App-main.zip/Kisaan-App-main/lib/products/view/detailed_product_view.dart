import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kisaan_electric/global/appcolor.dart';
import 'package:kisaan_electric/global/gradient_text.dart';
import 'package:kisaan_electric/products/controller/product_controller.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:smooth_star_rating_null_safety/smooth_star_rating_null_safety.dart';
import '../../CartPage.dart';

final  imgList = [
  'assets/img_3.png',
  'assets/img_4.png',
  'assets/img_5.png',
  'assets/img_4.png',
 ];

class detailedProductView extends StatefulWidget {
  const detailedProductView({super.key});

  @override
  State<detailedProductView> createState() => _detailedProductViewState();
}

class _detailedProductViewState extends State<detailedProductView> {
  productController controller = Get.put(productController());
  CarouselController buttonCarouselController = CarouselController();
  String selectedIndex= '';
  int _current = 0;
  var rating = 0.0;
  int quantity = 1;



  @override
  var value = null;
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: Get.height,
        width: Get.width,
        decoration: BoxDecoration(
          color: Colors.white
          // image: DecorationImage(
          //     image: AssetImage('assets/rectangle.png'), fit: BoxFit.fill),
        ),
          child: Scaffold(

            appBar: AppBar(
              centerTitle: true,
              automaticallyImplyLeading: false,
              title: Text('Detail',style: TextStyle(color: Colors.black),),
              backgroundColor: Colors.white,
              leading: IconButton(onPressed: (){
                Navigator.pop(context);
              }, icon:Icon(Icons.arrow_back_ios,color: Colors.red,)),
              actions: [
                IconButton(onPressed: (){
                  Get.to(CartPage());
                }, icon: Icon( Icons.shopping_cart_outlined,color: Colors.red,))
              ],
            ),
            // drawer: customDrawer(),
            backgroundColor: Colors.transparent,
            bottomNavigationBar: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    color: Colors.white,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: appcolor.redColor
                      ),
                      onPressed: (){
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Success')));
                      },child: Text('Add to Cart', style: TextStyle(
                      fontSize: 14,
                      color: Colors.white,
                      height: 0.7,
                    ),),
                    ),
                  ),
                  Container(
                    color: Colors.white,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: appcolor.redColor
                      ),

                      onPressed: (){},child: Text('Order Place', style: TextStyle(
                      fontSize: 14,
                      color: Colors.white,
                      height: 0.7,
                    ),),
                    ),
                  ),
                ],
              ),
            ),
            body: SingleChildScrollView(
              child: Column(
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            height: Get.height  * 0.41,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Stack(
                                  alignment: Alignment.topRight,
                                  children: [
                                    Column(
                                        children: [
                                      CarouselSlider.builder(
                                          itemCount: imgList.length,
                                          itemBuilder: (context,index, realindex){
                                            final urlimage =imgList[index];
                                            return Container(
                                              width: Get.width,
                                              color: Colors.grey,
                                              child: Image.asset(urlimage, fit: BoxFit.cover,),
                                            );
                                          },
                                          options: CarouselOptions(
                                            autoPlay: false,
                                            height: 300,
                                            enlargeCenterPage: false,
                                            aspectRatio: 2.0,

                                            viewportFraction: 1.0,
                                            initialPage: 0,
                                            onPageChanged: (index, reason){
                                            setState(() {
                                                      _current = index;
                                                    });
                                                                                    }
                                          )),



                                      Container(
                                        color: Colors.white,
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: AnimatedSmoothIndicator(
                                              activeIndex: _current,
                                              count: imgList.length,
                                          effect: JumpingDotEffect(
                                            dotWidth: 8,
                                            dotHeight: 8,
                                            activeDotColor: Colors.red,
                                            dotColor: Colors.black12
                                          ),),
                                        ),
                                      ),

                        ]),

                                    // Column(
                                    //   children: [
                                    //
                                    //     Padding(
                                    //       padding: const EdgeInsets.all(4.0),
                                    //       child: Container(
                                    //         height: 50,
                                    //         width: 50,
                                    //         decoration: BoxDecoration(
                                    //           border: Border.all(color:_current != null ? Colors.red:Colors.black,width: 2)
                                    //         ),
                                    //         child:Image.asset('assets/image 16.png',fit: BoxFit.cover,)
                                    //
                                    //       ),
                                    //     ),
                                    //
                                    //     Padding(
                                    //       padding: const EdgeInsets.all(4.0),
                                    //       child: Container(
                                    //
                                    //         decoration: BoxDecoration(
                                    //
                                    //             border: Border.all(color:_current == null ? Colors.black:Colors.white,width: 2)
                                    //         ),
                                    //         child: Image(
                                    //
                                    //           image: AssetImage(
                                    //             'assets/image 16.png',
                                    //           ),
                                    //         ),
                                    //       ),
                                    //     ),
                                    //     Padding(
                                    //       padding: const EdgeInsets.all(4.0),
                                    //       child: Container(
                                    //         decoration: BoxDecoration(
                                    //             border: Border.all(color:_current == null ? Colors.black:Colors.white,width: 2)
                                    //         ),
                                    //         child: Image(
                                    //           image: AssetImage(
                                    //             'assets/image 16.png',
                                    //           ),
                                    //         ),
                                    //       ),
                                    //     ),
                                    //   ],
                                    // )
                                  ],
                                ),

                              ],
                            ),
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 20,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [

                                  Text(
                                    'Double Door(Gold Series)',
                                    style: TextStyle(fontSize: 18, height: 0.9),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(right: 10),
                                    child: Row(
                                      children: [
                                       Icon(Icons.star,color: Colors.yellow,),
                                        Text('4.8', style: TextStyle(fontSize: 18, height: 0.9),)
                                      ],
                                    ),
                                  )
                                ],
                              ),
                              Text(
                                '₹1,000.00 – ₹1,490.00',
                                style: TextStyle(
                                  color: appcolor.newRedColor,
                                  fontSize: 14,
                                  height: 0.9,
                                ),
                              ),
                              SizedBox(height: 10,),
                              Text(
                                'Description',
                                style: TextStyle(fontSize: 14, height: 0.9),
                              ),
                              SizedBox(height: 10,),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Being  quality-conscious organization, we are instrument.Material- Galvanized Iron/ Mild Steel. Raw Material- TATA Steel',
                                    style: TextStyle(fontSize: 12, height: 1.2,),maxLines: 2,overflow: TextOverflow.ellipsis,
                                  ),
                                  TextButton(onPressed: (){}, child: Text('Read More',style: TextStyle(fontSize: 12,color: Colors.red),))
                                ],
                              ),

                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    padding: EdgeInsets.only(
                                        bottom: 8, top: 3, left: 10, right: 10),
                                    width: Get.width * 0.45,
                                    decoration: BoxDecoration(
                                      color: Colors.transparent,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        color: Color(
                                          0xffDD2B1C,
                                        ),
                                      ),
                                    ),
                                    child: Center(
                                      child: DropdownButtonFormField(
                                        decoration: InputDecoration.collapsed(
                                          hintText: 'Choose an Option',
                                          hintStyle: TextStyle(
                                            color: Colors.black,
                                            fontSize: 14,
                                            height: 1,
                                          ),
                                        ),
                                        value: value,
                                        onChanged: (value) {},
                                        items: [
                                          DropdownMenuItem(
                                            child: Text(
                                              'Option 1',
                                              style: TextStyle(
                                                fontSize: 14,
                                              ),
                                            ),
                                            value: 1,
                                          ),
                                          DropdownMenuItem(
                                              child: Text(
                                                'Option 2',
                                                style: TextStyle(
                                                  fontSize: 14,
                                                ),
                                              ),
                                              value: 2),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.all(Radius.circular(11)),
                                      border: Border.all(color: appcolor.redColor,width: 1)
                                    ),
                                    width: 120,
                                    child: Center(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          GestureDetector(
                                            onTap: (){
                                              decrement();
                                            },
                                            child: Padding(
                                                padding: const EdgeInsets.only(right: 1.0),
                                                child: Icon(Icons.remove, color: Colors.black,)
                                            ),
                                          ),
                                          SizedBox(width: 2,),
                                          Text(
                                            '$quantity',
                                            style: TextStyle(
                                                fontSize: 20,
                                                color: Colors.black,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          SizedBox(width: 2,),
                                          GestureDetector(
                                            onTap: (){
                                              increment();
                                            },
                                            child: Padding(
                                                padding: const EdgeInsets.only(left: 3.0),
                                                child: Icon(Icons.add, color: Colors.black,)
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  // Container(
                                  //   padding: EdgeInsets.only(
                                  //       bottom: 8, top: 3, left: 10, right: 10),
                                  //   width: Get.width * 0.4,
                                  //   decoration: BoxDecoration(
                                  //     color: Colors.transparent,
                                  //     borderRadius: BorderRadius.circular(10),
                                  //     border: Border.all(
                                  //       color: Color(
                                  //         0xffDD2B1C,
                                  //       ),
                                  //     ),
                                  //   ),
                                  //   child: Center(
                                  //     child: DropdownButtonFormField(
                                  //       decoration: InputDecoration.collapsed(
                                  //         hintText: '1',
                                  //         hintStyle: TextStyle(
                                  //           color: Colors.black,
                                  //           fontSize: 14,
                                  //           height: 1,
                                  //         ),
                                  //       ),
                                  //       value: value,
                                  //       onChanged: (value) {},
                                  //       items: [
                                  //         DropdownMenuItem(
                                  //           child: Text(
                                  //             '1',
                                  //             style: TextStyle(
                                  //               fontSize: 16,
                                  //             ),
                                  //           ),
                                  //           value: 1,
                                  //         ),
                                  //         DropdownMenuItem(
                                  //             child: Text(
                                  //               '2',
                                  //               style: TextStyle(
                                  //                 fontSize: 16,
                                  //               ),
                                  //             ),
                                  //             value: 2),
                                  //       ],
                                  //     ),
                                  //   ),
                                  // ),
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              // Container(
                              //   margin: EdgeInsets.only(left: 10),
                              //   padding: EdgeInsets.symmetric(
                              //       horizontal: 15, vertical: 12),
                              //   decoration: BoxDecoration(
                              //       border: Border.all(
                              //         color: Colors.black,
                              //       ),
                              //       color: appcolor.newRedColor,
                              //       borderRadius: BorderRadius.circular(
                              //         8,
                              //       )),
                              //   child: Text(
                              //     'Add to Cart',
                              //     style: TextStyle(
                              //       fontSize: 14,
                              //       color: Colors.white,
                              //       height: 0.7,
                              //     ),
                              //   ),
                              // ),
                            ],
                          ),
                        ],
                      ),
                      Text('Additional Information',style: TextStyle(fontSize: 15,color: appcolor.redColor),),
                      SizedBox(height: 10,),
                      Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: Colors.black,
                            radius: 4,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            'Material- Galvanized Iron/ Mild Steel',
                            style: TextStyle(
                              fontSize: 14,
                              height: 1,
                            ),
                          )
                        ],
                      ),
                      Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: Colors.black,
                            radius: 4,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            'Raw Material- TATA Steel',
                            style: TextStyle(
                              fontSize: 14,
                              height: 1,
                            ),
                          )
                        ],
                      ),
                      Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: Colors.black,
                            radius: 4,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            'Feature- Flame and Rust Proof',
                            style: TextStyle(
                              fontSize: 14,
                              height: 1,
                            ),
                          )
                        ],
                      ),
                      Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: Colors.black,
                            radius: 4,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            'Dimensions- As per requirement',
                            style: TextStyle(
                              fontSize: 14,
                              height: 1,
                            ),
                          )
                        ],
                      ),
                      Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: Colors.black,
                            radius: 4,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            'Cable Entry- Side Entry',
                            style: TextStyle(
                              fontSize: 14,
                              height: 1,
                            ),
                          )
                        ],
                      ),
                      SizedBox(height: 10,),
                      Text('Review',style: TextStyle(fontSize: 15,color: appcolor.redColor),),
                      SizedBox(height: 10,),
                      SmoothStarRating(
                          allowHalfRating: false,
                          onRatingChanged: (v) {
                            rating = v;
                            setState(() {});
                          },
                          starCount: 5,
                         rating: rating,
                          size: 40.0,
                          filledIconData: Icons.star,
                          halfFilledIconData: Icons.blur_on,
                          color: Colors.yellow,
                          borderColor: Colors.red,
                          spacing:0.0
                      ),
              SizedBox(height: 10,),
              Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height: 8),
                    chartRow(context, '5', 89),
                    chartRow(context, '4', 70),
                    chartRow(context, '3', 40),
                    chartRow(context, '4', 10),
                    chartRow(context, '1', 0),
                    SizedBox(height: 8),
                  ],
                ),
              ),
                      SizedBox(height: 20,),
                      // Container(
                      //   decoration: BoxDecoration(),
                      //   height: Get.height * 0.08,
                      //   child: TabBar(
                      //     dividerColor: appcolor.newRedColor,
                      //     isScrollable: true,
                      //     unselectedLabelColor: Colors.black,
                      //     unselectedLabelStyle: TextStyle(
                      //       fontSize: 14,
                      //     ),
                      //     indicatorColor: appcolor.redColor,
                      //     labelColor: Colors.black,
                      //     labelStyle: TextStyle(
                      //       fontWeight: FontWeight.bold,
                      //       color: Colors.black,
                      //       fontSize: 14,
                      //     ),
                      //     controller: controller.tabcontroller,
                      //     tabs: [
                      //       Container(
                      //         child: Text(
                      //           'Description'.tr,
                      //         ),
                      //       ),
                      //       Container(
                      //         child: Text('Additional Information'.tr),
                      //       ),
                      //       Text('Review'.tr),
                      //     ],
                      //   ),
                      // ),
                      // Container(
                      //   height: Get.height * 0.15,
                      //   child: Expanded(
                      //     child: TabBarView(
                      //       controller: controller.tabcontroller,
                      //       children: [
                      //         Column(
                      //           children: [
                      //             SizedBox(
                      //               height: 10,
                      //             ),
                      //             Row(
                      //               children: [
                      //                 CircleAvatar(
                      //                   backgroundColor: Colors.black,
                      //                   radius: 4,
                      //                 ),
                      //                 SizedBox(
                      //                   width: 10,
                      //                 ),
                      //                 Text(
                      //                   'Material- Galvanized Iron/ Mild Steel',
                      //                   style: TextStyle(
                      //                     fontSize: 14,
                      //                     height: 1,
                      //                   ),
                      //                 )
                      //               ],
                      //             ),
                      //             Row(
                      //               children: [
                      //                 CircleAvatar(
                      //                   backgroundColor: Colors.black,
                      //                   radius: 4,
                      //                 ),
                      //                 SizedBox(
                      //                   width: 10,
                      //                 ),
                      //                 Text(
                      //                   'Raw Material- TATA Steel',
                      //                   style: TextStyle(
                      //                     fontSize: 14,
                      //                     height: 1,
                      //                   ),
                      //                 )
                      //               ],
                      //             ),
                      //             Row(
                      //               children: [
                      //                 CircleAvatar(
                      //                   backgroundColor: Colors.black,
                      //                   radius: 4,
                      //                 ),
                      //                 SizedBox(
                      //                   width: 10,
                      //                 ),
                      //                 Text(
                      //                   'Feature- Flame and Rust Proof',
                      //                   style: TextStyle(
                      //                     fontSize: 14,
                      //                     height: 1,
                      //                   ),
                      //                 )
                      //               ],
                      //             ),
                      //             Row(
                      //               children: [
                      //                 CircleAvatar(
                      //                   backgroundColor: Colors.black,
                      //                   radius: 4,
                      //                 ),
                      //                 SizedBox(
                      //                   width: 10,
                      //                 ),
                      //                 Text(
                      //                   'Dimensions- As per requirement',
                      //                   style: TextStyle(
                      //                     fontSize: 14,
                      //                     height: 1,
                      //                   ),
                      //                 )
                      //               ],
                      //             ),
                      //             Row(
                      //               children: [
                      //                 CircleAvatar(
                      //                   backgroundColor: Colors.black,
                      //                   radius: 4,
                      //                 ),
                      //                 SizedBox(
                      //                   width: 10,
                      //                 ),
                      //                 Text(
                      //                   'Cable Entry- Side Entry',
                      //                   style: TextStyle(
                      //                     fontSize: 14,
                      //                     height: 1,
                      //                   ),
                      //                 )
                      //               ],
                      //             ),
                      //           ],
                      //         ),
                      //         Center(child: Text('Information')),
                      //         Center(child: Text('Review')),
                      //       ],
                      //     ),
                      //   ),
                      // ),
                      Row(
                        children: [
                          GradientText(
                              gradient: appcolor.gradient,
                              widget: Text('Related Products', style: TextStyle(fontSize: 20,color: appcolor.redColor),)),
                        ],
                      ),
                      Wrap(
                        spacing: 10,
                        children: [
                          appItemWidget('assets/image 25.png'),
                          appItemWidget('assets/image 25.png'),
                          appItemWidget('assets/image 25.png'),
                        ],
                      ),
                    ],
                  ).paddingSymmetric(horizontal: 10, vertical: 10),
                ],
              ),
            ),
          ),
      ),
    );
  }

  Widget appItemWidget(
    String imagepath,
  ) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.only(
            bottom: 0,
          ),
          child: Image(
            image: AssetImage(
              imagepath,
            ),
          ),
        ),
        Container(
          child: Text(
            'Fan Round Box\n₹128.00 – ₹162.00',
            style: TextStyle(
              fontSize: 10,
              height: 0.9,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        SizedBox(height: 5,),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 25, vertical: 8),
          decoration: BoxDecoration(
              color: appcolor.newRedColor,
              borderRadius: BorderRadius.circular(
                8,
              )),
          child: Text(
            'Buy Now',
            style: TextStyle(
              fontSize: 13,
              color: Colors.white,
              height: 0.7,
            ),
          ),
        ),
      ],
    );
  }
  void increment() {
    setState(() {
      quantity +=1;
    }
    );
  }

  void decrement() {
    setState(() {
      if(quantity ==1){
        quantity ==1;
      }else{
        quantity -= 1;
      }
    });
  }
  Widget chartRow(BuildContext context, String label, int pct) {
    return Row(
      children: [
        Text(label, style: TextStyle(color: Colors.black)),
        SizedBox(width: 8),
        Icon(Icons.star, color: Colors.yellow),
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(8, 0, 8, 0),
          child:
          Stack(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width * 0.66,
                  decoration: BoxDecoration(
                      color: Colors.grey,
                      borderRadius: BorderRadius.circular(20)
                  ),
                  child: Text(''),
                ),
                Container(
                  width: MediaQuery.of(context).size.width * (pct/100) * 0.66,
                  decoration: BoxDecoration(
                      color: Colors.green,
                      borderRadius: BorderRadius.circular(20)
                  ),
                  child: Text(''),
                ),
              ]

          ),
        ),
        Text('$pct%', style: TextStyle(color: Colors.black)),
      ],
    );
  }

}

